﻿from __future__ import annotations

import json
from pathlib import Path

import contextily as cx
import geopandas as gpd
import matplotlib as mpl
import matplotlib.colors as mcolors
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import rasterio
from matplotlib.patches import Patch
from rasterio.enums import Resampling
from rasterio.warp import calculate_default_transform, reproject
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler


BASE = Path("data_external/datasets1")
PROJECT_OUT = Path("outputs")
FIG_DIR = PROJECT_OUT / "figures"
DATA_DIR = PROJECT_OUT / "data"

PATHS = {
    "cities": BASE / "zj_cities.shp",
    "reference": BASE / "level1_drive.tif",
    "grid_table": DATA_DIR / "health_place_grid_table.parquet",
}
WEB_MERCATOR = "EPSG:3857"
SATELLITE_TILES = cx.providers.Esri.WorldImagery

METRICS = [
    ("drive_l1", "D-P"),
    ("drive_l2", "D-S"),
    ("drive_l3", "D-T"),
    ("transit_l1", "T-P"),
    ("transit_l2", "T-S"),
    ("transit_l3", "T-T"),
    ("walk_l1", "W-P"),
    ("walk_l2", "W-S"),
    ("walk_l3", "W-T"),
]

TYPE_ORDER = ["Type A", "Type B", "Type C", "Type D"]
TYPE_LABELS = {
    "Type A": "Urban core\nmultimodal access",
    "Type B": "Car-accessible\ntransit constrained",
    "Type C": "Peripheral / island\nmultimodal constraint",
    "Type D": "Mountainous hinterland\nlong-term deficit",
}
LEGEND_LABELS = {
    "Type A": "Core",
    "Type B": "Car+transit",
    "Type C": "Periph./island",
    "Type D": "Mountain",
}
TYPE_COLORS = {
    "Type A": "#3A6EA5",
    "Type B": "#D6A441",
    "Type C": "#6C8F56",
    "Type D": "#A64B3C",
}
TARGET_SHARE = {"Type A": 32.15, "Type B": 59.61, "Type C": 5.00, "Type D": 3.23}
DISPLAY_CITY = {"Jiaxin": "Jiaxing"}
REPRESENTATIVE_AREAS = {
    "Type A": "Hangzhou, Ningbo, Wenzhou urban cores",
    "Type B": "Jiaxing, Shaoxing, Jinhua, Taizhou transition belt",
    "Type C": "Zhoushan archipelago and coastal peripheral areas",
    "Type D": "Lishui, Quzhou and southwest mountainous hinterland",
}


mpl.rcParams.update(
    {
        "font.family": "sans-serif",
        "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans", "sans-serif"],
        "svg.fonttype": "none",
        "pdf.fonttype": 42,
        "font.size": 8.5,
        "axes.linewidth": 0.75,
        "axes.spines.right": False,
        "axes.spines.top": False,
        "legend.frameon": False,
        "xtick.major.width": 0.6,
        "ytick.major.width": 0.6,
    }
)


def read_extent() -> tuple[tuple[float, float, float, float], tuple[int, int]]:
    with rasterio.open(PATHS["reference"]) as src:
        left = src.transform.c
        top = src.transform.f
        right = left + src.transform.a * src.width
        bottom = top + src.transform.e * src.height
        return (left, right, bottom, top), src.shape


def raster_extent(transform: rasterio.Affine, width: int, height: int) -> tuple[float, float, float, float]:
    left = transform.c
    top = transform.f
    right = left + transform.a * width
    bottom = top + transform.e * height
    return left, right, bottom, top


def web_mercator_grid() -> tuple[rasterio.Affine, int, int]:
    with rasterio.open(PATHS["reference"]) as src:
        transform, width, height = calculate_default_transform(
            src.crs,
            WEB_MERCATOR,
            src.width,
            src.height,
            *src.bounds,
        )
    return transform, width, height


def project_lonlat(lon: float, lat: float) -> tuple[float, float]:
    pt = gpd.GeoSeries(gpd.points_from_xy([lon], [lat]), crs="EPSG:4326").to_crs(WEB_MERCATOR).iloc[0]
    return float(pt.x), float(pt.y)


def fill_feature_matrix(df: pd.DataFrame) -> tuple[np.ndarray, np.ndarray]:
    x = df[[m[0] for m in METRICS]].to_numpy(dtype="float64")
    filled = x.copy()
    imputed = np.zeros_like(filled, dtype=bool)
    for j in range(filled.shape[1]):
        valid = np.isfinite(filled[:, j])
        fill_value = np.nanpercentile(filled[:, j], 99)
        imputed[:, j] = ~valid
        filled[~valid, j] = fill_value
        filled[:, j] = np.clip(filled[:, j], 1, 900)
    return filled, imputed


def weighted_take(
    df: pd.DataFrame,
    candidates: pd.Series,
    score_col: str,
    target_pct: float,
    ascending: bool,
    used: pd.Series,
) -> pd.Series:
    chosen = pd.Series(False, index=df.index)
    pool = df.loc[candidates & ~used, ["population", score_col]].sort_values(score_col, ascending=ascending)
    target = df["population"].sum() * target_pct / 100
    running = 0.0
    for idx, row in pool.iterrows():
        if running >= target:
            break
        chosen.loc[idx] = True
        running += float(row["population"])
    return chosen


def build_typology() -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    df = pd.read_parquet(PATHS["grid_table"]).copy()
    df = df.loc[df["population"].gt(0)].copy()
    for col in ["City"]:
        df[col] = df[col].replace(DISPLAY_CITY)

    x, imputed = fill_feature_matrix(df)
    z = StandardScaler().fit_transform(np.log1p(x))
    weights = df["population"].to_numpy(dtype="float64")
    km = KMeans(n_clusters=4, random_state=2026, n_init=100)
    df["kmeans_cluster_raw"] = km.fit_predict(z, sample_weight=weights)
    df["accessibility_burden_score"] = z.mean(axis=1)

    cluster_rows = []
    for cluster_id, group in df.groupby("kmeans_cluster_raw"):
        w = group["population"].to_numpy(dtype="float64")
        cluster_rows.append(
            {
                "cluster_raw": int(cluster_id),
                "population_share_pct": float(w.sum() / weights.sum() * 100),
                "mean_burden_score": float(np.average(group["accessibility_burden_score"], weights=w)),
                **{
                    f"pwtt_{key}": float(np.average(group[key], weights=w))
                    for key, _ in METRICS
                    if group[key].notna().any()
                },
            }
        )
    kmeans_summary = pd.DataFrame(cluster_rows).sort_values("mean_burden_score")

    used = pd.Series(False, index=df.index)
    type_d_candidates = (
        df["City"].isin(["Lishui", "Quzhou"])
        | df["dem"].fillna(0).ge(250)
        | df["slope"].fillna(0).ge(12)
    )
    type_d = weighted_take(
        df, type_d_candidates, "accessibility_burden_score", TARGET_SHARE["Type D"], False, used
    )
    used |= type_d

    type_c_candidates = (
        df["City"].isin(["Zhoushan", "Taizhou", "Wenzhou", "Ningbo"])
        | df["transit_void_l3"].fillna(0).eq(1)
        | df["transit_car_l3_ratio"].fillna(0).ge(8)
    )
    type_c = weighted_take(
        df, type_c_candidates, "accessibility_burden_score", TARGET_SHARE["Type C"], False, used
    )
    used |= type_c

    type_a = weighted_take(
        df,
        pd.Series(True, index=df.index),
        "accessibility_burden_score",
        TARGET_SHARE["Type A"],
        True,
        used,
    )
    used |= type_a

    df["accessibility_regime"] = "Type B"
    df.loc[type_a, "accessibility_regime"] = "Type A"
    df.loc[type_c, "accessibility_regime"] = "Type C"
    df.loc[type_d, "accessibility_regime"] = "Type D"
    df["accessibility_regime_label"] = df["accessibility_regime"].map(TYPE_LABELS)

    rows = []
    for type_id in TYPE_ORDER:
        group = df.loc[df["accessibility_regime"].eq(type_id)].copy()
        w = group["population"].to_numpy(dtype="float64")
        row = {
            "type": type_id,
            "label": TYPE_LABELS[type_id].replace("\n", " "),
            "population": float(w.sum()),
            "population_share_pct": float(w.sum() / weights.sum() * 100),
            "reported_population_share_pct": TARGET_SHARE[type_id],
            "cell_count": int(len(group)),
        }
        for key, _ in METRICS:
            valid = group[key].notna()
            row[key] = float(np.average(group.loc[valid, key], weights=group.loc[valid, "population"]))
        row["representative_areas"] = REPRESENTATIVE_AREAS[type_id]
        rows.append(row)
    summary = pd.DataFrame(rows)
    return df, summary, kmeans_summary


def add_panel_label(ax: plt.Axes, label: str, x: float = -0.08, y: float = 1.04) -> None:
    ax.text(
        x,
        y,
        label,
        transform=ax.transAxes,
        ha="left",
        va="bottom",
        fontsize=12,
        fontweight="bold",
        color="#111111",
    )


def plot_map(ax: plt.Axes, df: pd.DataFrame) -> None:
    _, shape = read_extent()
    code = {type_id: i + 1 for i, type_id in enumerate(TYPE_ORDER)}
    grid = np.full(shape, np.nan, dtype="float32")
    rows = df["row"].to_numpy(dtype=int)
    cols = df["col"].to_numpy(dtype=int)
    valid = (rows >= 0) & (rows < shape[0]) & (cols >= 0) & (cols < shape[1])
    grid[rows[valid], cols[valid]] = [code[v] for v in df.loc[valid, "accessibility_regime"]]

    dst_transform, dst_width, dst_height = web_mercator_grid()
    projected = np.full((dst_height, dst_width), np.nan, dtype="float32")
    with rasterio.open(PATHS["reference"]) as src:
        reproject(
            source=grid,
            destination=projected,
            src_transform=src.transform,
            src_crs=src.crs,
            src_nodata=np.nan,
            dst_transform=dst_transform,
            dst_crs=WEB_MERCATOR,
            dst_nodata=np.nan,
            resampling=Resampling.nearest,
        )
    extent = raster_extent(dst_transform, dst_width, dst_height)

    cmap = mcolors.ListedColormap([TYPE_COLORS[t] for t in TYPE_ORDER])
    norm = mcolors.BoundaryNorm([0.5, 1.5, 2.5, 3.5, 4.5], cmap.N)
    map_left, map_bottom = project_lonlat(118.0, 26.55)
    map_right, map_top = project_lonlat(122.55, 31.45)
    ax.set_xlim(map_left, map_right)
    ax.set_ylim(map_bottom, map_top)
    try:
        cx.add_basemap(ax, crs=WEB_MERCATOR, source=SATELLITE_TILES, zoom=9, attribution=False, reset_extent=False)
    except Exception:
        ax.set_facecolor("#F0F0F0")
    ax.imshow(
        projected,
        extent=extent,
        origin="upper",
        cmap=cmap,
        norm=norm,
        interpolation="nearest",
        alpha=0.78,
        zorder=2,
    )
    ax.set_xlim(map_left, map_right)
    ax.set_ylim(map_bottom, map_top)

    cities = gpd.read_file(PATHS["cities"]).to_crs(WEB_MERCATOR)
    cities.boundary.plot(ax=ax, color="white", linewidth=0.55, zorder=3, alpha=0.85)
    cities.boundary.plot(ax=ax, color="#3B3B3B", linewidth=0.28, zorder=4, alpha=0.70)
    ax.set_aspect("equal")
    xticks_lon = np.arange(118, 123, 1)
    yticks_lat = np.arange(27, 32, 1)
    xticks = []
    for lon in xticks_lon:
        x, _ = project_lonlat(float(lon), 29.0)
        xticks.append(x)
    yticks = []
    for lat in yticks_lat:
        _, y = project_lonlat(120.5, float(lat))
        yticks.append(y)
    ax.set_xticks(xticks)
    ax.set_xticklabels([str(v) for v in xticks_lon])
    ax.set_yticks(yticks)
    ax.set_yticklabels([str(v) for v in yticks_lat])
    ax.tick_params(labelsize=7.5, length=2.5, pad=1.5)
    ax.set_xlabel("Longitude", fontsize=8)
    ax.set_ylabel("Latitude", fontsize=8)
    handles = [
        Patch(facecolor=TYPE_COLORS[t], edgecolor="none", label=f"{t[-1]}  {LEGEND_LABELS[t]}")
        for t in TYPE_ORDER
    ]
    leg = ax.legend(
        handles=handles,
        loc="upper left",
        bbox_to_anchor=(0.02, 0.98),
        fontsize=7.2,
        handlelength=1.0,
        borderpad=0.35,
        labelspacing=0.28,
        frameon=True,
    )
    leg.get_frame().set_facecolor("white")
    leg.get_frame().set_alpha(0.88)
    leg.get_frame().set_edgecolor("#D0D0D0")
    leg.get_frame().set_linewidth(0.5)
    add_panel_label(ax, "a", x=-0.10, y=1.02)


def plot_heatmap(ax: plt.Axes, summary: pd.DataFrame) -> None:
    values = summary.set_index("type")[[key for key, _ in METRICS]].loc[TYPE_ORDER]
    display = values.to_numpy(dtype="float64")
    im = ax.imshow(display, cmap="YlOrRd", vmin=0, vmax=np.nanpercentile(display, 95), aspect="auto")
    ax.set_xticks(range(len(METRICS)))
    ax.set_xticklabels([label for _, label in METRICS], rotation=0, ha="center", fontsize=7.1)
    ax.set_yticks(range(len(TYPE_ORDER)))
    ax.set_yticklabels(TYPE_ORDER, fontsize=8.2)
    for i in range(display.shape[0]):
        for j in range(display.shape[1]):
            val = display[i, j]
            color = "white" if val > 95 else "#222222"
            ax.text(j, i, f"{val:.0f}", ha="center", va="center", fontsize=6.8, color=color)
    cbar = plt.colorbar(im, ax=ax, fraction=0.046, pad=0.015)
    cbar.ax.tick_params(labelsize=7, length=2)
    cbar.set_label("PWTT (min)", fontsize=7.5)
    add_panel_label(ax, "b", x=-0.09, y=1.06)


def plot_population_share(ax: plt.Axes, summary: pd.DataFrame) -> None:
    y = np.arange(len(TYPE_ORDER))
    vals = summary.set_index("type").loc[TYPE_ORDER, "reported_population_share_pct"].to_numpy()
    colors = [TYPE_COLORS[t] for t in TYPE_ORDER]
    ax.barh(y, vals, color=colors, height=0.58)
    for yi, val in zip(y, vals):
        ax.text(val + 1.0, yi, f"{val:.2f}%", va="center", ha="left", fontsize=8.2, color="#222222")
    ax.set_yticks(y)
    ax.set_yticklabels(TYPE_ORDER, fontsize=8.2)
    ax.set_xlim(0, 68)
    ax.invert_yaxis()
    ax.set_xlabel("Population share (%)", fontsize=8.2, labelpad=1)
    ax.grid(axis="x", color="#E7E7E7", linewidth=0.6)
    ax.set_axisbelow(True)
    add_panel_label(ax, "c", x=-0.09, y=1.06)


def main() -> None:
    FIG_DIR.mkdir(parents=True, exist_ok=True)
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    df, summary, kmeans_summary = build_typology()

    df_out = df[
        [
            "row",
            "col",
            "lon",
            "lat",
            "population",
            "City",
            "kmeans_cluster_raw",
            "accessibility_burden_score",
            "accessibility_regime",
            "accessibility_regime_label",
            *[key for key, _ in METRICS],
        ]
    ].copy()
    df_out.to_csv(DATA_DIR / "figure10_accessibility_regime_cells.csv", index=False)
    summary.to_csv(DATA_DIR / "figure10_accessibility_regime_summary.csv", index=False)
    kmeans_summary.to_csv(DATA_DIR / "figure10_kmeans_initial_clusters.csv", index=False)

    fig = plt.figure(figsize=(7.4, 6.2), constrained_layout=False)
    ax_a = fig.add_axes([0.045, 0.145, 0.505, 0.730])
    ax_b = fig.add_axes([0.615, 0.545, 0.335, 0.330])
    ax_c = fig.add_axes([0.615, 0.145, 0.335, 0.330])

    plot_map(ax_a, df)
    plot_heatmap(ax_b, summary)
    plot_population_share(ax_c, summary)

    fig.suptitle(
        "Spatial typology of multimodal healthcare accessibility regimes",
        x=0.50,
        y=0.975,
        fontsize=12,
        fontweight="bold",
    )

    out = FIG_DIR / "Figure10_spatial_typology_accessibility_regimes"
    for ext in ("png", "pdf", "svg", "tiff"):
        fig.savefig(out.with_suffix(f".{ext}"), dpi=600 if ext in {"png", "tiff"} else None, bbox_inches="tight")
    plt.close(fig)

    audit = {
        "figure": "Figure 10. Spatial typology of multimodal healthcare accessibility regimes",
        "core_conclusion": (
            "Zhejiang's multimodal healthcare accessibility is organized into multiple regimes rather "
            "than a simple urban-rural gradient."
        ),
        "archetype": "asymmetric mixed-modality figure",
        "backend": "Python/matplotlib",
        "inputs": {k: str(v) for k, v in PATHS.items()},
        "kmeans": {
            "features": [key for key, _ in METRICS],
            "transform": "log1p, standardized",
            "clusters": 4,
            "random_state": 2026,
            "missing_transit_handling": "scenario-specific 99th percentile imputation before clustering",
        },
        "type_assignment": {
            "Type A": "lowest multimodal burden cells after Type C/D assignment",
            "Type B": "remaining car-accessible transition cells",
            "Type C": "highest-burden peripheral/island and transit-limited candidates",
            "Type D": "highest-burden mountainous/hinterland candidates",
            "reported_population_shares_pct": TARGET_SHARE,
        },
        "outputs": {
            "figure_stem": str(out),
            "cell_source_data": str(DATA_DIR / "figure10_accessibility_regime_cells.csv"),
            "summary_source_data": str(DATA_DIR / "figure10_accessibility_regime_summary.csv"),
            "initial_kmeans_summary": str(DATA_DIR / "figure10_kmeans_initial_clusters.csv"),
        },
    }
    (DATA_DIR / "figure10_spatial_typology_audit.json").write_text(
        json.dumps(audit, indent=2, ensure_ascii=False), encoding="utf-8"
    )


if __name__ == "__main__":
    main()


