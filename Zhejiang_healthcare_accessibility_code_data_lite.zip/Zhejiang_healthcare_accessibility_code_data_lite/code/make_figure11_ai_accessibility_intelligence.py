﻿from __future__ import annotations

import json
from pathlib import Path

import contextily as cx
import geopandas as gpd
import matplotlib as mpl
import matplotlib.colors as mcolors
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import rasterio
import shap
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch, Patch
from rasterio.enums import Resampling
from rasterio.warp import calculate_default_transform, reproject
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, cohen_kappa_score, confusion_matrix, f1_score
from sklearn.model_selection import StratifiedGroupKFold, cross_val_predict
from sklearn.preprocessing import StandardScaler


BASE = Path("data_external/datasets1")
PROJECT_OUT = Path("outputs")
FIG_DIR = PROJECT_OUT / "figures"
DATA_DIR = PROJECT_OUT / "data"

PATHS = {
    "cities": BASE / "zj_cities.shp",
    "reference": BASE / "level1_drive.tif",
    "cells": DATA_DIR / "figure10_accessibility_regime_cells.csv",
    "summary": DATA_DIR / "figure10_accessibility_regime_summary.csv",
}

FEATURES = [
    ("drive_l1", "Driving-primary", "Driving"),
    ("drive_l2", "Driving-secondary", "Driving"),
    ("drive_l3", "Driving-tertiary", "Driving"),
    ("transit_l1", "Transit-primary", "Public transit"),
    ("transit_l2", "Transit-secondary", "Public transit"),
    ("transit_l3", "Transit-tertiary", "Public transit"),
    ("walk_l1", "Walking-primary", "Walking"),
    ("walk_l2", "Walking-secondary", "Walking"),
    ("walk_l3", "Walking-tertiary", "Walking"),
]
FEATURE_KEYS = [x[0] for x in FEATURES]
FEATURE_LABELS = {x[0]: x[1] for x in FEATURES}
FEATURE_MODES = {x[0]: x[2] for x in FEATURES}

TYPE_ORDER = ["Type A", "Type B", "Type C", "Type D"]
TYPE_COLORS = {
    "Type A": "#3A6EA5",
    "Type B": "#D6A441",
    "Type C": "#6C8F56",
    "Type D": "#A64B3C",
}
TYPE_SHORT = {
    "Type A": "Favourable cores",
    "Type B": "Car-accessible,\ntransit-constrained",
    "Type C": "Peripheral / island",
    "Type D": "Mountainous deficit",
}
MODE_COLORS = {
    "Driving": "#4F79A7",
    "Public transit": "#D28A35",
    "Walking": "#4D8B6A",
}
WEB_MERCATOR = "EPSG:3857"


mpl.rcParams.update(
    {
        "font.family": "sans-serif",
        "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans", "sans-serif"],
        "svg.fonttype": "none",
        "pdf.fonttype": 42,
        "font.size": 7.5,
        "axes.linewidth": 0.7,
        "axes.spines.right": False,
        "axes.spines.top": False,
        "legend.frameon": False,
        "xtick.major.width": 0.6,
        "ytick.major.width": 0.6,
    }
)


def panel_label(ax: plt.Axes, label: str, x: float = -0.06, y: float = 1.02) -> None:
    ax.text(
        x,
        y,
        label,
        transform=ax.transAxes,
        ha="left",
        va="bottom",
        fontsize=10,
        fontweight="bold",
        color="#151515",
        clip_on=False,
    )


def prepare_features(df: pd.DataFrame) -> pd.DataFrame:
    x = df[FEATURE_KEYS].copy()
    for col in FEATURE_KEYS:
        fill = float(x[col].quantile(0.99))
        x[col] = np.log1p(np.clip(x[col].fillna(fill), 1, 900))
    return x


def fit_explainable_model(
    df: pd.DataFrame,
) -> tuple[RandomForestClassifier, dict[str, float], np.ndarray, pd.DataFrame]:
    x = prepare_features(df)
    y = df["accessibility_regime"].astype(str)

    # Spatial blocks reduce leakage between neighbouring grid cells.
    groups = (
        np.floor((df["lon"] - 117.5) / 0.35).astype(int) * 100
        + np.floor((df["lat"] - 26.0) / 0.35).astype(int)
    )
    cv = StratifiedGroupKFold(n_splits=5, shuffle=True, random_state=2026)
    cv_model = RandomForestClassifier(
        n_estimators=220,
        max_features="sqrt",
        min_samples_leaf=4,
        class_weight="balanced_subsample",
        n_jobs=-1,
        random_state=2026,
    )
    prediction = cross_val_predict(cv_model, x, y, groups=groups, cv=cv, n_jobs=1)
    metrics = {
        "accuracy": float(accuracy_score(y, prediction)),
        "macro_f1": float(f1_score(y, prediction, average="macro")),
        "kappa": float(cohen_kappa_score(y, prediction)),
    }
    matrix = confusion_matrix(y, prediction, labels=TYPE_ORDER)

    model = RandomForestClassifier(
        n_estimators=120,
        max_features="sqrt",
        min_samples_leaf=4,
        class_weight="balanced_subsample",
        n_jobs=-1,
        random_state=2026,
    )
    model.fit(x, y)
    sample = x.sample(n=min(600, len(x)), random_state=2026)
    shap_values = np.asarray(
        shap.TreeExplainer(model).shap_values(
            sample,
            check_additivity=False,
            approximate=True,
        )
    )
    # shap >=0.45 returns sample x feature x class for multiclass forests.
    if shap_values.ndim != 3 or shap_values.shape[1] != len(FEATURE_KEYS):
        raise RuntimeError(f"Unexpected SHAP array shape: {shap_values.shape}")
    importance = np.abs(shap_values).mean(axis=(0, 2))
    importance_df = pd.DataFrame(
        {
            "feature": FEATURE_KEYS,
            "label": [FEATURE_LABELS[x] for x in FEATURE_KEYS],
            "mode": [FEATURE_MODES[x] for x in FEATURE_KEYS],
            "mean_abs_shap": importance,
        }
    ).sort_values("mean_abs_shap", ascending=False)
    return model, metrics, matrix, importance_df


def add_box(
    ax: plt.Axes,
    xy: tuple[float, float],
    width: float,
    height: float,
    text: str,
    edge: str,
    fill: str,
    fontsize: float = 7.2,
    bold: bool = False,
) -> None:
    box = FancyBboxPatch(
        xy,
        width,
        height,
        boxstyle="round,pad=0.018,rounding_size=0.025",
        transform=ax.transAxes,
        facecolor=fill,
        edgecolor=edge,
        linewidth=0.9,
    )
    ax.add_patch(box)
    ax.text(
        xy[0] + width / 2,
        xy[1] + height / 2,
        text,
        transform=ax.transAxes,
        ha="center",
        va="center",
        fontsize=fontsize,
        fontweight="bold" if bold else "normal",
        color="#202020",
        linespacing=1.18,
    )


def add_arrow(ax: plt.Axes, start: tuple[float, float], end: tuple[float, float]) -> None:
    arrow = FancyArrowPatch(
        start,
        end,
        transform=ax.transAxes,
        arrowstyle="-|>",
        mutation_scale=8,
        linewidth=0.8,
        color="#777777",
    )
    ax.add_patch(arrow)


def plot_workflow(ax: plt.Axes, metrics: dict[str, float]) -> None:
    ax.set_axis_off()
    panel_label(ax, "b", x=-0.09, y=1.02)
    ax.text(
        0,
        1.00,
        "AI analytical workflow",
        transform=ax.transAxes,
        ha="left",
        va="top",
        fontsize=8.2,
        fontweight="bold",
    )
    boxes = [
        ("Nine multimodal travel-time indicators", "#3A6EA5", "#EEF4FA"),
        ("K-means + planning-oriented regimes", "#267A7B", "#EAF5F3"),
        (
            f"RF surrogate: Acc. {metrics['accuracy']:.3f} | F1 {metrics['macro_f1']:.3f} | "
            f"Kappa {metrics['kappa']:.3f}",
            "#267A7B",
            "#EAF5F3",
        ),
        ("SHAP diagnosis -> targeted planning", "#5B873C", "#F0F6EB"),
    ]
    y_positions = [0.74, 0.51, 0.28, 0.05]
    for i, ((text, edge, fill), y) in enumerate(zip(boxes, y_positions)):
        add_box(ax, (0.04, y), 0.92, 0.145, text, edge, fill, fontsize=6.4, bold=i >= 1)
        if i < len(boxes) - 1:
            add_arrow(ax, (0.50, y - 0.005), (0.50, y_positions[i + 1] + 0.155))


def raster_extent(transform: rasterio.Affine, width: int, height: int) -> tuple[float, float, float, float]:
    left = transform.c
    top = transform.f
    right = left + transform.a * width
    bottom = top + transform.e * height
    return left, right, bottom, top


def project_lonlat(lon: float, lat: float) -> tuple[float, float]:
    pt = gpd.GeoSeries(gpd.points_from_xy([lon], [lat]), crs="EPSG:4326").to_crs(WEB_MERCATOR).iloc[0]
    return float(pt.x), float(pt.y)


def plot_regime_map(ax: plt.Axes, df: pd.DataFrame) -> None:
    with rasterio.open(PATHS["reference"]) as src:
        grid = np.full(src.shape, np.nan, dtype="float32")
        rows = df["row"].to_numpy(dtype=int)
        cols = df["col"].to_numpy(dtype=int)
        valid = (rows >= 0) & (rows < src.height) & (cols >= 0) & (cols < src.width)
        code = {name: i + 1 for i, name in enumerate(TYPE_ORDER)}
        grid[rows[valid], cols[valid]] = [
            code[x] for x in df.loc[valid, "accessibility_regime"]
        ]
        dst_transform, dst_width, dst_height = calculate_default_transform(
            src.crs, WEB_MERCATOR, src.width, src.height, *src.bounds
        )
        projected = np.full((dst_height, dst_width), np.nan, dtype="float32")
        reproject(
            source=grid,
            destination=projected,
            src_transform=src.transform,
            src_crs=src.crs,
            src_nodata=np.nan,
            dst_transform=dst_transform,
            dst_crs=WEB_MERCATOR,
            dst_nodata=np.nan,
            resampling=Resampling.nearest,
        )

    map_left, map_bottom = project_lonlat(118.0, 26.55)
    map_right, map_top = project_lonlat(122.55, 31.45)
    ax.set_xlim(map_left, map_right)
    ax.set_ylim(map_bottom, map_top)
    try:
        cx.add_basemap(
            ax,
            crs=WEB_MERCATOR,
            source=cx.providers.Esri.WorldImagery,
            zoom=9,
            attribution=False,
            reset_extent=False,
        )
    except Exception:
        ax.set_facecolor("#E7E7E7")

    cmap = mcolors.ListedColormap([TYPE_COLORS[x] for x in TYPE_ORDER])
    norm = mcolors.BoundaryNorm([0.5, 1.5, 2.5, 3.5, 4.5], cmap.N)
    ax.imshow(
        projected,
        extent=raster_extent(dst_transform, dst_width, dst_height),
        origin="upper",
        cmap=cmap,
        norm=norm,
        interpolation="nearest",
        alpha=0.78,
        zorder=2,
    )
    cities = gpd.read_file(PATHS["cities"]).to_crs(WEB_MERCATOR)
    cities.boundary.plot(ax=ax, color="white", linewidth=0.55, zorder=3, alpha=0.9)
    cities.boundary.plot(ax=ax, color="#333333", linewidth=0.25, zorder=4, alpha=0.65)

    ax.set_xlim(map_left, map_right)
    ax.set_ylim(map_bottom, map_top)
    ax.set_aspect("equal")
    xticks_lon = np.arange(118, 123, 1)
    yticks_lat = np.arange(27, 32, 1)
    ax.set_xticks([project_lonlat(float(x), 29.0)[0] for x in xticks_lon])
    ax.set_yticks([project_lonlat(120.5, float(y))[1] for y in yticks_lat])
    ax.set_xticklabels([str(x) for x in xticks_lon], fontsize=7.5)
    ax.set_yticklabels([str(y) for y in yticks_lat], fontsize=7.5)
    ax.tick_params(length=2.5, pad=1.5)
    ax.set_xlabel("Longitude", fontsize=8)
    ax.set_ylabel("Latitude", fontsize=8)
    handles = [
        Patch(
            facecolor=TYPE_COLORS[x],
            edgecolor="none",
            label={
                "Type A": "A  Core",
                "Type B": "B  Car+transit",
                "Type C": "C  Periph./island",
                "Type D": "D  Mountain",
            }[x],
        )
        for x in TYPE_ORDER
    ]
    leg = ax.legend(
        handles=handles,
        loc="upper left",
        bbox_to_anchor=(0.015, 0.985),
        fontsize=7.2,
        frameon=True,
        handlelength=0.9,
        borderpad=0.35,
        labelspacing=0.26,
    )
    leg.get_frame().set_facecolor("white")
    leg.get_frame().set_alpha(0.88)
    leg.get_frame().set_edgecolor("#CCCCCC")
    leg.get_frame().set_linewidth(0.5)
    panel_label(ax, "a", x=-0.10, y=1.02)


def plot_profiles(ax: plt.Axes, summary: pd.DataFrame) -> None:
    values = summary.set_index("type").loc[TYPE_ORDER, FEATURE_KEYS]
    display = values.to_numpy(dtype=float)
    im = ax.imshow(
        display,
        cmap="YlOrRd",
        vmin=0,
        vmax=np.nanpercentile(display, 95),
        aspect="auto",
    )
    ax.set_xticks(range(len(FEATURE_KEYS)))
    ax.set_xticklabels(
        ["D-P", "D-S", "D-T", "T-P", "T-S", "T-T", "W-P", "W-S", "W-T"],
        fontsize=6.8,
    )
    ax.set_yticks(range(len(TYPE_ORDER)))
    ax.set_yticklabels(TYPE_ORDER, fontsize=7.8)
    for i in range(len(TYPE_ORDER)):
        for j in range(len(FEATURE_KEYS)):
            value = display[i, j]
            ax.text(
                j,
                i,
                f"{value:.0f}",
                ha="center",
                va="center",
                fontsize=6.2,
                color="white" if value > 95 else "#252525",
            )
    cbar = plt.colorbar(im, ax=ax, fraction=0.040, pad=0.015)
    cbar.set_label("PWTT (min)", fontsize=7.2)
    cbar.ax.tick_params(labelsize=6.2, length=2)
    panel_label(ax, "b", x=-0.09, y=1.06)


def plot_shap_importance(ax: plt.Axes, importance: pd.DataFrame) -> None:
    ordered = importance.sort_values("mean_abs_shap", ascending=True).copy()
    y = np.arange(len(ordered))
    colors = [MODE_COLORS[x] for x in ordered["mode"]]
    ax.barh(y, ordered["mean_abs_shap"], color=colors, height=0.64)
    ax.set_yticks(y)
    code_labels = {
        "drive_l1": "D-P",
        "drive_l2": "D-S",
        "drive_l3": "D-T",
        "transit_l1": "T-P",
        "transit_l2": "T-S",
        "transit_l3": "T-T",
        "walk_l1": "W-P",
        "walk_l2": "W-S",
        "walk_l3": "W-T",
    }
    short_labels = [code_labels[x] for x in ordered["feature"]]
    ax.set_yticklabels(short_labels, fontsize=6.0)
    ax.set_xlabel("Mean |SHAP value|", fontsize=7.2)
    ax.set_title("Global SHAP importance", loc="left", fontsize=8.0, pad=10)
    ax.grid(axis="x", color="#E5E5E5", linewidth=0.55)
    ax.set_axisbelow(True)
    ax.tick_params(axis="x", labelsize=6.5)
    handles = [Patch(facecolor=color, edgecolor="none", label=mode) for mode, color in MODE_COLORS.items()]
    ax.legend(
        handles=handles,
        loc="lower right",
        fontsize=6.3,
        handlelength=0.9,
        labelspacing=0.25,
    )
    total = float(importance["mean_abs_shap"].sum())
    non_car = float(
        importance.loc[importance["mode"].isin(["Public transit", "Walking"]), "mean_abs_shap"].sum()
    )
    ax.text(
        0.00,
        1.012,
        f"Non-car indicators: {non_car / total * 100:.1f}%",
        transform=ax.transAxes,
        ha="left",
        va="bottom",
        fontsize=6.1,
        fontweight="bold",
        color="#444444",
    )
    panel_label(ax, "c", x=-0.09, y=1.075)


def main() -> None:
    FIG_DIR.mkdir(parents=True, exist_ok=True)
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    cells = pd.read_csv(PATHS["cells"])
    summary = pd.read_csv(PATHS["summary"])
    metrics_path = DATA_DIR / "figure11_spatial_cv_metrics.csv"
    matrix_path = DATA_DIR / "figure11_spatial_cv_confusion_matrix.csv"
    importance_path = DATA_DIR / "figure11_shap_global_importance.csv"
    if metrics_path.exists() and matrix_path.exists() and importance_path.exists():
        metrics = pd.read_csv(metrics_path).iloc[0].to_dict()
        matrix = pd.read_csv(matrix_path, index_col=0).loc[TYPE_ORDER, TYPE_ORDER].to_numpy()
        importance = pd.read_csv(importance_path)
    else:
        _, metrics, matrix, importance = fit_explainable_model(cells)

    fig = plt.figure(figsize=(7.4, 6.2), constrained_layout=False)
    ax_a = fig.add_axes([0.045, 0.145, 0.505, 0.730])
    ax_b = fig.add_axes([0.615, 0.545, 0.335, 0.330])
    ax_c = fig.add_axes([0.615, 0.145, 0.335, 0.330])

    plot_regime_map(ax_a, cells)
    plot_profiles(ax_b, summary)
    plot_shap_importance(ax_c, importance)

    fig.suptitle(
        "AI-enabled identification and explanation of healthcare accessibility regimes",
        x=0.50,
        y=0.975,
        fontsize=12,
        fontweight="bold",
    )

    stem = FIG_DIR / "Figure11_AI_enabled_accessibility_intelligence"
    for ext in ("png", "pdf", "svg", "tiff"):
        fig.savefig(
            stem.with_suffix(f".{ext}"),
            dpi=600 if ext in {"png", "tiff"} else None,
            bbox_inches="tight",
            facecolor="white",
        )
    plt.close(fig)

    importance.to_csv(importance_path, index=False)
    pd.DataFrame(matrix, index=TYPE_ORDER, columns=TYPE_ORDER).to_csv(
        matrix_path
    )
    pd.DataFrame([metrics]).to_csv(metrics_path, index=False)
    audit = {
        "figure": "Figure 11. AI-enabled identification and explanation of healthcare accessibility regimes",
        "core_conclusion": (
            "The four planning-oriented accessibility regimes can be recovered from multimodal travel-time "
            "indicators under spatial validation, and their separation is driven predominantly by non-car access."
        ),
        "archetype": "asymmetric mixed-modality figure",
        "backend": "Python/matplotlib",
        "regime_provenance": (
            "Existing planning-oriented Type A-D labels derived from the K-means burden structure plus "
            "terrain/island candidate rules and reported population-share targets."
        ),
        "rf_role": "Explainable surrogate classifier, not the original source of the regime labels.",
        "features": FEATURE_KEYS,
        "validation": {
            "scheme": "5-fold StratifiedGroupKFold using 0.35-degree spatial blocks",
            **metrics,
            "confusion_matrix_labels": TYPE_ORDER,
            "confusion_matrix": matrix.tolist(),
        },
        "shap": {
            "method": "TreeSHAP approximate mode on a fixed 600-cell sample",
            "aggregation": "mean absolute SHAP across samples and four classes",
        },
        "outputs": {
            "figure_stem": str(stem),
            "metrics": str(metrics_path),
            "confusion_matrix": str(matrix_path),
            "importance": str(importance_path),
        },
    }
    (DATA_DIR / "figure11_ai_accessibility_intelligence_audit.json").write_text(
        json.dumps(audit, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )


if __name__ == "__main__":
    main()


