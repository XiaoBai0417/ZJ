﻿from __future__ import annotations

import json
from pathlib import Path

import contextily as cx
import geopandas as gpd
import matplotlib as mpl
import matplotlib.colors as mcolors
import matplotlib.patheffects as pe
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import rasterio
import cartopy.crs as ccrs
from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle
from matplotlib.ticker import FuncFormatter
from rasterio import features
from rasterio.warp import Resampling, reproject


BASE = Path("data_external/datasets1")
PROJECT_OUT = Path("outputs")
FIG_DIR = PROJECT_OUT / "figures"
DATA_DIR = PROJECT_OUT / "data"

PATHS = {
    "china_provinces": Path("data_external/boundaries/China_province.shp"),
    "china_lines": Path("data_external/boundaries/china_line.shp"),
    "zhejiang_cities": BASE / "zj_cities.shp",
    "population": BASE / "ZJ_pop.tif",
    "dem": Path("data_external/terrain/resampled_dem_2.tif"),
}

CHINA_ALBERS = (
    "+proj=aea +lat_1=25 +lat_2=47 +lat_0=35 +lon_0=105 "
    "+x_0=0 +y_0=0 +datum=WGS84 +units=m +no_defs"
)
WEB_MERCATOR = "EPSG:3857"
SATELLITE_TILES = cx.providers.Esri.WorldImagery


mpl.rcParams.update(
    {
        "font.family": "sans-serif",
        "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans", "sans-serif"],
        "svg.fonttype": "none",
        "pdf.fonttype": 42,
        "font.size": 9,
        "axes.spines.right": False,
        "axes.spines.top": False,
        "axes.linewidth": 0.75,
        "legend.frameon": False,
        "xtick.major.width": 0.65,
        "ytick.major.width": 0.65,
    }
)


DISPLAY_CITY = {"Jiaxin": "Jiaxing"}
URBAN_COASTAL = {"Hangzhou", "Ningbo", "Wenzhou", "Taizhou", "Jiaxin", "Shaoxing"}

CITY_LABELS = {
    "Hangzhou": (120.05, 30.35),
    "Ningbo": (121.46, 29.93),
    "Wenzhou": (120.60, 28.00),
    "Zhoushan": (122.10, 30.08),
    "Lishui": (119.45, 28.18),
    "Jinhua": (119.72, 29.05),
}


def clean_raster(arr: np.ndarray, nodata: float | int | None) -> np.ndarray:
    arr = arr.astype("float32", copy=False)
    if nodata is not None and np.isfinite(nodata):
        arr = np.where(arr == nodata, np.nan, arr)
    return np.where(np.isfinite(arr), arr, np.nan)


def raster_extent(transform: rasterio.Affine, arr: np.ndarray) -> tuple[float, float, float, float]:
    h, w = arr.shape
    left = transform.c
    top = transform.f
    right = left + transform.a * w
    bottom = top + transform.e * h
    return left, right, bottom, top


def reproject_dem_to_population_grid(
    dem_path: Path, pop_path: Path, mask_gdf: gpd.GeoDataFrame
) -> tuple[np.ndarray, np.ndarray, rasterio.Affine, rasterio.crs.CRS]:
    with rasterio.open(pop_path) as tmpl:
        dst_shape = (tmpl.height, tmpl.width)
        dst_transform = tmpl.transform
        dst_crs = tmpl.crs
        pop = clean_raster(tmpl.read(1), tmpl.nodata)

    with rasterio.open(dem_path) as src:
        dem = np.full(dst_shape, np.nan, dtype="float32")
        reproject(
            source=rasterio.band(src, 1),
            destination=dem,
            src_transform=src.transform,
            src_crs=src.crs,
            src_nodata=src.nodata,
            dst_transform=dst_transform,
            dst_crs=dst_crs,
            dst_nodata=np.nan,
            resampling=Resampling.bilinear,
        )

    mask_arr = features.geometry_mask(
        mask_gdf.to_crs(dst_crs).geometry,
        out_shape=dst_shape,
        transform=dst_transform,
        invert=True,
        all_touched=True,
    )
    return np.where(mask_arr, dem, np.nan), np.where(mask_arr, pop, np.nan), dst_transform, dst_crs


def hillshade(dem: np.ndarray, azimuth: float = 315, altitude: float = 45) -> np.ndarray:
    fill = np.nanmedian(dem)
    z = np.where(np.isfinite(dem), dem, fill)
    dy, dx = np.gradient(z)
    slope = np.pi / 2.0 - np.arctan(np.hypot(dx, dy))
    aspect = np.arctan2(-dx, dy)
    az = np.deg2rad(azimuth)
    alt = np.deg2rad(altitude)
    shaded = np.sin(alt) * np.sin(slope) + np.cos(alt) * np.cos(slope) * np.cos(az - aspect)
    return (shaded - np.nanmin(shaded)) / (np.nanmax(shaded) - np.nanmin(shaded))


def population_by_city(pop_path: Path, cities: gpd.GeoDataFrame) -> pd.DataFrame:
    with rasterio.open(pop_path) as src:
        pop = clean_raster(src.read(1), src.nodata)
        city_src = cities.to_crs(src.crs)
        rows = []
        for _, row in city_src.iterrows():
            city_mask = features.geometry_mask(
                [row.geometry],
                out_shape=pop.shape,
                transform=src.transform,
                invert=True,
                all_touched=True,
            )
            rows.append({"City": row["City_name"], "population": float(np.nansum(np.where(city_mask, pop, np.nan)))})
    out = pd.DataFrame(rows).sort_values("population", ascending=True)
    out["City_display"] = out["City"].replace(DISPLAY_CITY)
    out["setting"] = np.where(out["City"].isin(URBAN_COASTAL), "Northern/coastal", "Interior/mountain")
    return out


def add_panel_label(ax: plt.Axes, label: str, x: float = 0.0, y: float = 1.0) -> None:
    ax.text(
        x,
        y,
        label,
        transform=ax.transAxes,
        ha="left",
        va="top",
        fontsize=11,
        fontweight="bold",
        color="#111111",
        zorder=30,
    )


def style_map_axis(ax: plt.Axes, tick_labels: bool = True) -> None:
    ax.set_xlabel("")
    ax.set_ylabel("")
    ax.tick_params(labelsize=8, length=2.5, color="#4D4D4D")
    if not tick_labels:
        ax.set_xticks([])
        ax.set_yticks([])
    for spine in ax.spines.values():
        spine.set_color("#4A4A4A")
        spine.set_linewidth(0.7)


def lon_formatter(x: float, _pos: int) -> str:
    return f"{int(x)}°E"


def lat_formatter(y: float, _pos: int) -> str:
    return f"{int(y)}°N"


def add_degree_ticks(ax: plt.Axes) -> None:
    ax.set_xticks([118, 120, 122])
    ax.set_yticks([27, 29, 31])
    ax.xaxis.set_major_formatter(FuncFormatter(lon_formatter))
    ax.yaxis.set_major_formatter(FuncFormatter(lat_formatter))
    ax.tick_params(
        axis="both",
        which="major",
        labelsize=8,
        pad=2,
        top=True,
        right=True,
        labeltop=True,
        labelright=True,
    )
    for side in ("top", "right", "bottom", "left"):
        ax.spines[side].set_visible(True)


def add_scale_bar(ax: plt.Axes, color: str = "white") -> None:
    x0, x1 = ax.get_xlim()
    y0, y1 = ax.get_ylim()
    bar_x = x0 + (x1 - x0) * 0.09
    bar_y = y0 + (y1 - y0) * 0.09
    length_deg = 0.9
    halo = [pe.withStroke(linewidth=2.2, foreground="black", alpha=0.55)]
    ax.plot([bar_x, bar_x + length_deg], [bar_y, bar_y], color=color, lw=1.6, zorder=25, path_effects=halo)
    ax.plot([bar_x, bar_x], [bar_y - 0.035, bar_y + 0.035], color=color, lw=1.1, zorder=25, path_effects=halo)
    ax.plot(
        [bar_x + length_deg, bar_x + length_deg],
        [bar_y - 0.035, bar_y + 0.035],
        color=color,
        lw=1.1,
        zorder=25,
        path_effects=halo,
    )
    ax.text(
        bar_x + length_deg / 2,
        bar_y + 0.055,
        "~80 km",
        ha="center",
        va="bottom",
        fontsize=8,
        color=color,
        zorder=25,
        path_effects=halo,
    )


def add_north_arrow(ax: plt.Axes) -> None:
    halo = [pe.withStroke(linewidth=2.4, foreground="black", alpha=0.55)]
    ax.annotate(
        "",
        xy=(0.925, 0.915),
        xytext=(0.925, 0.795),
        xycoords="axes fraction",
        arrowprops=dict(arrowstyle="-|>", color="white", lw=1.6, mutation_scale=13),
        zorder=30,
    )
    ax.text(
        0.925,
        0.94,
        "N",
        transform=ax.transAxes,
        ha="center",
        va="bottom",
        fontsize=9,
        fontweight="bold",
        color="white",
        zorder=30,
        path_effects=halo,
    )


def save_outputs(fig: plt.Figure, stem: Path) -> None:
    fig.savefig(stem.with_suffix(".svg"), bbox_inches="tight")
    fig.savefig(stem.with_suffix(".pdf"), bbox_inches="tight")
    fig.savefig(stem.with_suffix(".png"), dpi=600, bbox_inches="tight")
    fig.savefig(stem.with_suffix(".tiff"), dpi=600, bbox_inches="tight", pil_kwargs={"compression": "tiff_lzw"})


def main() -> None:
    missing = [str(p) for p in PATHS.values() if not p.exists()]
    if missing:
        raise FileNotFoundError("Missing required inputs:\n" + "\n".join(missing))

    FIG_DIR.mkdir(parents=True, exist_ok=True)
    DATA_DIR.mkdir(parents=True, exist_ok=True)

    china = gpd.read_file(PATHS["china_provinces"]).to_crs("EPSG:4326")
    china_lines = gpd.read_file(PATHS["china_lines"]).to_crs("EPSG:4326")
    cities = gpd.read_file(PATHS["zhejiang_cities"]).to_crs("EPSG:4326")
    zhejiang = cities.dissolve()
    zhejiang_boundary = zhejiang.boundary
    minx, miny, maxx, maxy = zhejiang.total_bounds
    map_center_x = (minx + maxx) / 2
    map_center_y = (miny + maxy) / 2
    map_span = max((maxx - minx) + 0.55, (maxy - miny) + 0.55)
    map_xlim = (map_center_x - map_span / 2, map_center_x + map_span / 2)
    map_ylim = (map_center_y - map_span / 2, map_center_y + map_span / 2)

    dem, pop, transform, crs = reproject_dem_to_population_grid(PATHS["dem"], PATHS["population"], zhejiang)
    extent = raster_extent(transform, pop)
    shade = hillshade(dem)
    city_pop = population_by_city(PATHS["population"], cities)
    city_pop.to_csv(DATA_DIR / "figure1_city_population_exposure.csv", index=False, encoding="utf-8-sig")

    dem_valid = dem[np.isfinite(dem)]
    pop_valid = pop[np.isfinite(pop) & (pop > 0)]
    dem_norm = mcolors.Normalize(vmin=np.nanpercentile(dem_valid, 2), vmax=np.nanpercentile(dem_valid, 98))
    pop_norm = mcolors.LogNorm(vmin=max(1, np.nanpercentile(pop_valid, 1)), vmax=np.nanpercentile(pop_valid, 99.6))

    fig = plt.figure(figsize=(7.2, 7.2), facecolor="white")

    # Four-panel left/right, top/bottom layout.
    panel = 0.365
    left_x = 0.070
    right_x = 0.565
    top_y = 0.575
    bottom_y = 0.115
    ax_a = fig.add_axes([left_x, top_y, panel, panel])
    ax_b = fig.add_axes([right_x, top_y, panel, panel])
    ax_c = fig.add_axes([left_x, bottom_y, panel, panel])
    ax_d = fig.add_axes([right_x, bottom_y, panel, panel])

    # a. Locator map.
    china_projected = china.to_crs(WEB_MERCATOR)
    china_lines_projected = china_lines.to_crs(WEB_MERCATOR)
    zhejiang_projected = china_projected[china_projected["gb"].astype(str) == "156330000"]
    minx_a, miny_a, maxx_a, maxy_a = china_projected.total_bounds
    center_x_a = (minx_a + maxx_a) / 2
    center_y_a = (miny_a + maxy_a) / 2
    span_a = max(maxx_a - minx_a, maxy_a - miny_a) * 1.04
    china_xlim = (center_x_a - span_a / 2, center_x_a + span_a / 2)
    china_ylim = (center_y_a - span_a / 2, center_y_a + span_a / 2)
    ax_a.set_xlim(*china_xlim)
    ax_a.set_ylim(*china_ylim)
    cx.add_basemap(ax_a, crs=WEB_MERCATOR, source=SATELLITE_TILES, zoom=4, attribution=False, reset_extent=False)
    china_projected.plot(ax=ax_a, facecolor=(1, 1, 1, 0.03), edgecolor="#E6E0D6", linewidth=0.42)
    china_lines_projected.plot(ax=ax_a, facecolor="none", edgecolor="#D8D2C8", linewidth=0.50)
    zhejiang_projected.plot(ax=ax_a, facecolor="#B84D42", edgecolor="#6D221E", linewidth=0.90, alpha=0.82)
    ax_a.set_xlim(*china_xlim)
    ax_a.set_ylim(*china_ylim)
    ax_a.set_aspect("equal", adjustable="box")
    ax_a.set_box_aspect(1)
    ax_a.set_xticks([])
    ax_a.set_yticks([])
    for spine in ax_a.spines.values():
        spine.set_visible(True)
        spine.set_color("#4A4A4A")
        spine.set_linewidth(0.7)
    add_panel_label(ax_a, "a", 0.01, 0.99)

    # b. Hero map: terrain as the base evidence, with city boundaries and direct labels.
    ax_b.set_xlim(*map_xlim)
    ax_b.set_ylim(*map_ylim)
    cx.add_basemap(ax_b, crs="EPSG:4326", source=SATELLITE_TILES, zoom=9, attribution=False, reset_extent=False)
    im_dem = ax_b.imshow(dem, extent=extent, cmap="terrain", norm=dem_norm, alpha=0.62, zorder=2)
    cities.boundary.plot(ax=ax_b, color="white", linewidth=0.90, alpha=0.90, zorder=4)
    cities.boundary.plot(ax=ax_b, color="#2A3032", linewidth=0.32, alpha=0.75, zorder=5)
    zhejiang_boundary.plot(ax=ax_b, color="#111111", linewidth=0.95, zorder=6)
    for name, (x, y) in CITY_LABELS.items():
        ax_b.text(
            x,
            y,
            name,
            fontsize=8.5,
            ha="center",
            va="center",
            color="#111111",
            path_effects=[pe.withStroke(linewidth=2.4, foreground="white", alpha=0.85)],
            zorder=10,
        )
    ax_b.text(
        118.72,
        28.04,
        "mountainous\nsouth",
        fontsize=8.2,
        ha="center",
        va="center",
        color="#222222",
        path_effects=[pe.withStroke(linewidth=2.2, foreground="white", alpha=0.72)],
        zorder=12,
    )
    ax_b.text(
        120.75,
        30.63,
        "northern urban belt",
        fontsize=8.2,
        ha="center",
        va="center",
        color="#222222",
        path_effects=[pe.withStroke(linewidth=2.2, foreground="white", alpha=0.72)],
        zorder=12,
    )
    ax_b.text(
        122.38,
        29.72,
        "islands",
        fontsize=8.0,
        ha="center",
        va="center",
        color="#222222",
        path_effects=[pe.withStroke(linewidth=2.0, foreground="white", alpha=0.76)],
        zorder=12,
    )
    add_scale_bar(ax_b, color="white")
    add_north_arrow(ax_b)
    ax_b.set_box_aspect(1)
    ax_b.set_aspect("equal", adjustable="box")
    add_panel_label(ax_b, "b", 0.01, 0.99)
    style_map_axis(ax_b)
    add_degree_ticks(ax_b)

    cax_dem = fig.add_axes([0.635, 0.535, 0.225, 0.012])
    cb_dem = fig.colorbar(im_dem, cax=cax_dem, orientation="horizontal")
    cb_dem.set_label("Elevation (m)", fontsize=8, labelpad=1)
    cb_dem.ax.tick_params(labelsize=7, length=2.5, pad=1)

    # c. Population exposure is a compact companion using the same footprint.
    ax_c.set_xlim(*map_xlim)
    ax_c.set_ylim(*map_ylim)
    cx.add_basemap(ax_c, crs="EPSG:4326", source=SATELLITE_TILES, zoom=9, attribution=False, reset_extent=False)
    im_pop = ax_c.imshow(pop, extent=extent, cmap="magma_r", norm=pop_norm, alpha=0.78, zorder=2)
    zhejiang_boundary.plot(ax=ax_c, color="#111111", linewidth=0.62, zorder=4)
    cities.boundary.plot(ax=ax_c, color="#3C3C3C", linewidth=0.22, alpha=0.65, zorder=5)
    add_scale_bar(ax_c, color="white")
    add_north_arrow(ax_c)
    ax_c.set_box_aspect(1)
    ax_c.set_aspect("equal", adjustable="box")
    add_panel_label(ax_c, "c", 0.015, 0.985)
    style_map_axis(ax_c)
    add_degree_ticks(ax_c)

    cax_pop = fig.add_axes([0.140, 0.075, 0.225, 0.012])
    cb_pop = fig.colorbar(im_pop, cax=cax_pop, orientation="horizontal")
    cb_pop.set_label("Population per grid cell", fontsize=8, labelpad=1)
    cb_pop.ax.tick_params(labelsize=7, length=2.5)

    # d. Quantitative support: compact horizontal bars.
    bar_colors = np.where(city_pop["setting"] == "Northern/coastal", "#B84D42", "#6F8B70")
    ax_d.barh(
        city_pop["City_display"],
        city_pop["population"] / 1e6,
        color=bar_colors,
        edgecolor="#333333",
        linewidth=0.32,
        height=0.72,
    )
    ax_d.set_xlabel("Population (million)", fontsize=8.5)
    ax_d.grid(axis="x", color="#D7D7D7", linewidth=0.45)
    ax_d.tick_params(axis="y", labelsize=8.0, length=0)
    ax_d.tick_params(axis="x", labelsize=8.0, length=2.5)
    ax_d.set_xlim(0, max(city_pop["population"] / 1e6) * 1.08)
    add_panel_label(ax_d, "d", -0.11, 1.02)
    legend_handles = [
        Rectangle((0, 0), 1, 1, facecolor="#B84D42", edgecolor="#333333", label="Northern/coastal"),
        Rectangle((0, 0), 1, 1, facecolor="#6F8B70", edgecolor="#333333", label="Interior/mountain"),
    ]
    ax_d.legend(handles=legend_handles, loc="lower right", fontsize=7.2, handlelength=1.4, borderaxespad=0.2)

    stem = FIG_DIR / "Figure1_study_area_population_geographic_setting"
    save_outputs(fig, stem)
    plt.close(fig)

    audit = {
        "figure": "Figure 1. Study area, population exposure, and geographic setting",
        "core_conclusion": (
            "Zhejiang's healthcare-accessibility setting is heterogeneous: northern/coastal "
            "population concentration, southern mountain terrain, and island settlements frame "
            "the accessibility analysis."
        ),
        "archetype": "balanced four-panel geographic setting figure",
        "panel_map": {
            "a": "China locator map",
            "b": "Hero DEM and prefecture-boundary map",
            "c": "WorldPop population exposure grid",
            "d": "City population exposure bars",
        },
        "inputs": {k: str(v) for k, v in PATHS.items()},
        "outputs": {
            "svg": str(stem.with_suffix(".svg")),
            "pdf": str(stem.with_suffix(".pdf")),
            "png": str(stem.with_suffix(".png")),
            "tiff": str(stem.with_suffix(".tiff")),
            "source_data": str(DATA_DIR / "figure1_city_population_exposure.csv"),
        },
    }
    (DATA_DIR / "figure1_geographic_setting_audit.json").write_text(
        json.dumps(audit, indent=2, ensure_ascii=False), encoding="utf-8"
    )


if __name__ == "__main__":
    main()


