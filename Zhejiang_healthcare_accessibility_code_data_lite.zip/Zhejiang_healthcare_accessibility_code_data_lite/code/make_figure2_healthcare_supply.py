﻿from __future__ import annotations

import json
from pathlib import Path

import contextily as cx
import geopandas as gpd
import matplotlib as mpl
import matplotlib.patheffects as pe
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.patches import Rectangle
from matplotlib.ticker import FuncFormatter
from matplotlib.transforms import blended_transform_factory


BASE = Path("data_external/healthcare_zj")
PROJECT_OUT = Path("outputs")
FIG_DIR = PROJECT_OUT / "figures"
DATA_DIR = PROJECT_OUT / "data"

PATHS = {
    "zhejiang_cities": BASE / "datasets1" / "zj_cities.shp",
    "primary_facilities": BASE / "zj_L1.shp",
    "secondary_facilities": BASE / "zj_L2.shp",
    "tertiary_facilities": BASE / "zj_L3.shp",
    "city_population": DATA_DIR / "figure1_city_population_exposure.csv",
}

SATELLITE_TILES = cx.providers.Esri.WorldImagery
DISPLAY_CITY = {"Jiaxin": "Jiaxing"}
BASEMAP_AVAILABLE = True

TIERS = {
    "primary": {
        "path_key": "primary_facilities",
        "label": "Primary",
        "color": "#2D7FA3",
        "markersize": 1.05,
        "alpha": 0.40,
    },
    "secondary": {
        "path_key": "secondary_facilities",
        "label": "Secondary",
        "color": "#C67A30",
        "markersize": 1.35,
        "alpha": 0.48,
    },
    "tertiary": {
        "path_key": "tertiary_facilities",
        "label": "Tertiary",
        "color": "#B33A3A",
        "markersize": 3.2,
        "alpha": 0.78,
    },
}


mpl.rcParams.update(
    {
        "font.family": "sans-serif",
        "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans", "sans-serif"],
        "svg.fonttype": "none",
        "pdf.fonttype": 42,
        "font.size": 9,
        "axes.spines.right": False,
        "axes.spines.top": False,
        "axes.linewidth": 0.75,
        "legend.frameon": False,
        "xtick.major.width": 0.65,
        "ytick.major.width": 0.65,
    }
)


def add_panel_label(ax: plt.Axes, label: str, x: float = 0.01, y: float = 0.99) -> None:
    ax.text(
        x,
        y,
        label,
        transform=ax.transAxes,
        ha="left",
        va="top",
        fontsize=11,
        fontweight="bold",
        color="#111111",
        zorder=30,
    )


def lon_formatter(x: float, _pos: int) -> str:
    return f"{int(x)}°E"


def lat_formatter(y: float, _pos: int) -> str:
    return f"{int(y)}°N"


def add_degree_ticks(ax: plt.Axes) -> None:
    ax.set_xticks([118, 120, 122])
    ax.set_yticks([27, 29, 31])
    ax.xaxis.set_major_formatter(FuncFormatter(lon_formatter))
    ax.yaxis.set_major_formatter(FuncFormatter(lat_formatter))
    ax.tick_params(
        axis="both",
        which="major",
        labelsize=8,
        pad=2,
        top=True,
        right=True,
        labeltop=True,
        labelright=True,
        length=2.5,
        color="#4D4D4D",
    )
    for side in ("top", "right", "bottom", "left"):
        ax.spines[side].set_visible(True)
        ax.spines[side].set_color("#4A4A4A")
        ax.spines[side].set_linewidth(0.7)


def add_scale_bar(ax: plt.Axes, color: str = "white") -> None:
    x0, x1 = ax.get_xlim()
    y0, y1 = ax.get_ylim()
    bar_x = x0 + (x1 - x0) * 0.09
    bar_y = y0 + (y1 - y0) * 0.09
    length_deg = 0.9
    halo = [pe.withStroke(linewidth=2.2, foreground="black", alpha=0.55)]
    ax.plot([bar_x, bar_x + length_deg], [bar_y, bar_y], color=color, lw=1.6, zorder=25, path_effects=halo)
    ax.plot([bar_x, bar_x], [bar_y - 0.035, bar_y + 0.035], color=color, lw=1.1, zorder=25, path_effects=halo)
    ax.plot(
        [bar_x + length_deg, bar_x + length_deg],
        [bar_y - 0.035, bar_y + 0.035],
        color=color,
        lw=1.1,
        zorder=25,
        path_effects=halo,
    )
    ax.text(
        bar_x + length_deg / 2,
        bar_y + 0.055,
        "~80 km",
        ha="center",
        va="bottom",
        fontsize=8,
        color=color,
        zorder=25,
        path_effects=halo,
    )


def add_north_arrow(ax: plt.Axes) -> None:
    halo = [pe.withStroke(linewidth=2.4, foreground="black", alpha=0.55)]
    ax.annotate(
        "",
        xy=(0.92, 0.90),
        xytext=(0.92, 0.80),
        xycoords=ax.transAxes,
        arrowprops=dict(arrowstyle="-|>", color="white", lw=1.6, mutation_scale=13, path_effects=halo),
        zorder=28,
    )
    ax.text(
        0.92,
        0.925,
        "N",
        transform=ax.transAxes,
        ha="center",
        va="bottom",
        fontsize=8.5,
        fontweight="bold",
        color="white",
        path_effects=halo,
        zorder=28,
    )


def square_extent(bounds: np.ndarray, pad: float = 0.42) -> tuple[tuple[float, float], tuple[float, float]]:
    minx, miny, maxx, maxy = bounds
    minx -= pad
    maxx += pad
    miny -= pad
    maxy += pad
    cx0 = (minx + maxx) / 2
    cy0 = (miny + maxy) / 2
    span = max(maxx - minx, maxy - miny)
    return (cx0 - span / 2, cx0 + span / 2), (cy0 - span / 2, cy0 + span / 2)


def read_facilities(path: Path, zhejiang: gpd.GeoDataFrame) -> gpd.GeoDataFrame:
    gdf = gpd.read_file(path)
    if gdf.crs is None:
        gdf = gdf.set_crs("EPSG:4326")
    gdf = gdf.to_crs("EPSG:4326")
    gdf = gdf[gdf.geometry.notna() & ~gdf.geometry.is_empty].copy()
    return gpd.sjoin(gdf, zhejiang[["geometry"]], predicate="within", how="inner").drop(columns=["index_right"])


def city_supply_table(facilities: dict[str, gpd.GeoDataFrame], cities: gpd.GeoDataFrame) -> pd.DataFrame:
    rows = []
    for tier, gdf in facilities.items():
        joined = gpd.sjoin(
            gdf[["geometry"]],
            cities[["City_name", "geometry"]],
            predicate="within",
            how="inner",
        )
        counts = joined["City_name"].value_counts()
        for city, count in counts.items():
            rows.append({"City": city, "tier": tier, "count": int(count)})

    tier_counts = (
        pd.DataFrame(rows)
        .pivot_table(index="City", columns="tier", values="count", aggfunc="sum", fill_value=0)
        .reset_index()
    )
    all_cities = cities[["City_name"]].rename(columns={"City_name": "City"}).drop_duplicates()
    tier_counts = all_cities.merge(tier_counts, on="City", how="left").fillna(0)
    for tier in TIERS:
        if tier not in tier_counts.columns:
            tier_counts[tier] = 0
        tier_counts[tier] = tier_counts[tier].astype(int)

    pop = pd.read_csv(PATHS["city_population"])
    table = tier_counts.merge(pop[["City", "population"]], on="City", how="left")
    table["City_display"] = table["City"].replace(DISPLAY_CITY)
    table["total_count"] = table[["primary", "secondary", "tertiary"]].sum(axis=1)
    table["facilities_per_10k"] = table["total_count"] / table["population"] * 10000
    table["tertiary_share_pct"] = np.where(table["total_count"] > 0, table["tertiary"] / table["total_count"] * 100, 0)
    table = table.sort_values(["tertiary", "total_count"], ascending=[True, True])
    return table


def plot_supply_map(
    ax: plt.Axes,
    facilities: gpd.GeoDataFrame,
    cities: gpd.GeoDataFrame,
    boundary: gpd.GeoDataFrame,
    map_xlim: tuple[float, float],
    map_ylim: tuple[float, float],
    tier_cfg: dict[str, object],
) -> None:
    global BASEMAP_AVAILABLE
    ax.set_xlim(*map_xlim)
    ax.set_ylim(*map_ylim)
    if BASEMAP_AVAILABLE:
        try:
            cx.add_basemap(ax, crs="EPSG:4326", source=SATELLITE_TILES, zoom=8, attribution=False, reset_extent=False)
        except Exception:
            BASEMAP_AVAILABLE = False
            ax.set_facecolor("#E8E3D6")
    else:
        ax.set_facecolor("#E8E3D6")
    ax.add_patch(
        Rectangle(
            (map_xlim[0], map_ylim[0]),
            map_xlim[1] - map_xlim[0],
            map_ylim[1] - map_ylim[0],
            facecolor="white",
            alpha=0.22,
            edgecolor="none",
            zorder=1,
        )
    )
    cities.boundary.plot(ax=ax, color="white", linewidth=0.80, alpha=0.88, zorder=3)
    cities.boundary.plot(ax=ax, color="#2F3335", linewidth=0.25, alpha=0.70, zorder=4)
    boundary.plot(ax=ax, color="#111111", linewidth=0.70, alpha=0.90, zorder=5)
    facilities.plot(
        ax=ax,
        markersize=float(tier_cfg["markersize"]),
        color=str(tier_cfg["color"]),
        alpha=float(tier_cfg["alpha"]),
        linewidth=0,
        zorder=8,
    )
    if ax.collections:
        ax.collections[-1].set_rasterized(True)
    ax.set_xlim(*map_xlim)
    ax.set_ylim(*map_ylim)
    ax.set_aspect("equal", adjustable="box")
    ax.set_box_aspect(1)
    add_scale_bar(ax, color="white")
    add_north_arrow(ax)
    add_degree_ticks(ax)
    ax.set_xlabel("")
    ax.set_ylabel("")


def plot_city_panel(ax: plt.Axes, table: pd.DataFrame) -> None:
    y = np.arange(len(table))
    left = np.zeros(len(table))
    colors = {tier: str(cfg["color"]) for tier, cfg in TIERS.items()}
    labels = {"primary": "Primary", "secondary": "Secondary", "tertiary": "Tertiary"}

    for tier in ("primary", "secondary", "tertiary"):
        values = table[tier].to_numpy()
        ax.barh(
            y,
            values,
            left=left,
            height=0.70,
            color=colors[tier],
            edgecolor="white",
            linewidth=0.32,
            label=labels[tier],
        )
        left += values

    ax.set_yticks(y)
    ax.set_yticklabels(table["City_display"], fontsize=8)
    ax.tick_params(axis="y", length=0)
    ax.tick_params(axis="x", labelsize=8, length=2.5)
    ax.grid(axis="x", color="#D9D9D9", linewidth=0.45)
    ax.set_xlabel("Facilities (count)", fontsize=8.5)
    ax.set_xlim(0, table["total_count"].max() * 1.86)
    ax.spines["right"].set_visible(False)
    ax.spines["top"].set_visible(False)

    trans = blended_transform_factory(ax.transAxes, ax.transData)
    for yi, (_, row) in zip(y, table.iterrows()):
        ax.text(
            0.72,
            yi,
            f"{row['facilities_per_10k']:.1f}",
            transform=trans,
            ha="center",
            va="center",
            fontsize=7.6,
            color="#222222",
        )
        ax.text(
            0.91,
            yi,
            f"{row['tertiary_share_pct']:.1f}",
            transform=trans,
            ha="center",
            va="center",
            fontsize=7.6,
            color="#222222",
        )

    ax.text(0.72, 1.02, "per 10k", transform=ax.transAxes, ha="center", va="bottom", fontsize=7.4)
    ax.text(0.91, 1.02, "tertiary %", transform=ax.transAxes, ha="center", va="bottom", fontsize=7.4)
    ax.legend(
        loc="upper left",
        bbox_to_anchor=(0.00, 1.12),
        fontsize=7.1,
        ncol=3,
        handlelength=1.2,
        borderaxespad=0.20,
        columnspacing=0.85,
        labelspacing=0.30,
    )


def save_outputs(fig: plt.Figure, stem: Path) -> None:
    stem.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(stem.with_suffix(".svg"), bbox_inches="tight")
    fig.savefig(stem.with_suffix(".pdf"), bbox_inches="tight")
    fig.savefig(stem.with_suffix(".png"), dpi=600, bbox_inches="tight")
    fig.savefig(stem.with_suffix(".tiff"), dpi=600, bbox_inches="tight")


def main() -> None:
    FIG_DIR.mkdir(parents=True, exist_ok=True)
    DATA_DIR.mkdir(parents=True, exist_ok=True)

    cities = gpd.read_file(PATHS["zhejiang_cities"]).to_crs("EPSG:4326")
    zhejiang = gpd.GeoDataFrame(geometry=[cities.geometry.unary_union], crs=cities.crs)
    zhejiang_boundary = zhejiang.boundary
    map_xlim, map_ylim = square_extent(cities.total_bounds, pad=0.36)

    facilities = {
        tier: read_facilities(PATHS[cfg["path_key"]], zhejiang)
        for tier, cfg in TIERS.items()
    }
    city_table = city_supply_table(facilities, cities)
    source_csv = DATA_DIR / "figure2_city_healthcare_supply.csv"
    city_table.to_csv(source_csv, index=False, encoding="utf-8-sig")

    fig = plt.figure(figsize=(7.2, 7.2), constrained_layout=False)
    panel = 0.365
    left_x = 0.070
    right_x = 0.565
    top_y = 0.575
    bottom_y = 0.115
    ax_a = fig.add_axes([left_x, top_y, panel, panel])
    ax_b = fig.add_axes([right_x, top_y, panel, panel])
    ax_c = fig.add_axes([left_x, bottom_y, panel, panel])
    ax_d = fig.add_axes([right_x, bottom_y, panel, panel])

    for ax, tier, label in [
        (ax_a, "primary", "a"),
        (ax_b, "secondary", "b"),
        (ax_c, "tertiary", "c"),
    ]:
        plot_supply_map(
            ax,
            facilities[tier],
            cities,
            zhejiang_boundary,
            map_xlim,
            map_ylim,
            TIERS[tier],
        )
        add_panel_label(ax, label)
        ax.text(
            0.96,
            0.055,
            f"{TIERS[tier]['label']} n={len(facilities[tier]):,}",
            transform=ax.transAxes,
            ha="right",
            va="bottom",
            fontsize=8.0,
            color="white",
            path_effects=[pe.withStroke(linewidth=2.2, foreground="black", alpha=0.58)],
            zorder=28,
        )

    plot_city_panel(ax_d, city_table)
    add_panel_label(ax_d, "d", -0.11, 1.02)

    stem = FIG_DIR / "Figure2_healthcare_facility_hierarchy_supply"
    save_outputs(fig, stem)
    plt.close(fig)

    raw_counts = {tier: int(len(gpd.read_file(PATHS[cfg["path_key"]]))) for tier, cfg in TIERS.items()}
    plotted_counts = {tier: int(len(gdf)) for tier, gdf in facilities.items()}
    audit = {
        "figure": "Figure 2. Spatial distribution and hierarchy of healthcare facilities",
        "core_conclusion": (
            "Healthcare supply in Zhejiang is hierarchical: primary facilities are widespread, "
            "secondary facilities strengthen the urban corridor, and tertiary facilities are "
            "spatially concentrated in major cities."
        ),
        "archetype": "quantitative grid with three map panels and one city-level supply panel",
        "panel_map": {
            "a": "Primary facility distribution",
            "b": "Secondary facility distribution",
            "c": "Tertiary facility distribution",
            "d": "City-level facility counts, facilities per 10,000 people, and tertiary share",
        },
        "inputs": {k: str(v) for k, v in PATHS.items()},
        "counts": {
            "raw_layer_counts": raw_counts,
            "plotted_within_zhejiang_counts": plotted_counts,
            "raw_total": int(sum(raw_counts.values())),
            "plotted_total": int(sum(plotted_counts.values())),
            "manuscript_total_to_reconcile": 20759,
            "note": (
                "The supplied tier shapefiles sum to 20,761 rows. The manuscript total "
                "is 20,759; reconcile against the final cleaned facility list if available."
            ),
        },
        "outputs": {
            "svg": str(stem.with_suffix(".svg")),
            "pdf": str(stem.with_suffix(".pdf")),
            "png": str(stem.with_suffix(".png")),
            "tiff": str(stem.with_suffix(".tiff")),
            "source_data": str(source_csv),
        },
    }
    (DATA_DIR / "figure2_healthcare_supply_audit.json").write_text(
        json.dumps(audit, indent=2, ensure_ascii=False), encoding="utf-8"
    )


if __name__ == "__main__":
    main()


