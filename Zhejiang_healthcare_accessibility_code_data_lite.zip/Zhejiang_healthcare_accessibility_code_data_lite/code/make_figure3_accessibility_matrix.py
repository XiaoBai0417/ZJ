﻿from __future__ import annotations

import json
from pathlib import Path

import geopandas as gpd
import matplotlib as mpl
import matplotlib.colors as mcolors
import matplotlib.patheffects as pe
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import rasterio
from rasterio import features
from rasterio.enums import Resampling
from rasterio.warp import calculate_default_transform, reproject


BASE = Path("data_external/datasets1")
PROJECT_OUT = Path("outputs")
FIG_DIR = PROJECT_OUT / "figures"
DATA_DIR = PROJECT_OUT / "data"

WEB_MERCATOR = "EPSG:3857"

PATHS = {
    "cities": BASE / "zj_cities.shp",
    "population": BASE / "ZJ_pop.tif",
    "drive_l1": BASE / "level1_drive.tif",
    "drive_l2": BASE / "level2_drive.tif",
    "drive_l3": BASE / "level3_drive.tif",
    "transit_l1": BASE / "level1_transit.tif",
    "transit_l2": BASE / "level2_transit.tif",
    "transit_l3": BASE / "level3_transit.tif",
    "walk_l1": BASE / "level1_walk.tif",
    "walk_l2": BASE / "level2_walk.tif",
    "walk_l3": BASE / "level3_walk.tif",
    "main_table2": PROJECT_OUT / "tables" / "MainTable2_mode_tier_accessibility_inequality.csv",
}

MODES = [
    ("drive", "Driving"),
    ("transit", "Public transit"),
    ("walk", "Walking"),
]
TIERS = [
    ("l1", "Primary"),
    ("l2", "Secondary"),
    ("l3", "Tertiary"),
]

TIME_BOUNDS = [0, 15, 30, 45, 60, 90, 120, 180, 240, 360, 600, 900]


mpl.rcParams.update(
    {
        "font.family": "sans-serif",
        "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans", "sans-serif"],
        "svg.fonttype": "none",
        "pdf.fonttype": 42,
        "font.size": 8,
        "axes.linewidth": 0.65,
        "axes.spines.right": False,
        "axes.spines.top": False,
        "legend.frameon": False,
        "xtick.major.width": 0.55,
        "ytick.major.width": 0.55,
    }
)


def clean_time(arr: np.ndarray, nodata: float | int | None) -> np.ndarray:
    arr = arr.astype("float32", copy=False)
    if nodata is not None and np.isfinite(nodata):
        arr = np.where(arr == nodata, np.nan, arr)
    arr = np.where((arr <= 0) | (arr > 3000) | ~np.isfinite(arr), np.nan, arr)
    return arr


def masked_time(arr: np.ndarray) -> np.ma.MaskedArray:
    return np.ma.masked_invalid(arr)


def clean_population(arr: np.ndarray, nodata: float | int | None) -> np.ndarray:
    arr = arr.astype("float32", copy=False)
    if nodata is not None and np.isfinite(nodata):
        arr = np.where(arr == nodata, 0, arr)
    return np.where((arr > 0) & np.isfinite(arr), arr, 0)


def raster_extent(transform: rasterio.Affine, width: int, height: int) -> tuple[float, float, float, float]:
    left = transform.c
    top = transform.f
    right = left + transform.a * width
    bottom = top + transform.e * height
    return left, right, bottom, top


def destination_grid(reference_path: Path) -> tuple[rasterio.Affine, int, int]:
    with rasterio.open(reference_path) as src:
        transform, width, height = calculate_default_transform(
            src.crs,
            WEB_MERCATOR,
            src.width,
            src.height,
            *src.bounds,
        )
    return transform, width, height


def reproject_array(
    arr: np.ndarray,
    src_transform: rasterio.Affine,
    src_crs,
    dst_transform: rasterio.Affine,
    dst_width: int,
    dst_height: int,
    resampling: Resampling,
) -> np.ndarray:
    dst = np.full((dst_height, dst_width), np.nan, dtype="float32")
    reproject(
        source=arr,
        destination=dst,
        src_transform=src_transform,
        src_crs=src_crs,
        src_nodata=np.nan,
        dst_transform=dst_transform,
        dst_crs=WEB_MERCATOR,
        dst_nodata=np.nan,
        resampling=resampling,
    )
    return dst


def read_projected_time(
    path: Path,
    mask_geom,
    dst_transform: rasterio.Affine,
    dst_width: int,
    dst_height: int,
) -> tuple[np.ndarray, np.ndarray, dict[str, float]]:
    with rasterio.open(path) as src:
        arr = clean_time(src.read(1), src.nodata)
        inside = features.geometry_mask(
            mask_geom,
            out_shape=arr.shape,
            transform=src.transform,
            invert=True,
            all_touched=True,
        )
        arr = np.where(inside, arr, np.nan)
        projected = reproject_array(
            arr,
            src.transform,
            src.crs,
            dst_transform,
            dst_width,
            dst_height,
            Resampling.bilinear,
        )
    projected = np.where((projected > 0) & (projected <= 3000), projected, np.nan)
    finite = projected[np.isfinite(projected)]
    stats = {
        "valid_cells": int(finite.size),
        "median": float(np.nanmedian(finite)) if finite.size else np.nan,
        "p90": float(np.nanpercentile(finite, 90)) if finite.size else np.nan,
        "p95": float(np.nanpercentile(finite, 95)) if finite.size else np.nan,
        "p99": float(np.nanpercentile(finite, 99)) if finite.size else np.nan,
    }
    return projected, inside, stats


def population_weighted_time(path: Path, pop_path: Path, mask_geom) -> tuple[float, float]:
    with rasterio.open(pop_path) as pop_src:
        pop = clean_population(pop_src.read(1), pop_src.nodata)
        pop_transform = pop_src.transform
        pop_crs = pop_src.crs

    with rasterio.open(path) as src:
        arr = clean_time(src.read(1), src.nodata)
        inside = features.geometry_mask(
            mask_geom,
            out_shape=arr.shape,
            transform=src.transform,
            invert=True,
            all_touched=True,
        )
        arr = np.where(inside, arr, np.nan)
        if pop.shape == arr.shape and pop_transform == src.transform and pop_crs == src.crs:
            pop_match = pop
        else:
            pop_match = np.zeros(arr.shape, dtype="float32")
            reproject(
                source=pop,
                destination=pop_match,
                src_transform=pop_transform,
                src_crs=pop_crs,
                src_nodata=0,
                dst_transform=src.transform,
                dst_crs=src.crs,
                dst_nodata=0,
                resampling=Resampling.bilinear,
            )
    valid = np.isfinite(arr) & np.isfinite(pop_match) & (pop_match > 0)
    if not valid.any():
        return np.nan, 0
    return float(np.average(arr[valid], weights=pop_match[valid])), float(pop_match[valid].sum())


def add_column_headers(fig: plt.Figure, axes: np.ndarray) -> None:
    for j, (_, label) in enumerate(TIERS):
        pos = axes[0, j].get_position()
        fig.text(
            (pos.x0 + pos.x1) / 2,
            pos.y1 + 0.016,
            label,
            ha="center",
            va="bottom",
            fontsize=10,
            fontweight="bold",
            color="#222222",
        )


def add_row_headers(fig: plt.Figure, axes: np.ndarray) -> None:
    for i, (_, label) in enumerate(MODES):
        pos = axes[i, 0].get_position()
        fig.text(
            pos.x0 - 0.035,
            (pos.y0 + pos.y1) / 2,
            label,
            ha="right",
            va="center",
            rotation=90,
            fontsize=10,
            fontweight="bold",
            color="#222222",
        )


def add_panel_label(ax: plt.Axes, label: str) -> None:
    ax.text(
        0.02,
        0.98,
        label,
        transform=ax.transAxes,
        ha="left",
        va="top",
        fontsize=9,
        fontweight="bold",
        color="#222222",
        zorder=20,
        path_effects=[pe.withStroke(linewidth=2.4, foreground="white", alpha=0.80)],
    )


def style_map_axis(ax: plt.Axes) -> None:
    ax.set_xticks([])
    ax.set_yticks([])
    for spine in ax.spines.values():
        spine.set_visible(True)
        spine.set_color("#4A4A4A")
        spine.set_linewidth(0.62)
    ax.set_aspect("equal", adjustable="box")


def plot_matrix() -> None:
    FIG_DIR.mkdir(parents=True, exist_ok=True)
    DATA_DIR.mkdir(parents=True, exist_ok=True)

    cities = gpd.read_file(PATHS["cities"]).to_crs("EPSG:4326")
    zhejiang_geom = [cities.geometry.unary_union]
    cities_projected = cities.to_crs(WEB_MERCATOR)

    dst_transform, dst_width, dst_height = destination_grid(PATHS["drive_l1"])
    extent = raster_extent(dst_transform, dst_width, dst_height)

    cmap = mpl.colormaps["YlOrRd"].copy()
    cmap.set_bad((1, 1, 1, 0))
    cmap.set_over("#5E1416")
    norm = mcolors.BoundaryNorm(TIME_BOUNDS, ncolors=cmap.N, extend="max")

    arrays: dict[str, np.ndarray] = {}
    rows = []
    for mode, mode_label in MODES:
        for tier, tier_label in TIERS:
            key = f"{mode}_{tier}"
            arr, _mask, stats = read_projected_time(
                PATHS[key],
                zhejiang_geom,
                dst_transform,
                dst_width,
                dst_height,
            )
            pwtt, pop_valid = population_weighted_time(PATHS[key], PATHS["population"], zhejiang_geom)
            arrays[key] = arr
            rows.append(
                {
                    "mode": mode_label,
                    "tier": tier_label,
                    "key": key,
                    "pwtt_min": pwtt,
                    "population_valid": pop_valid,
                    **stats,
                }
            )

    metrics = pd.DataFrame(rows)
    if PATHS["main_table2"].exists():
        table_pwtt = pd.read_csv(PATHS["main_table2"])
        table_pwtt["mode"] = table_pwtt["mode"].replace({"Transit": "Public transit"})
        table_pwtt = table_pwtt[["mode", "tier", "pwtt"]].rename(columns={"pwtt": "table_pwtt_min"})
        metrics = metrics.merge(table_pwtt, on=["mode", "tier"], how="left")
        metrics["label_pwtt_min"] = metrics["table_pwtt_min"].fillna(metrics["pwtt_min"])
    else:
        metrics["label_pwtt_min"] = metrics["pwtt_min"]
    metrics.to_csv(DATA_DIR / "figure3_accessibility_matrix_metrics.csv", index=False, encoding="utf-8-sig")

    fig, axes = plt.subplots(3, 3, figsize=(7.6, 8.1), constrained_layout=False)
    plt.subplots_adjust(left=0.105, right=0.965, top=0.925, bottom=0.115, wspace=0.035, hspace=0.035)

    last_im = None
    panel = 0
    for i, (mode, _mode_label) in enumerate(MODES):
        for j, (tier, _tier_label) in enumerate(TIERS):
            ax = axes[i, j]
            key = f"{mode}_{tier}"
            arr = arrays[key]
            ax.set_facecolor("#F7F7F4")
            cities_projected.plot(
                ax=ax,
                facecolor="#D9D9D9",
                edgecolor="none",
                alpha=0.82,
                zorder=0,
            )
            last_im = ax.imshow(
                masked_time(arr),
                extent=extent,
                origin="upper",
                cmap=cmap,
                norm=norm,
                interpolation="nearest",
                zorder=1,
            )
            cities_projected.boundary.plot(ax=ax, color="white", linewidth=0.58, alpha=0.88, zorder=3)
            cities_projected.boundary.plot(ax=ax, color="#222222", linewidth=0.18, alpha=0.70, zorder=4)
            style_map_axis(ax)
            add_panel_label(ax, chr(97 + panel))
            row = metrics.loc[metrics["key"] == key].iloc[0]
            ax.text(
                0.96,
                0.045,
                f"PWTT {row['label_pwtt_min']:.1f} min",
                transform=ax.transAxes,
                ha="right",
                va="bottom",
                fontsize=7.4,
                color="#222222",
                zorder=12,
                path_effects=[pe.withStroke(linewidth=2.8, foreground="white", alpha=0.82)],
            )
            panel += 1

    add_column_headers(fig, axes)
    add_row_headers(fig, axes)
    if last_im is not None:
        cax = fig.add_axes([0.18, 0.055, 0.68, 0.018])
        cbar = fig.colorbar(last_im, cax=cax, orientation="horizontal", extend="max")
        cbar.set_label("Travel time to nearest facility (minutes)", fontsize=9, labelpad=2)
        cbar.set_ticks([0, 30, 60, 120, 240, 600, 900])
        cbar.ax.tick_params(labelsize=8, length=2.5, pad=1)
        cbar.outline.set_linewidth(0.45)

    stem = FIG_DIR / "Figure3_mode_tier_accessibility_matrix"
    fig.savefig(stem.with_suffix(".svg"), bbox_inches="tight")
    fig.savefig(stem.with_suffix(".pdf"), bbox_inches="tight")
    fig.savefig(stem.with_suffix(".png"), dpi=600, bbox_inches="tight")
    fig.savefig(stem.with_suffix(".tiff"), dpi=600, bbox_inches="tight", pil_kwargs={"compression": "tiff_lzw"})
    plt.close(fig)

    audit = {
        "figure": "Figure 3. The 3 x 3 accessibility matrix",
        "title": "Spatial patterns of healthcare travel time across travel modes and hospital tiers",
        "core_conclusion": (
            "Driving compresses healthcare travel-time burdens, whereas public transit and walking "
            "substantially expand travel times, especially for tertiary care."
        ),
        "archetype": "quantitative grid",
        "projection": WEB_MERCATOR,
        "color_scale_minutes": TIME_BOUNDS,
        "inputs": {k: str(v) for k, v in PATHS.items()},
        "outputs": {
            "svg": str(stem.with_suffix(".svg")),
            "pdf": str(stem.with_suffix(".pdf")),
            "png": str(stem.with_suffix(".png")),
            "tiff": str(stem.with_suffix(".tiff")),
            "source_metrics": str(DATA_DIR / "figure3_accessibility_matrix_metrics.csv"),
        },
    }
    (DATA_DIR / "figure3_accessibility_matrix_audit.json").write_text(
        json.dumps(audit, indent=2, ensure_ascii=False), encoding="utf-8"
    )


if __name__ == "__main__":
    plot_matrix()


