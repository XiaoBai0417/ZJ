﻿from __future__ import annotations

import json
from pathlib import Path

import geopandas as gpd
import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import rasterio
from matplotlib.patches import Rectangle
from rasterio import features
from rasterio.enums import Resampling
from rasterio.warp import reproject


BASE = Path("data_external/datasets1")
PROJECT_OUT = Path("outputs")
FIG_DIR = PROJECT_OUT / "figures"
DATA_DIR = PROJECT_OUT / "data"

PATHS = {
    "cities": BASE / "zj_cities.shp",
    "population": BASE / "ZJ_pop.tif",
    "main_table2": PROJECT_OUT / "tables" / "MainTable2_mode_tier_accessibility_inequality.csv",
    "drive_l1": BASE / "level1_drive.tif",
    "drive_l2": BASE / "level2_drive.tif",
    "drive_l3": BASE / "level3_drive.tif",
    "transit_l1": BASE / "level1_transit.tif",
    "transit_l2": BASE / "level2_transit.tif",
    "transit_l3": BASE / "level3_transit.tif",
    "walk_l1": BASE / "level1_walk.tif",
    "walk_l2": BASE / "level2_walk.tif",
    "walk_l3": BASE / "level3_walk.tif",
}

MODES = [
    ("drive", "Driving"),
    ("transit", "Public transit"),
    ("walk", "Walking"),
]
TIERS = [
    ("l1", "Primary"),
    ("l2", "Secondary"),
    ("l3", "Tertiary"),
]
MODE_COLORS = {
    "Driving": "#3E6EA8",
    "Public transit": "#D18A2D",
    "Walking": "#B9403A",
}
DISPLAY_CITY = {"Jiaxin": "Jiaxing"}


mpl.rcParams.update(
    {
        "font.family": "sans-serif",
        "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans", "sans-serif"],
        "svg.fonttype": "none",
        "pdf.fonttype": 42,
        "font.size": 8,
        "axes.linewidth": 0.7,
        "axes.spines.right": False,
        "axes.spines.top": False,
        "legend.frameon": False,
        "xtick.major.width": 0.6,
        "ytick.major.width": 0.6,
    }
)


def clean_time(arr: np.ndarray, nodata: float | int | None) -> np.ndarray:
    arr = arr.astype("float32", copy=False)
    if nodata is not None and np.isfinite(nodata):
        arr = np.where(arr == nodata, np.nan, arr)
    return np.where((arr > 0) & (arr <= 3000) & np.isfinite(arr), arr, np.nan)


def clean_population(arr: np.ndarray, nodata: float | int | None) -> np.ndarray:
    arr = arr.astype("float32", copy=False)
    if nodata is not None and np.isfinite(nodata):
        arr = np.where(arr == nodata, 0, arr)
    return np.where((arr > 0) & np.isfinite(arr), arr, 0)


def load_population() -> tuple[np.ndarray, rasterio.Affine, object]:
    with rasterio.open(PATHS["population"]) as src:
        return clean_population(src.read(1), src.nodata), src.transform, src.crs


def match_population(
    pop: np.ndarray,
    pop_transform: rasterio.Affine,
    pop_crs,
    target_shape: tuple[int, int],
    target_transform: rasterio.Affine,
    target_crs,
) -> np.ndarray:
    if pop.shape == target_shape and pop_transform == target_transform and pop_crs == target_crs:
        return pop.copy()
    out = np.zeros(target_shape, dtype="float32")
    reproject(
        source=pop,
        destination=out,
        src_transform=pop_transform,
        src_crs=pop_crs,
        src_nodata=0,
        dst_transform=target_transform,
        dst_crs=target_crs,
        dst_nodata=0,
        resampling=Resampling.bilinear,
    )
    return out


def read_time_and_population(path: Path, mask_geom) -> tuple[np.ndarray, np.ndarray]:
    pop, pop_transform, pop_crs = load_population()
    with rasterio.open(path) as src:
        arr = clean_time(src.read(1), src.nodata)
        inside = features.geometry_mask(
            mask_geom,
            out_shape=arr.shape,
            transform=src.transform,
            invert=True,
            all_touched=True,
        )
        arr = np.where(inside, arr, np.nan)
        pop_match = match_population(pop, pop_transform, pop_crs, arr.shape, src.transform, src.crs)
    return arr, pop_match


def weighted_metrics() -> tuple[pd.DataFrame, dict[str, tuple[np.ndarray, np.ndarray]]]:
    cities = gpd.read_file(PATHS["cities"]).to_crs("EPSG:4326")
    mask_geom = [cities.geometry.unary_union]
    table_pwtt = None
    if PATHS["main_table2"].exists():
        table_pwtt = pd.read_csv(PATHS["main_table2"])
        table_pwtt["mode"] = table_pwtt["mode"].replace({"Transit": "Public transit"})

    arrays = {}
    rows = []
    for mode, mode_label in MODES:
        for tier, tier_label in TIERS:
            key = f"{mode}_{tier}"
            arr, pop = read_time_and_population(PATHS[key], mask_geom)
            valid = np.isfinite(arr) & np.isfinite(pop) & (pop > 0)
            denom = float(pop[valid].sum())
            item = {
                "key": key,
                "mode": mode_label,
                "tier": tier_label,
                "population_denominator": denom,
                "pwtt_min": float(np.average(arr[valid], weights=pop[valid])) if valid.any() else np.nan,
            }
            for threshold in (15, 30, 45, 60, 90, 120):
                within = valid & (arr <= threshold)
                beyond = valid & (arr > threshold)
                item[f"coverage_{threshold}min_pct"] = float(pop[within].sum() / denom * 100) if denom else np.nan
                item[f"beyond_{threshold}min_pop"] = float(pop[beyond].sum()) if denom else np.nan
            rows.append(item)
            arrays[key] = (arr, pop)

    metrics = pd.DataFrame(rows)
    if table_pwtt is not None:
        metrics = metrics.merge(
            table_pwtt[["mode", "tier", "pwtt"]].rename(columns={"pwtt": "table_pwtt_min"}),
            on=["mode", "tier"],
            how="left",
        )
        metrics["label_pwtt_min"] = metrics["table_pwtt_min"].fillna(metrics["pwtt_min"])
        for threshold in (30, 45):
            col = f"coverage_{threshold}min_pct"
            if col in table_pwtt.columns:
                metrics = metrics.merge(
                    table_pwtt[["mode", "tier", col]].rename(columns={col: f"table_{col}"}),
                    on=["mode", "tier"],
                    how="left",
                )
                metrics[f"label_{col}"] = metrics[f"table_{col}"].fillna(metrics[col])
    else:
        metrics["label_pwtt_min"] = metrics["pwtt_min"]
    return metrics, arrays


def city_walk_primary_uncovered(arr: np.ndarray, pop: np.ndarray) -> pd.DataFrame:
    cities = gpd.read_file(PATHS["cities"]).to_crs("EPSG:4326")
    with rasterio.open(PATHS["walk_l1"]) as src:
        rows = []
        for _, city in cities.iterrows():
            mask = features.geometry_mask(
                [city.geometry],
                out_shape=arr.shape,
                transform=src.transform,
                invert=True,
                all_touched=True,
            )
            valid = mask & np.isfinite(arr) & (pop > 0)
            total = float(pop[valid].sum())
            uncovered = float(pop[valid & (arr > 30)].sum())
            rows.append(
                {
                    "city": DISPLAY_CITY.get(city["City_name"], city["City_name"]),
                    "population": total,
                    "walk_primary_beyond30_pop": uncovered,
                    "walk_primary_beyond30_pct": uncovered / total * 100 if total else np.nan,
                }
            )
    return pd.DataFrame(rows).sort_values("walk_primary_beyond30_pop", ascending=True)


def tertiary_curve(metrics_arrays: dict[str, tuple[np.ndarray, np.ndarray]]) -> pd.DataFrame:
    thresholds = np.arange(0, 121, 5)
    rows = []
    for mode, mode_label in MODES:
        arr, pop = metrics_arrays[f"{mode}_l3"]
        valid = np.isfinite(arr) & (pop > 0)
        denom = float(pop[valid].sum())
        for threshold in thresholds:
            covered = float(pop[valid & (arr <= threshold)].sum())
            rows.append(
                {
                    "mode": mode_label,
                    "threshold_min": int(threshold),
                    "coverage_pct": covered / denom * 100 if denom else np.nan,
                    "covered_pop": covered,
                    "beyond_pop": denom - covered,
                }
            )
    return pd.DataFrame(rows)


def add_panel_label(ax: plt.Axes, label: str) -> None:
    ax.text(
        -0.11,
        1.04,
        label,
        transform=ax.transAxes,
        ha="left",
        va="bottom",
        fontsize=11,
        fontweight="bold",
        color="#111111",
    )


def plot_pwtt(ax: plt.Axes, metrics: pd.DataFrame) -> None:
    order = [(mode_label, tier_label) for mode_key, mode_label in MODES for tier_key, tier_label in TIERS]
    data = pd.DataFrame(order, columns=["mode", "tier"]).merge(metrics, on=["mode", "tier"], how="left")
    labels = [f"{r.mode} {r.tier}" for r in data.itertuples()]
    y = np.arange(len(data))
    colors = [MODE_COLORS[m] for m in data["mode"]]
    ax.barh(y, data["label_pwtt_min"], color=colors, edgecolor="#333333", linewidth=0.35, height=0.70)
    for yi, val in zip(y, data["label_pwtt_min"]):
        ax.text(val + 1.1, yi, f"{val:.1f}", ha="left", va="center", fontsize=7.2)
    ax.set_yticks(y)
    ax.set_yticklabels(labels, fontsize=7.2)
    ax.invert_yaxis()
    ax.set_xlabel("PWTT (min)", fontsize=8.5)
    ax.set_xlim(0, max(data["label_pwtt_min"]) * 1.22)
    ax.tick_params(axis="y", length=0)
    ax.grid(axis="x", color="#D8D8D8", linewidth=0.45)
    handles = [Rectangle((0, 0), 1, 1, facecolor=c, edgecolor="none", label=m) for m, c in MODE_COLORS.items()]
    ax.legend(handles=handles, loc="upper right", fontsize=7.2, ncol=1, borderaxespad=0.1)
    add_panel_label(ax, "a")


def plot_heatmap(ax: plt.Axes, metrics: pd.DataFrame) -> None:
    order = [(mode_label, tier_label) for mode_key, mode_label in MODES for tier_key, tier_label in TIERS]
    data = pd.DataFrame(order, columns=["mode", "tier"]).merge(metrics, on=["mode", "tier"], how="left")
    values = data[[f"coverage_{thr}min_pct" for thr in (15, 30, 60)]].to_numpy()
    im = ax.imshow(values, cmap="YlGnBu", vmin=0, vmax=100, aspect="auto")
    ax.set_xticks([0, 1, 2])
    ax.set_xticklabels(["15", "30", "60"], fontsize=8)
    ax.set_yticks(np.arange(len(data)))
    mode_short = {"Driving": "Drive", "Public transit": "Transit", "Walking": "Walk"}
    tier_short = {"Primary": "P", "Secondary": "S", "Tertiary": "T"}
    ax.set_yticklabels([f"{mode_short[r.mode]}-{tier_short[r.tier]}" for r in data.itertuples()], fontsize=7.4)
    ax.set_xlabel("Threshold (min)", fontsize=8.5)
    for i in range(values.shape[0]):
        for j in range(values.shape[1]):
            color = "white" if values[i, j] > 62 else "#222222"
            ax.text(j, i, f"{values[i, j]:.0f}", ha="center", va="center", fontsize=7.2, color=color)
    cbar = ax.figure.colorbar(im, ax=ax, fraction=0.046, pad=0.02)
    cbar.set_label("Covered population (%)", fontsize=8)
    cbar.ax.tick_params(labelsize=7, length=2.2)
    add_panel_label(ax, "b")


def plot_tertiary_curve(ax: plt.Axes, curve: pd.DataFrame, metrics: pd.DataFrame) -> None:
    for mode_label, color in MODE_COLORS.items():
        d = curve[curve["mode"] == mode_label]
        ax.plot(d["threshold_min"], d["coverage_pct"], color=color, lw=2.0, label=mode_label)
    ax.axvline(30, color="#4A4A4A", lw=0.8, ls="--")
    ax.set_xlim(0, 120)
    ax.set_ylim(0, 103)
    ax.set_xlabel("Threshold (min)", fontsize=8.5)
    ax.set_ylabel("Tertiary coverage (%)", fontsize=8.5)
    ax.grid(color="#D8D8D8", linewidth=0.45)
    ax.legend(loc="lower right", fontsize=7.4)
    tertiary = metrics[metrics["tier"] == "Tertiary"].copy()
    text = []
    for mode_label in ["Driving", "Public transit", "Walking"]:
        row = tertiary[tertiary["mode"] == mode_label].iloc[0]
        text.append(f"{mode_label}: {row['coverage_30min_pct']:.1f}%")
    walking_row = tertiary[tertiary["mode"] == "Walking"].iloc[0]
    ax.text(
        0.03,
        0.96,
        "30-min coverage\n" + "\n".join(text) + f"\nWalking beyond 30 min: {walking_row['beyond_30min_pop']/1e6:.1f}M",
        transform=ax.transAxes,
        ha="left",
        va="top",
        fontsize=7.5,
        bbox=dict(facecolor="white", edgecolor="#BBBBBB", boxstyle="round,pad=0.25", alpha=0.92),
    )
    add_panel_label(ax, "c")


def plot_uncovered_city(ax: plt.Axes, city: pd.DataFrame, metrics: pd.DataFrame, arrays: dict[str, tuple[np.ndarray, np.ndarray]]) -> None:
    ax.barh(
        city["city"],
        city["walk_primary_beyond30_pop"] / 1e6,
        color="#B9403A",
        edgecolor="#333333",
        linewidth=0.30,
        height=0.70,
    )
    ax.set_xlabel("Population beyond 30 min (million)", fontsize=8.5)
    ax.tick_params(axis="y", labelsize=7.4, length=0)
    ax.tick_params(axis="x", labelsize=7.6)
    ax.grid(axis="x", color="#D8D8D8", linewidth=0.45)
    primary = metrics[(metrics["mode"] == "Walking") & (metrics["tier"] == "Primary")].iloc[0]
    arr_walk, pop_walk = arrays["walk_l1"]
    arr_drive, _ = arrays["drive_l1"]
    valid = np.isfinite(arr_walk) & np.isfinite(arr_drive) & (pop_walk > 0)
    constrained = float(pop_walk[valid & (arr_drive <= 30) & (arr_walk > 30)].sum())
    ax.text(
        0.98,
        0.08,
        (
            f"Primary walking >30 min:\n{primary['beyond_30min_pop']/1e6:.1f}M "
            f"({100 - primary['coverage_30min_pct']:.1f}%)\n"
            f"Car-reachable subset:\n{constrained/1e6:.1f}M"
        ),
        transform=ax.transAxes,
        ha="right",
        va="bottom",
        fontsize=7.5,
        bbox=dict(facecolor="white", edgecolor="#BBBBBB", boxstyle="round,pad=0.25", alpha=0.92),
    )
    add_panel_label(ax, "d")


def save_outputs(fig: plt.Figure, stem: Path) -> None:
    fig.savefig(stem.with_suffix(".svg"), bbox_inches="tight")
    fig.savefig(stem.with_suffix(".pdf"), bbox_inches="tight")
    fig.savefig(stem.with_suffix(".png"), dpi=600, bbox_inches="tight")
    fig.savefig(stem.with_suffix(".tiff"), dpi=600, bbox_inches="tight", pil_kwargs={"compression": "tiff_lzw"})


def main() -> None:
    FIG_DIR.mkdir(parents=True, exist_ok=True)
    DATA_DIR.mkdir(parents=True, exist_ok=True)

    metrics, arrays = weighted_metrics()
    city = city_walk_primary_uncovered(*arrays["walk_l1"])
    curve = tertiary_curve(arrays)

    metrics.to_csv(DATA_DIR / "figure4_pwtt_coverage_metrics.csv", index=False, encoding="utf-8-sig")
    city.to_csv(DATA_DIR / "figure4_city_walk_primary_uncovered.csv", index=False, encoding="utf-8-sig")
    curve.to_csv(DATA_DIR / "figure4_tertiary_coverage_curves.csv", index=False, encoding="utf-8-sig")

    fig = plt.figure(figsize=(7.4, 6.4), constrained_layout=False)
    gs = fig.add_gridspec(
        2,
        2,
        left=0.075,
        right=0.975,
        top=0.955,
        bottom=0.095,
        wspace=0.30,
        hspace=0.34,
    )
    ax_a = fig.add_subplot(gs[0, 0])
    ax_b = fig.add_subplot(gs[0, 1])
    ax_c = fig.add_subplot(gs[1, 0])
    ax_d = fig.add_subplot(gs[1, 1])

    plot_pwtt(ax_a, metrics)
    plot_heatmap(ax_b, metrics)
    plot_tertiary_curve(ax_c, curve, metrics)
    plot_uncovered_city(ax_d, city, metrics, arrays)

    stem = FIG_DIR / "Figure4_pwtt_threshold_coverage"
    save_outputs(fig, stem)
    plt.close(fig)

    audit = {
        "figure": "Figure 4. Population-weighted travel time and threshold coverage",
        "core_conclusion": (
            "Car access keeps tertiary care within 30 min for almost the whole population, "
            "whereas public transit and walking sharply reduce threshold coverage and leave "
            "large populations beyond walking thresholds."
        ),
        "archetype": "quantitative grid",
        "inputs": {k: str(v) for k, v in PATHS.items()},
        "outputs": {
            "svg": str(stem.with_suffix(".svg")),
            "pdf": str(stem.with_suffix(".pdf")),
            "png": str(stem.with_suffix(".png")),
            "tiff": str(stem.with_suffix(".tiff")),
            "metrics": str(DATA_DIR / "figure4_pwtt_coverage_metrics.csv"),
            "city_uncovered": str(DATA_DIR / "figure4_city_walk_primary_uncovered.csv"),
            "tertiary_curves": str(DATA_DIR / "figure4_tertiary_coverage_curves.csv"),
        },
        "key_values": {
            "driving_tertiary_30min_coverage_pct": float(
                metrics.loc[(metrics["mode"] == "Driving") & (metrics["tier"] == "Tertiary"), "coverage_30min_pct"].iloc[0]
            ),
            "walking_tertiary_beyond30_pop": float(
                metrics.loc[(metrics["mode"] == "Walking") & (metrics["tier"] == "Tertiary"), "beyond_30min_pop"].iloc[0]
            ),
            "walking_primary_beyond30_pop": float(
                metrics.loc[(metrics["mode"] == "Walking") & (metrics["tier"] == "Primary"), "beyond_30min_pop"].iloc[0]
            ),
        },
    }
    (DATA_DIR / "figure4_pwtt_coverage_audit.json").write_text(
        json.dumps(audit, indent=2, ensure_ascii=False), encoding="utf-8"
    )


if __name__ == "__main__":
    main()


