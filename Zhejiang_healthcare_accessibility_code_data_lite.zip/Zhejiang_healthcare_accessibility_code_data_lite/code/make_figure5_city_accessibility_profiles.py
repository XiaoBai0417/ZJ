﻿from __future__ import annotations

import json
from pathlib import Path

import geopandas as gpd
import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import rasterio
from matplotlib.lines import Line2D
from rasterio import features
from rasterio.enums import Resampling
from rasterio.warp import reproject


BASE = Path("data_external/datasets1")
PROJECT_OUT = Path("outputs")
FIG_DIR = PROJECT_OUT / "figures"
DATA_DIR = PROJECT_OUT / "data"

PATHS = {
    "cities": BASE / "zj_cities.shp",
    "population": BASE / "ZJ_pop.tif",
    "drive_l1": BASE / "level1_drive.tif",
    "drive_l3": BASE / "level3_drive.tif",
    "transit_l3": BASE / "level3_transit.tif",
    "walk_l1": BASE / "level1_walk.tif",
    "walk_l3": BASE / "level3_walk.tif",
}

DISPLAY_CITY = {"Jiaxin": "Jiaxing"}
MODE_COLORS = {
    "Driving": "#3E6EA8",
    "Public transit": "#D18A2D",
    "Walking": "#B9403A",
}


mpl.rcParams.update(
    {
        "font.family": "sans-serif",
        "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans", "sans-serif"],
        "svg.fonttype": "none",
        "pdf.fonttype": 42,
        "font.size": 8,
        "axes.linewidth": 0.7,
        "axes.spines.right": False,
        "axes.spines.top": False,
        "legend.frameon": False,
        "xtick.major.width": 0.6,
        "ytick.major.width": 0.6,
    }
)


def clean_time(arr: np.ndarray, nodata: float | int | None) -> np.ndarray:
    arr = arr.astype("float32", copy=False)
    if nodata is not None and np.isfinite(nodata):
        arr = np.where(arr == nodata, np.nan, arr)
    return np.where((arr > 0) & (arr <= 3000) & np.isfinite(arr), arr, np.nan)


def clean_population(arr: np.ndarray, nodata: float | int | None) -> np.ndarray:
    arr = arr.astype("float32", copy=False)
    if nodata is not None and np.isfinite(nodata):
        arr = np.where(arr == nodata, 0, arr)
    return np.where((arr > 0) & np.isfinite(arr), arr, 0)


def load_population() -> tuple[np.ndarray, rasterio.Affine, object]:
    with rasterio.open(PATHS["population"]) as src:
        return clean_population(src.read(1), src.nodata), src.transform, src.crs


def read_time(path: Path) -> tuple[np.ndarray, rasterio.Affine, object]:
    with rasterio.open(path) as src:
        return clean_time(src.read(1), src.nodata), src.transform, src.crs


def match_population(
    pop: np.ndarray,
    pop_transform: rasterio.Affine,
    pop_crs,
    target_shape: tuple[int, int],
    target_transform: rasterio.Affine,
    target_crs,
) -> np.ndarray:
    if pop.shape == target_shape and pop_transform == target_transform and pop_crs == target_crs:
        return pop.copy()
    out = np.zeros(target_shape, dtype="float32")
    reproject(
        source=pop,
        destination=out,
        src_transform=pop_transform,
        src_crs=pop_crs,
        src_nodata=0,
        dst_transform=target_transform,
        dst_crs=target_crs,
        dst_nodata=0,
        resampling=Resampling.bilinear,
    )
    return out


def weighted_mean(values: np.ndarray, weights: np.ndarray, mask: np.ndarray) -> float:
    valid = mask & np.isfinite(values) & np.isfinite(weights) & (weights > 0)
    if not valid.any():
        return np.nan
    return float(np.average(values[valid], weights=weights[valid]))


def coverage(values: np.ndarray, weights: np.ndarray, mask: np.ndarray, threshold: float) -> tuple[float, float, float]:
    valid = mask & np.isfinite(values) & np.isfinite(weights) & (weights > 0)
    denom = float(weights[valid].sum())
    if denom <= 0:
        return np.nan, np.nan, np.nan
    covered = float(weights[valid & (values <= threshold)].sum())
    beyond = float(weights[valid & (values > threshold)].sum())
    return covered / denom * 100, beyond, denom


def city_profiles() -> pd.DataFrame:
    cities = gpd.read_file(PATHS["cities"]).to_crs("EPSG:4326")
    pop, pop_transform, pop_crs = load_population()
    arrays = {}
    for key in ["drive_l1", "drive_l3", "transit_l3", "walk_l1", "walk_l3"]:
        arr, transform, crs = read_time(PATHS[key])
        city_id = features.rasterize(
            [(geom, idx + 1) for idx, geom in enumerate(cities.geometry)],
            out_shape=arr.shape,
            transform=transform,
            fill=0,
            dtype="int16",
            all_touched=False,
        )
        arrays[key] = {
            "time": arr,
            "transform": transform,
            "crs": crs,
            "population": match_population(pop, pop_transform, pop_crs, arr.shape, transform, crs),
            "city_id": city_id,
        }

    rows = []
    for _, city in cities.iterrows():
        row = {
            "city": DISPLAY_CITY.get(city["City_name"], city["City_name"]),
            "city_raw": city["City_name"],
        }
        city_idx = int(cities.index.get_loc(city.name)) + 1
        masks = {key: pack["city_id"] == city_idx for key, pack in arrays.items()}

        for key, label in [
            ("drive_l3", "driving_tertiary"),
            ("transit_l3", "transit_tertiary"),
            ("walk_l3", "walking_tertiary"),
        ]:
            pack = arrays[key]
            row[f"{label}_pwtt"] = weighted_mean(pack["time"], pack["population"], masks[key])
            cov30, beyond30, denom = coverage(pack["time"], pack["population"], masks[key], 30)
            row[f"{label}_coverage30_pct"] = cov30
            row[f"{label}_beyond30_pop"] = beyond30
            row[f"{label}_population_denominator"] = denom

        pack = arrays["walk_l1"]
        cov30, beyond30, denom = coverage(pack["time"], pack["population"], masks["walk_l1"], 30)
        row["walking_primary_coverage30_pct"] = cov30
        row["walking_primary_beyond30_pop"] = beyond30
        row["walking_primary_population_denominator"] = denom

        rows.append(row)

    df = pd.DataFrame(rows)
    burden_inputs = pd.DataFrame(
        {
            "drive_l3_pwtt": df["driving_tertiary_pwtt"],
            "transit_l3_pwtt": df["transit_tertiary_pwtt"],
            "walk_l3_pwtt": df["walking_tertiary_pwtt"],
            "walk_primary_uncovered_pct": 100 - df["walking_primary_coverage30_pct"],
            "tertiary_uncovered30_mean_pct": 100
            - df[
                [
                    "driving_tertiary_coverage30_pct",
                    "transit_tertiary_coverage30_pct",
                    "walking_tertiary_coverage30_pct",
                ]
            ].mean(axis=1),
        }
    )
    z = (burden_inputs - burden_inputs.mean()) / burden_inputs.std(ddof=0)
    df["accessibility_burden_score"] = z.mean(axis=1)
    df["accessibility_burden_rank"] = df["accessibility_burden_score"].rank(ascending=False, method="min").astype(int)
    df = df.sort_values("accessibility_burden_score", ascending=False).reset_index(drop=True)
    return df


def add_panel_label(ax: plt.Axes, label: str) -> None:
    ax.text(
        -0.12,
        1.04,
        label,
        transform=ax.transAxes,
        ha="left",
        va="bottom",
        fontsize=11,
        fontweight="bold",
        color="#111111",
    )


def plot_tertiary_pwtt(ax: plt.Axes, df: pd.DataFrame) -> None:
    y = np.arange(len(df))
    low = df[["driving_tertiary_pwtt", "transit_tertiary_pwtt", "walking_tertiary_pwtt"]].min(axis=1)
    high = df[["driving_tertiary_pwtt", "transit_tertiary_pwtt", "walking_tertiary_pwtt"]].max(axis=1)
    ax.hlines(y, low, high, color="#D0D0D0", lw=1.0, zorder=1)
    for label, col in [
        ("Driving", "driving_tertiary_pwtt"),
        ("Public transit", "transit_tertiary_pwtt"),
        ("Walking", "walking_tertiary_pwtt"),
    ]:
        ax.scatter(df[col], y, s=24, color=MODE_COLORS[label], label=label, zorder=3, edgecolor="white", linewidth=0.35)
    ax.set_yticks(y)
    ax.set_yticklabels(df["city"], fontsize=7.5)
    ax.invert_yaxis()
    ax.set_xlabel("Tertiary PWTT (min)", fontsize=8.5)
    ax.grid(axis="x", color="#D8D8D8", linewidth=0.45)
    ax.legend(loc="lower right", fontsize=7.1, handletextpad=0.3)
    add_panel_label(ax, "a")


def plot_primary_uncovered(ax: plt.Axes, df: pd.DataFrame) -> None:
    y = np.arange(len(df))
    ax.barh(
        y,
        df["walking_primary_beyond30_pop"] / 1e6,
        color="#B9403A",
        edgecolor="#333333",
        linewidth=0.30,
        height=0.68,
    )
    ax.set_yticks(y)
    ax.set_yticklabels(df["city"], fontsize=7.5)
    ax.invert_yaxis()
    ax.set_xlabel("Primary walking >30 min (million)", fontsize=8.5)
    ax.grid(axis="x", color="#D8D8D8", linewidth=0.45)
    total = df["walking_primary_beyond30_pop"].sum()
    ax.text(
        0.98,
        0.08,
        f"Total: {total/1e6:.1f}M",
        transform=ax.transAxes,
        ha="right",
        va="bottom",
        fontsize=7.6,
        bbox=dict(facecolor="white", edgecolor="#BBBBBB", boxstyle="round,pad=0.25", alpha=0.92),
    )
    add_panel_label(ax, "b")


def plot_tertiary_coverage(ax: plt.Axes, df: pd.DataFrame) -> None:
    y = np.arange(len(df))
    offsets = [-0.22, 0.0, 0.22]
    for offset, label, col in [
        (offsets[0], "Driving", "driving_tertiary_coverage30_pct"),
        (offsets[1], "Public transit", "transit_tertiary_coverage30_pct"),
        (offsets[2], "Walking", "walking_tertiary_coverage30_pct"),
    ]:
        ax.scatter(df[col], y + offset, s=24, color=MODE_COLORS[label], label=label, edgecolor="white", linewidth=0.35)
    ax.axvline(80, color="#777777", lw=0.7, ls="--")
    ax.set_xlim(0, 103)
    ax.set_yticks(y)
    ax.set_yticklabels(df["city"], fontsize=7.5)
    ax.invert_yaxis()
    ax.set_xlabel("Tertiary 30-min coverage (%)", fontsize=8.5)
    ax.grid(axis="x", color="#D8D8D8", linewidth=0.45)
    add_panel_label(ax, "c")


def plot_burden_rank(ax: plt.Axes, df: pd.DataFrame) -> None:
    y = np.arange(len(df))
    colors = mpl.colormaps["Reds"](np.linspace(0.85, 0.35, len(df)))
    ax.barh(
        y,
        df["accessibility_burden_score"],
        color=colors,
        edgecolor="#333333",
        linewidth=0.30,
        height=0.68,
    )
    ax.axvline(0, color="#555555", lw=0.75)
    for yi, rank in zip(y, df["accessibility_burden_rank"]):
        ax.text(
            df["accessibility_burden_score"].iloc[yi] + 0.035,
            yi,
            f"#{rank}",
            va="center",
            ha="left",
            fontsize=7.1,
            color="#222222",
        )
    ax.set_yticks(y)
    ax.set_yticklabels(df["city"], fontsize=7.5)
    ax.invert_yaxis()
    ax.set_xlabel("Composite accessibility burden (z-score)", fontsize=8.5)
    ax.grid(axis="x", color="#D8D8D8", linewidth=0.45)
    ax.text(
        0.98,
        0.08,
        "Higher score =\nlonger tertiary PWTT,\nmore uncovered population",
        transform=ax.transAxes,
        ha="right",
        va="bottom",
        fontsize=7.1,
        bbox=dict(facecolor="white", edgecolor="#BBBBBB", boxstyle="round,pad=0.25", alpha=0.92),
    )
    add_panel_label(ax, "d")


def save_outputs(fig: plt.Figure, stem: Path) -> None:
    fig.savefig(stem.with_suffix(".svg"), bbox_inches="tight")
    fig.savefig(stem.with_suffix(".pdf"), bbox_inches="tight")
    fig.savefig(stem.with_suffix(".png"), dpi=600, bbox_inches="tight")
    fig.savefig(stem.with_suffix(".tiff"), dpi=600, bbox_inches="tight", pil_kwargs={"compression": "tiff_lzw"})


def main() -> None:
    FIG_DIR.mkdir(parents=True, exist_ok=True)
    DATA_DIR.mkdir(parents=True, exist_ok=True)

    df = city_profiles()
    source_csv = DATA_DIR / "figure5_city_accessibility_profiles.csv"
    df.to_csv(source_csv, index=False, encoding="utf-8-sig")

    fig = plt.figure(figsize=(7.4, 6.6), constrained_layout=False)
    gs = fig.add_gridspec(
        2,
        2,
        left=0.085,
        right=0.975,
        top=0.965,
        bottom=0.090,
        wspace=0.34,
        hspace=0.34,
    )
    axes = [fig.add_subplot(gs[0, 0]), fig.add_subplot(gs[0, 1]), fig.add_subplot(gs[1, 0]), fig.add_subplot(gs[1, 1])]
    plot_tertiary_pwtt(axes[0], df)
    plot_primary_uncovered(axes[1], df)
    plot_tertiary_coverage(axes[2], df)
    plot_burden_rank(axes[3], df)

    stem = FIG_DIR / "Figure5_city_accessibility_profiles"
    save_outputs(fig, stem)
    plt.close(fig)

    audit = {
        "figure": "Figure 5. City-level accessibility profiles",
        "core_conclusion": (
            "City profiles reveal large variation in tertiary-care travel times, walking-primary "
            "uncovered populations, and combined accessibility burden across Zhejiang's 11 prefectures."
        ),
        "burden_score_definition": (
            "Mean of standardized driving/transit/walking tertiary PWTT, walking-primary >30 min "
            "uncovered percentage, and mean tertiary 30-min uncovered percentage."
        ),
        "inputs": {k: str(v) for k, v in PATHS.items()},
        "outputs": {
            "svg": str(stem.with_suffix(".svg")),
            "pdf": str(stem.with_suffix(".pdf")),
            "png": str(stem.with_suffix(".png")),
            "tiff": str(stem.with_suffix(".tiff")),
            "source_data": str(source_csv),
        },
    }
    (DATA_DIR / "figure5_city_accessibility_profiles_audit.json").write_text(
        json.dumps(audit, indent=2, ensure_ascii=False), encoding="utf-8"
    )


if __name__ == "__main__":
    main()


