﻿from __future__ import annotations

import json
from pathlib import Path

import geopandas as gpd
import matplotlib as mpl
import matplotlib.colors as mcolors
import matplotlib.patheffects as pe
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import rasterio
from matplotlib.patches import Patch
from rasterio import features
from rasterio.enums import Resampling
from rasterio.warp import calculate_default_transform, reproject


BASE = Path("data_external/datasets1")
PROJECT_OUT = Path("outputs")
FIG_DIR = PROJECT_OUT / "figures"
DATA_DIR = PROJECT_OUT / "data"
WEB_MERCATOR = "EPSG:3857"

PATHS = {
    "cities": BASE / "zj_cities.shp",
    "population": BASE / "ZJ_pop.tif",
    "drive_l3": BASE / "level3_drive.tif",
    "transit_l3": BASE / "level3_transit.tif",
}

DISPLAY_CITY = {"Jiaxin": "Jiaxing"}


mpl.rcParams.update(
    {
        "font.family": "sans-serif",
        "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans", "sans-serif"],
        "svg.fonttype": "none",
        "pdf.fonttype": 42,
        "font.size": 8,
        "axes.linewidth": 0.7,
        "axes.spines.right": False,
        "axes.spines.top": False,
        "legend.frameon": False,
        "xtick.major.width": 0.6,
        "ytick.major.width": 0.6,
    }
)


def clean_time(arr: np.ndarray, nodata: float | int | None) -> np.ndarray:
    arr = arr.astype("float32", copy=False)
    if nodata is not None and np.isfinite(nodata):
        arr = np.where(arr == nodata, np.nan, arr)
    return np.where((arr > 0) & (arr <= 3000) & np.isfinite(arr), arr, np.nan)


def clean_population(arr: np.ndarray, nodata: float | int | None) -> np.ndarray:
    arr = arr.astype("float32", copy=False)
    if nodata is not None and np.isfinite(nodata):
        arr = np.where(arr == nodata, 0, arr)
    return np.where((arr > 0) & np.isfinite(arr), arr, 0)


def read_inputs() -> tuple[np.ndarray, np.ndarray, np.ndarray, rasterio.Affine, object]:
    with rasterio.open(PATHS["drive_l3"]) as src:
        drive = clean_time(src.read(1), src.nodata)
        transform = src.transform
        crs = src.crs
        shape = drive.shape
    with rasterio.open(PATHS["transit_l3"]) as src:
        transit = clean_time(src.read(1), src.nodata)
    with rasterio.open(PATHS["population"]) as src:
        pop = clean_population(src.read(1), src.nodata)
        if pop.shape != shape or src.transform != transform or src.crs != crs:
            matched = np.zeros(shape, dtype="float32")
            reproject(
                source=pop,
                destination=matched,
                src_transform=src.transform,
                src_crs=src.crs,
                src_nodata=0,
                dst_transform=transform,
                dst_crs=crs,
                dst_nodata=0,
                resampling=Resampling.bilinear,
            )
            pop = matched
    return drive, transit, pop, transform, crs


def destination_grid(transform: rasterio.Affine, crs, width: int, height: int) -> tuple[rasterio.Affine, int, int]:
    left = transform.c
    top = transform.f
    right = left + transform.a * width
    bottom = top + transform.e * height
    dst_transform, dst_width, dst_height = calculate_default_transform(
        crs,
        WEB_MERCATOR,
        width,
        height,
        left,
        bottom,
        right,
        top,
    )
    return dst_transform, dst_width, dst_height


def raster_extent(transform: rasterio.Affine, width: int, height: int) -> tuple[float, float, float, float]:
    left = transform.c
    top = transform.f
    right = left + transform.a * width
    bottom = top + transform.e * height
    return left, right, bottom, top


def reproject_metric(
    arr: np.ndarray,
    src_transform: rasterio.Affine,
    src_crs,
    dst_transform: rasterio.Affine,
    dst_width: int,
    dst_height: int,
    resampling: Resampling,
) -> np.ndarray:
    dst = np.full((dst_height, dst_width), np.nan, dtype="float32")
    reproject(
        source=arr.astype("float32"),
        destination=dst,
        src_transform=src_transform,
        src_crs=src_crs,
        src_nodata=np.nan,
        dst_transform=dst_transform,
        dst_crs=WEB_MERCATOR,
        dst_nodata=np.nan,
        resampling=resampling,
    )
    return dst


def compute_metrics() -> tuple[pd.DataFrame, np.ndarray, np.ndarray, tuple[float, float, float, float], gpd.GeoDataFrame]:
    cities = gpd.read_file(PATHS["cities"]).to_crs("EPSG:4326")
    drive, transit, pop, transform, crs = read_inputs()

    zhejiang_mask = features.geometry_mask(
        [cities.geometry.unary_union],
        out_shape=drive.shape,
        transform=transform,
        invert=True,
        all_touched=True,
    )
    valid_drive = zhejiang_mask & np.isfinite(drive) & (pop > 0)
    valid_ratio = valid_drive & np.isfinite(transit)
    ratio = np.where(valid_ratio, transit / drive, np.nan)
    ratio = np.where((ratio >= 1) & (ratio <= 40), ratio, np.nan)
    void = np.where(valid_drive & ~np.isfinite(transit), 1.0, np.nan)

    rows = []
    for idx, row in cities.iterrows():
        city_mask = features.geometry_mask(
            [row.geometry],
            out_shape=drive.shape,
            transform=transform,
            invert=True,
            all_touched=False,
        )
        city_drive = city_mask & np.isfinite(drive) & (pop > 0)
        city_ratio = city_drive & np.isfinite(transit)
        city_void = city_drive & ~np.isfinite(transit)
        denom = float(pop[city_drive].sum())
        ratio_values = transit[city_ratio] / drive[city_ratio]
        rows.append(
            {
                "city": DISPLAY_CITY.get(row["City_name"], row["City_name"]),
                "city_raw": row["City_name"],
                "population_denominator": denom,
                "mean_transit_to_car_ratio": float(np.average(ratio_values, weights=pop[city_ratio]))
                if city_ratio.any()
                else np.nan,
                "unweighted_mean_transit_to_car_ratio": float(np.nanmean(ratio_values)) if city_ratio.any() else np.nan,
                "potential_public_transit_service_void_pop": float(pop[city_void].sum()),
                "potential_public_transit_service_void_pop_share_pct": float(pop[city_void].sum() / denom * 100)
                if denom
                else np.nan,
                "potential_public_transit_service_void_cell_share_pct": float(city_void.sum() / city_drive.sum() * 100)
                if city_drive.any()
                else np.nan,
            }
        )
    stats = pd.DataFrame(rows)

    dst_transform, dst_width, dst_height = destination_grid(transform, crs, drive.shape[1], drive.shape[0])
    ratio_projected = reproject_metric(ratio, transform, crs, dst_transform, dst_width, dst_height, Resampling.bilinear)
    void_projected = reproject_metric(void, transform, crs, dst_transform, dst_width, dst_height, Resampling.nearest)
    ratio_projected = np.where((ratio_projected >= 1) & (ratio_projected <= 40), ratio_projected, np.nan)
    void_projected = np.where(np.isfinite(void_projected) & (void_projected > 0.5), 1, np.nan)
    extent = raster_extent(dst_transform, dst_width, dst_height)
    return stats, ratio_projected, void_projected, extent, cities.to_crs(WEB_MERCATOR)


def add_panel_label(ax: plt.Axes, label: str) -> None:
    ax.text(
        -0.08,
        1.04,
        label,
        transform=ax.transAxes,
        ha="left",
        va="bottom",
        fontsize=11,
        fontweight="bold",
        color="#111111",
        zorder=30,
    )


def add_aligned_panel_labels(
    fig: plt.Figure,
    left_x: float,
    right_x: float,
    top_y: float,
    bottom_y: float,
    panel_h: float,
) -> None:
    label_x_offset = 0.030
    label_y_offset = 0.015
    labels = [
        ("a", left_x - label_x_offset, top_y + panel_h + label_y_offset),
        ("b", right_x - label_x_offset, top_y + panel_h + label_y_offset),
        ("c", left_x - label_x_offset, bottom_y + panel_h + label_y_offset),
        ("d", right_x - label_x_offset, bottom_y + panel_h + label_y_offset),
    ]
    for label, x, y in labels:
        fig.text(
            x,
            y,
            label,
            ha="left",
            va="bottom",
            fontsize=11,
            fontweight="bold",
            color="#111111",
        )


def style_map(ax: plt.Axes) -> None:
    ax.set_xticks([])
    ax.set_yticks([])
    ax.set_aspect("equal", adjustable="box")
    for spine in ax.spines.values():
        spine.set_visible(True)
        spine.set_color("#4A4A4A")
        spine.set_linewidth(0.65)


def plot_ratio_map(ax: plt.Axes, ratio: np.ndarray, extent, cities: gpd.GeoDataFrame) -> mpl.image.AxesImage:
    ax.set_facecolor("#F7F7F4")
    cities.plot(ax=ax, facecolor="#D9D9D9", edgecolor="none", alpha=0.75, zorder=0)
    cmap = mpl.colormaps["YlOrRd"].copy()
    cmap.set_bad((1, 1, 1, 0))
    norm = mcolors.Normalize(vmin=1, vmax=12)
    im = ax.imshow(np.ma.masked_invalid(ratio), extent=extent, origin="upper", cmap=cmap, norm=norm, zorder=2)
    cities.boundary.plot(ax=ax, color="white", linewidth=0.62, alpha=0.90, zorder=4)
    cities.boundary.plot(ax=ax, color="#303030", linewidth=0.18, alpha=0.70, zorder=5)
    style_map(ax)
    ax.text(
        0.04,
        0.06,
        "Tertiary public transit-to-car ratio",
        transform=ax.transAxes,
        ha="left",
        va="bottom",
        fontsize=7.4,
        color="#222222",
        path_effects=[pe.withStroke(linewidth=2.4, foreground="white", alpha=0.85)],
    )
    return im


def plot_void_map(ax: plt.Axes, void: np.ndarray, extent, cities: gpd.GeoDataFrame) -> None:
    ax.set_facecolor("#F7F7F4")
    cities.plot(ax=ax, facecolor="#E2E2E2", edgecolor="none", alpha=0.95, zorder=0)
    void_cmap = mcolors.ListedColormap(["#B9403A"])
    ax.imshow(np.ma.masked_invalid(void), extent=extent, origin="upper", cmap=void_cmap, vmin=1, vmax=1, zorder=2)
    cities.boundary.plot(ax=ax, color="white", linewidth=0.62, alpha=0.90, zorder=4)
    cities.boundary.plot(ax=ax, color="#303030", linewidth=0.18, alpha=0.72, zorder=5)
    style_map(ax)
    ax.text(
        0.04,
        0.06,
        "Potential public-transit service voids",
        transform=ax.transAxes,
        ha="left",
        va="bottom",
        fontsize=7.4,
        color="#222222",
        path_effects=[pe.withStroke(linewidth=2.4, foreground="white", alpha=0.85)],
    )
    handles = [
        Patch(facecolor="#B9403A", edgecolor="none", label="Potential public-transit service voids"),
        Patch(facecolor="#E2E2E2", edgecolor="none", label="Other areas"),
    ]
    ax.legend(handles=handles, loc="upper right", fontsize=6.8, handlelength=1.0, borderaxespad=0.2)


def plot_ratio_city(ax: plt.Axes, stats: pd.DataFrame) -> None:
    d = stats.sort_values("mean_transit_to_car_ratio", ascending=False).reset_index(drop=True)
    y = np.arange(len(d))
    ax.barh(y, d["mean_transit_to_car_ratio"], color="#D18A2D", edgecolor="#333333", linewidth=0.30, height=0.70)
    ax.axvline(6.0, color="#555555", lw=0.75, ls="--")
    ax.set_yticks(y)
    ax.set_yticklabels(d["city"], fontsize=7.5)
    ax.invert_yaxis()
    ax.set_xlabel("Mean transit-to-car ratio", fontsize=8.5)
    ax.set_xlim(0, max(8.8, d["mean_transit_to_car_ratio"].max() * 1.12))
    ax.grid(axis="x", color="#D8D8D8", linewidth=0.45)
    top = d.iloc[0]
    ax.text(
        0.98,
        0.08,
        f"All cities >6.0\nHighest: {top['city']} {top['mean_transit_to_car_ratio']:.2f}",
        transform=ax.transAxes,
        ha="right",
        va="bottom",
        fontsize=7.4,
        bbox=dict(facecolor="white", edgecolor="#BBBBBB", boxstyle="round,pad=0.25", alpha=0.92),
    )


def plot_void_city(ax: plt.Axes, stats: pd.DataFrame) -> None:
    d = stats.sort_values("potential_public_transit_service_void_pop_share_pct", ascending=False).reset_index(drop=True)
    y = np.arange(len(d))
    ax.barh(
        y,
        d["potential_public_transit_service_void_pop_share_pct"],
        color="#B9403A",
        edgecolor="#333333",
        linewidth=0.30,
        height=0.70,
    )
    ax.set_yticks(y)
    ax.set_yticklabels(d["city"], fontsize=7.5)
    ax.invert_yaxis()
    ax.set_xlabel("Population share in potential public-transit\nservice voids (%)", fontsize=8.5)
    ax.set_xlim(0, max(20, d["potential_public_transit_service_void_pop_share_pct"].max() * 1.18))
    ax.grid(axis="x", color="#D8D8D8", linewidth=0.45)
    top = d.iloc[0]
    ax.text(
        0.98,
        0.08,
        f"Highest: {top['city']}\n{top['potential_public_transit_service_void_pop_share_pct']:.2f}%",
        transform=ax.transAxes,
        ha="right",
        va="bottom",
        fontsize=7.4,
        bbox=dict(facecolor="white", edgecolor="#BBBBBB", boxstyle="round,pad=0.25", alpha=0.92),
    )


def save_outputs(fig: plt.Figure, stem: Path) -> None:
    fig.savefig(stem.with_suffix(".svg"), bbox_inches="tight")
    fig.savefig(stem.with_suffix(".pdf"), bbox_inches="tight")
    fig.savefig(stem.with_suffix(".png"), dpi=600, bbox_inches="tight")
    fig.savefig(stem.with_suffix(".tiff"), dpi=600, bbox_inches="tight", pil_kwargs={"compression": "tiff_lzw"})


def main() -> None:
    FIG_DIR.mkdir(parents=True, exist_ok=True)
    DATA_DIR.mkdir(parents=True, exist_ok=True)

    stats, ratio, void, extent, cities_projected = compute_metrics()
    source_csv = DATA_DIR / "figure6_transit_efficiency_voids_city_stats.csv"
    stats.to_csv(source_csv, index=False, encoding="utf-8-sig")

    fig = plt.figure(figsize=(7.4, 6.6), constrained_layout=False)
    left_x = 0.075
    right_x = 0.555
    top_shift_x = -0.025
    top_left_x = left_x + top_shift_x
    top_right_x = right_x + top_shift_x
    panel_w = 0.375
    panel_h = 0.375
    top_y = 0.565
    bottom_y = 0.090
    ax_a = fig.add_axes([top_left_x, top_y, panel_w, panel_h])
    ax_b = fig.add_axes([top_right_x, top_y, panel_w, panel_h])
    ax_c = fig.add_axes([left_x, bottom_y, panel_w, panel_h])
    ax_d = fig.add_axes([right_x, bottom_y, panel_w, panel_h])

    im = plot_ratio_map(ax_a, ratio, extent, cities_projected)
    plot_void_map(ax_b, void, extent, cities_projected)
    plot_ratio_city(ax_c, stats)
    plot_void_city(ax_d, stats)
    add_aligned_panel_labels(fig, left_x, right_x, top_y, bottom_y, panel_h)

    cax = fig.add_axes([top_left_x + panel_w + 0.008, top_y + 0.035, 0.014, panel_h - 0.070])
    cbar = fig.colorbar(im, cax=cax)
    cbar.set_label("Ratio", fontsize=8)
    cbar.ax.tick_params(labelsize=7, length=2.2)

    stem = FIG_DIR / "Figure6_public_transit_efficiency_service_voids"
    save_outputs(fig, stem)
    plt.close(fig)

    audit = {
        "figure": "Figure 6. Public transit efficiency and service voids",
        "core_conclusion": (
            "Public transit is not merely slower than driving; in parts of Zhejiang it creates "
            "a substantial non-car accessibility disadvantage and potential public-transit service voids."
        ),
        "definitions": {
            "tertiary_public_transit_to_car_ratio": "level3_transit travel time divided by level3_drive travel time",
            "potential_public_transit_service_voids": (
                "grid cells with valid driving travel time to tertiary care but no valid public-transit "
                "travel-time estimate in the supplied tertiary transit raster"
            ),
            "city_mean_ratio": "population-weighted mean ratio among cells with valid driving and transit travel times",
            "city_void_share": "population in potential public-transit service voids divided by city population with valid driving time",
        },
        "key_values": {
            "highest_mean_ratio_city": str(stats.loc[stats["mean_transit_to_car_ratio"].idxmax(), "city"]),
            "highest_mean_ratio": float(stats["mean_transit_to_car_ratio"].max()),
            "highest_void_share_city": str(
                stats.loc[stats["potential_public_transit_service_void_pop_share_pct"].idxmax(), "city"]
            ),
            "highest_void_share_pct": float(stats["potential_public_transit_service_void_pop_share_pct"].max()),
        },
        "inputs": {k: str(v) for k, v in PATHS.items()},
        "outputs": {
            "svg": str(stem.with_suffix(".svg")),
            "pdf": str(stem.with_suffix(".pdf")),
            "png": str(stem.with_suffix(".png")),
            "tiff": str(stem.with_suffix(".tiff")),
            "source_data": str(source_csv),
        },
    }
    (DATA_DIR / "figure6_transit_efficiency_voids_audit.json").write_text(
        json.dumps(audit, indent=2, ensure_ascii=False), encoding="utf-8"
    )


if __name__ == "__main__":
    main()


