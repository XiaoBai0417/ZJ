﻿from __future__ import annotations

import json
from pathlib import Path

import geopandas as gpd
import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import rasterio
from pyproj import Geod
from rasterio import features
from rasterio.enums import Resampling
from rasterio.warp import reproject


BASE = Path("data_external/datasets1")
PROJECT_OUT = Path("outputs")
FIG_DIR = PROJECT_OUT / "figures"
DATA_DIR = PROJECT_OUT / "data"

PATHS = {
    "cities": BASE / "zj_cities.shp",
    "population": BASE / "ZJ_pop.tif",
    "drive_l3": BASE / "level3_drive.tif",
    "transit_l3": BASE / "level3_transit.tif",
}

DISPLAY_CITY = {"Jiaxin": "Jiaxing"}
CITY_PALETTE = {
    "Hangzhou": "#4E79A7",
    "Ningbo": "#59A14F",
    "Wenzhou": "#F28E2B",
    "Jiaxing": "#76B7B2",
    "Huzhou": "#9C755F",
    "Shaoxing": "#B07AA1",
    "Jinhua": "#EDC948",
    "Quzhou": "#8CD17D",
    "Zhoushan": "#499894",
    "Taizhou": "#E15759",
    "Lishui": "#AF7AA1",
}
GROUP_ORDER = ["Urban core", "Transitional", "Mountainous", "Island"]
GROUP_PALETTE = {
    "Urban core": "#3A6EA5",
    "Transitional": "#D19A2A",
    "Mountainous": "#6F8F4E",
    "Island": "#4C9AA0",
}


mpl.rcParams.update(
    {
        "font.family": "sans-serif",
        "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans", "sans-serif"],
        "svg.fonttype": "none",
        "pdf.fonttype": 42,
        "font.size": 8,
        "axes.linewidth": 0.75,
        "axes.spines.right": False,
        "axes.spines.top": False,
        "legend.frameon": False,
        "xtick.major.width": 0.6,
        "ytick.major.width": 0.6,
    }
)


def clean_time(arr: np.ndarray, nodata: float | int | None) -> np.ndarray:
    arr = arr.astype("float32", copy=False)
    if nodata is not None and np.isfinite(nodata):
        arr = np.where(arr == nodata, np.nan, arr)
    return np.where((arr > 0) & (arr <= 3000) & np.isfinite(arr), arr, np.nan)


def clean_population(arr: np.ndarray, nodata: float | int | None) -> np.ndarray:
    arr = arr.astype("float32", copy=False)
    if nodata is not None and np.isfinite(nodata):
        arr = np.where(arr == nodata, 0, arr)
    return np.where((arr > 0) & np.isfinite(arr), arr, 0)


def read_inputs() -> tuple[np.ndarray, np.ndarray, np.ndarray, rasterio.Affine, object]:
    with rasterio.open(PATHS["drive_l3"]) as src:
        drive = clean_time(src.read(1), src.nodata)
        transform = src.transform
        crs = src.crs
        shape = drive.shape
    with rasterio.open(PATHS["transit_l3"]) as src:
        transit = clean_time(src.read(1), src.nodata)
    with rasterio.open(PATHS["population"]) as src:
        pop = clean_population(src.read(1), src.nodata)
        if pop.shape != shape or src.transform != transform or src.crs != crs:
            matched = np.zeros(shape, dtype="float32")
            reproject(
                source=pop,
                destination=matched,
                src_transform=src.transform,
                src_crs=src.crs,
                src_nodata=0,
                dst_transform=transform,
                dst_crs=crs,
                dst_nodata=0,
                resampling=Resampling.bilinear,
            )
            pop = matched
    return drive, transit, pop, transform, crs


def pixel_area_km2(transform: rasterio.Affine, crs, height: int, width: int) -> np.ndarray:
    if crs and crs.is_projected:
        return np.full((height, width), abs(transform.a * transform.e) / 1_000_000, dtype="float32")

    geod = Geod(ellps="WGS84")
    areas = np.zeros((height, width), dtype="float32")
    x_edges = transform.c + np.arange(width + 1) * transform.a
    for row in range(height):
        y_top = transform.f + row * transform.e
        y_bottom = transform.f + (row + 1) * transform.e
        row_values = np.zeros(width, dtype="float32")
        for col in range(width):
            lons = [x_edges[col], x_edges[col + 1], x_edges[col + 1], x_edges[col]]
            lats = [y_top, y_top, y_bottom, y_bottom]
            cell_area, _ = geod.polygon_area_perimeter(lons, lats)
            row_values[col] = abs(cell_area) / 1_000_000
        areas[row, :] = row_values
    return areas


def rasterize_cities(cities: gpd.GeoDataFrame, transform: rasterio.Affine, shape: tuple[int, int]) -> np.ndarray:
    shapes = [(geom, i + 1) for i, geom in enumerate(cities.geometry)]
    return features.rasterize(shapes, out_shape=shape, transform=transform, fill=0, dtype="int16")


def landscape_group(city: str, density: float) -> str:
    if city == "Zhoushan":
        return "Island"
    if density >= 10_000:
        return "Urban core"
    if city in {"Lishui", "Quzhou"}:
        return "Mountainous"
    return "Transitional"


def build_cell_table() -> tuple[pd.DataFrame, pd.DataFrame]:
    cities = gpd.read_file(PATHS["cities"])
    drive, transit, pop, transform, crs = read_inputs()
    if cities.crs != crs:
        cities_for_grid = cities.to_crs(crs)
    else:
        cities_for_grid = cities.copy()
    city_names = [DISPLAY_CITY.get(name, name) for name in cities_for_grid["City_name"]]
    city_grid = rasterize_cities(cities_for_grid, transform, drive.shape)

    area = pixel_area_km2(transform, crs, drive.shape[0], drive.shape[1])
    valid = (city_grid > 0) & np.isfinite(drive) & np.isfinite(transit) & (drive > 0) & (pop > 0) & (area > 0)
    ratio = np.where(valid, transit / drive, np.nan)
    ratio = np.where((ratio >= 1) & (ratio <= 40), ratio, np.nan)
    valid &= np.isfinite(ratio)
    density = np.where(valid, pop / area, np.nan)

    row_idx, col_idx = np.where(valid)
    city = np.array([city_names[i - 1] for i in city_grid[valid]], dtype=object)
    df = pd.DataFrame(
        {
            "row": row_idx,
            "col": col_idx,
            "city": city,
            "population": pop[valid].astype("float64"),
            "cell_area_km2": area[valid].astype("float64"),
            "population_density_per_km2": density[valid].astype("float64"),
            "driving_time_min": drive[valid].astype("float64"),
            "public_transit_time_min": transit[valid].astype("float64"),
            "transit_to_car_ratio": ratio[valid].astype("float64"),
        }
    )
    df["landscape_group"] = [landscape_group(c, d) for c, d in zip(df["city"], df["population_density_per_km2"])]

    city_rows = []
    for city_name, group in df.groupby("city"):
        weights = group["population"].to_numpy()
        city_rows.append(
            {
                "city": city_name,
                "population": float(weights.sum()),
                "weighted_mean_density_per_km2": float(
                    np.average(group["population_density_per_km2"], weights=weights)
                ),
                "weighted_mean_transit_to_car_ratio": float(np.average(group["transit_to_car_ratio"], weights=weights)),
                "median_density_per_km2": float(group["population_density_per_km2"].median()),
                "median_transit_to_car_ratio": float(group["transit_to_car_ratio"].median()),
                "share_pop_density_gt10000_ratio_gt3_pct": float(
                    group.loc[
                        (group["population_density_per_km2"] > 10_000) & (group["transit_to_car_ratio"] > 3),
                        "population",
                    ].sum()
                    / weights.sum()
                    * 100
                ),
            }
        )
    city_stats = pd.DataFrame(city_rows).sort_values("weighted_mean_transit_to_car_ratio", ascending=False)
    return df, city_stats


def sample_for_plot(df: pd.DataFrame, n: int, seed: int = 7) -> pd.DataFrame:
    if len(df) <= n:
        return df.copy()
    return df.sample(n=n, weights="population", random_state=seed).copy()


def add_panel_label(ax: plt.Axes, label: str) -> None:
    ax.text(
        -0.10,
        1.04,
        label,
        transform=ax.transAxes,
        ha="left",
        va="bottom",
        fontsize=11,
        fontweight="bold",
        color="#111111",
    )


def style_scatter_axis(ax: plt.Axes) -> None:
    ax.set_xscale("log")
    ax.set_xlim(30, 80_000)
    ax.set_ylim(1, 15)
    ax.axvline(10_000, color="#555555", lw=0.75, ls="--", zorder=1)
    ax.axhline(3, color="#555555", lw=0.75, ls="--", zorder=1)
    ax.grid(color="#DADADA", linewidth=0.45, zorder=0)
    ax.set_xlabel("Population density (persons km$^{-2}$)")
    ax.set_ylabel("Public transit-to-car ratio")


def plot_density_ratio(ax: plt.Axes, df: pd.DataFrame) -> None:
    plot_df = sample_for_plot(df, 80_000)
    high_inefficient = (plot_df["population_density_per_km2"] > 10_000) & (plot_df["transit_to_car_ratio"] > 3)
    ax.scatter(
        plot_df.loc[~high_inefficient, "population_density_per_km2"],
        plot_df.loc[~high_inefficient, "transit_to_car_ratio"],
        s=2.1,
        c="#B8B8B8",
        alpha=0.25,
        linewidths=0,
        rasterized=True,
    )
    ax.scatter(
        plot_df.loc[high_inefficient, "population_density_per_km2"],
        plot_df.loc[high_inefficient, "transit_to_car_ratio"],
        s=4.0,
        c="#B9403A",
        alpha=0.55,
        linewidths=0,
        rasterized=True,
    )
    style_scatter_axis(ax)
    share_pop = (
        df.loc[
            (df["population_density_per_km2"] > 10_000) & (df["transit_to_car_ratio"] > 3),
            "population",
        ].sum()
        / df["population"].sum()
        * 100
    )
    cell_count = int(((df["population_density_per_km2"] > 10_000) & (df["transit_to_car_ratio"] > 3)).sum())
    ax.text(
        0.97,
        0.94,
        f">{10_000:,} persons km$^{{-2}}$ and ratio >3\n{cell_count:,} cells; {share_pop:.1f}% of exposed population",
        transform=ax.transAxes,
        ha="right",
        va="top",
        fontsize=7.5,
        bbox=dict(facecolor="white", edgecolor="#BDBDBD", boxstyle="round,pad=0.28", alpha=0.94),
    )
    add_panel_label(ax, "a")


def plot_city_colored(ax: plt.Axes, df: pd.DataFrame, city_stats: pd.DataFrame) -> None:
    plot_df = sample_for_plot(df, 60_000, seed=11)
    for city, group in plot_df.groupby("city", sort=False):
        ax.scatter(
            group["population_density_per_km2"],
            group["transit_to_car_ratio"],
            s=2.3,
            alpha=0.34,
            linewidths=0,
            color=CITY_PALETTE.get(city, "#777777"),
            rasterized=True,
        )
    style_scatter_axis(ax)
    ax.set_ylabel("")
    for _, row in city_stats.iterrows():
        ax.scatter(
            row["weighted_mean_density_per_km2"],
            row["weighted_mean_transit_to_car_ratio"],
            s=36,
            color=CITY_PALETTE.get(row["city"], "#777777"),
            edgecolor="white",
            linewidth=0.5,
            zorder=5,
        )
    handles = [
        mpl.lines.Line2D(
            [0],
            [0],
            marker="o",
            linestyle="",
            markersize=4.5,
            markerfacecolor=CITY_PALETTE.get(city, "#777777"),
            markeredgecolor="none",
            label=city,
        )
        for city in city_stats.sort_values("city")["city"]
    ]
    ax.legend(
        handles=handles,
        loc="upper left",
        bbox_to_anchor=(0.01, 0.99),
        ncol=2,
        fontsize=6.3,
        handletextpad=0.25,
        columnspacing=0.55,
        borderaxespad=0,
    )
    add_panel_label(ax, "b")


def plot_group_box(ax: plt.Axes, df: pd.DataFrame) -> None:
    arrays = [
        df.loc[df["landscape_group"] == group, "transit_to_car_ratio"].clip(upper=20).to_numpy()
        for group in GROUP_ORDER
    ]
    box = ax.boxplot(
        arrays,
        vert=True,
        patch_artist=True,
        widths=0.56,
        showfliers=False,
        medianprops=dict(color="#111111", linewidth=1.05),
        whiskerprops=dict(color="#555555", linewidth=0.8),
        capprops=dict(color="#555555", linewidth=0.8),
        boxprops=dict(edgecolor="#333333", linewidth=0.8),
    )
    for patch, group in zip(box["boxes"], GROUP_ORDER):
        patch.set_facecolor(GROUP_PALETTE[group])
        patch.set_alpha(0.82)
    rng = np.random.default_rng(21)
    for idx, group in enumerate(GROUP_ORDER, start=1):
        group_df = df[df["landscape_group"] == group]
        show = sample_for_plot(group_df, 3_000, seed=idx + 20)
        jitter = rng.normal(0, 0.045, size=len(show))
        ax.scatter(
            np.full(len(show), idx) + jitter,
            show["transit_to_car_ratio"].clip(upper=20),
            s=2.0,
            color="#252525",
            alpha=0.12,
            linewidths=0,
            rasterized=True,
        )
        median = group_df["transit_to_car_ratio"].median()
        ax.text(idx, 15.4, f"{median:.1f}", ha="center", va="bottom", fontsize=7.2, color="#111111")
    ax.axhline(3, color="#555555", lw=0.75, ls="--", zorder=1)
    ax.set_ylim(1, 16)
    ax.set_xticks(np.arange(1, len(GROUP_ORDER) + 1))
    ax.set_xticklabels(["Urban\ncore", "Trans.", "Mount.", "Island"], fontsize=6.9, rotation=28, ha="right")
    ax.set_ylabel("Public transit-to-car ratio")
    ax.set_xlabel("Grid-cell context")
    ax.grid(axis="y", color="#DADADA", linewidth=0.45)
    ax.text(0.04, 0.96, "Median ratio", transform=ax.transAxes, ha="left", va="top", fontsize=7.2)
    add_panel_label(ax, "c")


def save_outputs(fig: plt.Figure, stem: Path) -> None:
    fig.savefig(stem.with_suffix(".svg"), bbox_inches="tight")
    fig.savefig(stem.with_suffix(".pdf"), bbox_inches="tight")
    fig.savefig(stem.with_suffix(".png"), dpi=600, bbox_inches="tight")
    fig.savefig(stem.with_suffix(".tiff"), dpi=600, bbox_inches="tight", pil_kwargs={"compression": "tiff_lzw"})


def main() -> None:
    FIG_DIR.mkdir(parents=True, exist_ok=True)
    DATA_DIR.mkdir(parents=True, exist_ok=True)

    df, city_stats = build_cell_table()
    source_csv = DATA_DIR / "figure7_density_transit_efficiency_cells.csv"
    city_csv = DATA_DIR / "figure7_density_transit_efficiency_city_stats.csv"
    df.to_csv(source_csv, index=False, encoding="utf-8-sig")
    city_stats.to_csv(city_csv, index=False, encoding="utf-8-sig")

    fig = plt.figure(figsize=(7.4, 4.4), constrained_layout=False)
    ax_a = fig.add_axes([0.080, 0.160, 0.370, 0.760])
    ax_b = fig.add_axes([0.515, 0.160, 0.250, 0.760])
    ax_c = fig.add_axes([0.810, 0.160, 0.170, 0.760])

    plot_density_ratio(ax_a, df)
    plot_city_colored(ax_b, df, city_stats)
    plot_group_box(ax_c, df)

    stem = FIG_DIR / "Figure7_population_density_transit_efficiency"
    save_outputs(fig, stem)
    plt.close(fig)

    high_dense_inefficient = (df["population_density_per_km2"] > 10_000) & (df["transit_to_car_ratio"] > 3)
    audit = {
        "figure": "Figure 7. Population density versus public transit efficiency",
        "core_conclusion": (
            "High population density does not guarantee efficient public-transit access to tertiary care; "
            "many dense grid cells still have public transit-to-car ratios above 3.0."
        ),
        "definitions": {
            "population_density_per_km2": "WorldPop population divided by raster-cell area in square kilometres",
            "transit_to_car_ratio": "level3 public-transit travel time divided by level3 driving travel time",
            "urban_core": "non-island cells with population density >= 10,000 persons/km2",
            "mountainous": "Lishui and Quzhou cells below the urban-core density threshold",
            "island": "Zhoushan cells",
            "transitional": "remaining cells",
        },
        "key_values": {
            "valid_cells": int(len(df)),
            "dense_inefficient_cells": int(high_dense_inefficient.sum()),
            "dense_inefficient_population": float(df.loc[high_dense_inefficient, "population"].sum()),
            "dense_inefficient_population_share_pct": float(
                df.loc[high_dense_inefficient, "population"].sum() / df["population"].sum() * 100
            ),
            "spearman_density_ratio": float(
                df[["population_density_per_km2", "transit_to_car_ratio"]].corr(method="spearman").iloc[0, 1]
            ),
        },
        "inputs": {k: str(v) for k, v in PATHS.items()},
        "outputs": {
            "svg": str(stem.with_suffix(".svg")),
            "pdf": str(stem.with_suffix(".pdf")),
            "png": str(stem.with_suffix(".png")),
            "tiff": str(stem.with_suffix(".tiff")),
            "cell_source_data": str(source_csv),
            "city_source_data": str(city_csv),
        },
    }
    (DATA_DIR / "figure7_density_transit_efficiency_audit.json").write_text(
        json.dumps(audit, indent=2, ensure_ascii=False), encoding="utf-8"
    )


if __name__ == "__main__":
    main()


