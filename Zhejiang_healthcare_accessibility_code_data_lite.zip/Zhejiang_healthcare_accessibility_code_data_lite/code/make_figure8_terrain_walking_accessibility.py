﻿from __future__ import annotations

import json
from pathlib import Path

import contextily as cx
import geopandas as gpd
import matplotlib as mpl
import matplotlib.colors as mcolors
import matplotlib.patheffects as pe
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import rasterio
from rasterio import features
from rasterio.enums import Resampling
from rasterio.warp import reproject


BASE = Path("data_external/datasets1")
PROJECT_OUT = Path("outputs")
FIG_DIR = PROJECT_OUT / "figures"
DATA_DIR = PROJECT_OUT / "data"

PATHS = {
    "cities": BASE / "zj_cities.shp",
    "population": BASE / "ZJ_pop.tif",
    "level1_walk": BASE / "level1_walk.tif",
    "dem": Path("data_external/terrain/resampled_dem_2.tif"),
}

DISPLAY_CITY = {"Jiaxin": "Jiaxing"}
TARGET_CITIES = {"Jiaxin": "Jiaxing", "Lishui": "Lishui"}
SATELLITE_TILES = cx.providers.Esri.WorldImagery


mpl.rcParams.update(
    {
        "font.family": "sans-serif",
        "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans", "sans-serif"],
        "svg.fonttype": "none",
        "pdf.fonttype": 42,
        "font.size": 8,
        "axes.linewidth": 0.7,
        "axes.spines.right": False,
        "axes.spines.top": False,
        "legend.frameon": False,
        "xtick.major.width": 0.6,
        "ytick.major.width": 0.6,
    }
)


def clean_time(arr: np.ndarray, nodata: float | int | None) -> np.ndarray:
    arr = arr.astype("float32", copy=False)
    if nodata is not None and np.isfinite(nodata):
        arr = np.where(arr == nodata, np.nan, arr)
    return np.where((arr > 0) & (arr <= 3000) & np.isfinite(arr), arr, np.nan)


def clean_positive(arr: np.ndarray, nodata: float | int | None) -> np.ndarray:
    arr = arr.astype("float32", copy=False)
    if nodata is not None and np.isfinite(nodata):
        arr = np.where(arr == nodata, np.nan, arr)
    return np.where(np.isfinite(arr) & (arr > 0), arr, np.nan)


def read_aligned_inputs() -> tuple[np.ndarray, np.ndarray, np.ndarray, rasterio.Affine, object]:
    with rasterio.open(PATHS["level1_walk"]) as src:
        walk = clean_time(src.read(1), src.nodata)
        transform = src.transform
        crs = src.crs
        shape = walk.shape
    with rasterio.open(PATHS["population"]) as src:
        pop = clean_positive(src.read(1), src.nodata)
        if pop.shape != shape or src.transform != transform or src.crs != crs:
            matched = np.full(shape, np.nan, dtype="float32")
            reproject(
                source=pop,
                destination=matched,
                src_transform=src.transform,
                src_crs=src.crs,
                src_nodata=np.nan,
                dst_transform=transform,
                dst_crs=crs,
                dst_nodata=np.nan,
                resampling=Resampling.bilinear,
            )
            pop = matched
    with rasterio.open(PATHS["dem"]) as src:
        dem = np.full(shape, np.nan, dtype="float32")
        reproject(
            source=rasterio.band(src, 1),
            destination=dem,
            src_transform=src.transform,
            src_crs=src.crs,
            src_nodata=src.nodata,
            dst_transform=transform,
            dst_crs=crs,
            dst_nodata=np.nan,
            resampling=Resampling.bilinear,
        )
    dem = np.where(np.isfinite(dem) & (dem > -200), dem, np.nan)
    return dem, walk, pop, transform, crs


def raster_extent(transform: rasterio.Affine, arr: np.ndarray) -> tuple[float, float, float, float]:
    h, w = arr.shape
    left = transform.c
    top = transform.f
    right = left + transform.a * w
    bottom = top + transform.e * h
    return left, right, bottom, top


def hillshade(dem: np.ndarray, azimuth: float = 315, altitude: float = 45) -> np.ndarray:
    fill = np.nanmedian(dem)
    z = np.where(np.isfinite(dem), dem, fill)
    dy, dx = np.gradient(z)
    slope = np.pi / 2 - np.arctan(np.hypot(dx, dy))
    aspect = np.arctan2(-dx, dy)
    az = np.deg2rad(azimuth)
    alt = np.deg2rad(altitude)
    shaded = np.sin(alt) * np.sin(slope) + np.cos(alt) * np.cos(slope) * np.cos(az - aspect)
    return (shaded - np.nanmin(shaded)) / (np.nanmax(shaded) - np.nanmin(shaded))


def city_mask(city_row: pd.Series, shape: tuple[int, int], transform: rasterio.Affine) -> np.ndarray:
    return features.geometry_mask(
        [city_row.geometry],
        out_shape=shape,
        transform=transform,
        invert=True,
        all_touched=True,
    )


def crop_to_mask(
    arrays: list[np.ndarray], mask: np.ndarray, transform: rasterio.Affine, pad: int = 2
) -> tuple[list[np.ndarray], tuple[float, float, float, float]]:
    rows, cols = np.where(mask)
    r0 = max(rows.min() - pad, 0)
    r1 = min(rows.max() + pad + 1, mask.shape[0])
    c0 = max(cols.min() - pad, 0)
    c1 = min(cols.max() + pad + 1, mask.shape[1])
    clipped = []
    for arr in arrays:
        cut = arr[r0:r1, c0:c1].copy()
        mcut = mask[r0:r1, c0:c1]
        clipped.append(np.where(mcut, cut, np.nan))
    left = transform.c + c0 * transform.a
    right = transform.c + c1 * transform.a
    top = transform.f + r0 * transform.e
    bottom = transform.f + r1 * transform.e
    return clipped, (left, right, bottom, top)


def padded_extent_from_geometry(geom, pad_fraction: float = 0.035) -> tuple[float, float, float, float]:
    minx, miny, maxx, maxy = geom.bounds
    dx = maxx - minx
    dy = maxy - miny
    return (
        minx - dx * pad_fraction,
        maxx + dx * pad_fraction,
        miny - dy * pad_fraction,
        maxy + dy * pad_fraction,
    )


def weighted_cdf(values: np.ndarray, weights: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    ok = np.isfinite(values) & np.isfinite(weights) & (weights > 0)
    values = values[ok]
    weights = weights[ok]
    order = np.argsort(values)
    x = values[order]
    y = np.cumsum(weights[order]) / weights.sum()
    return x, y


def city_statistics(cities: gpd.GeoDataFrame, dem: np.ndarray, walk: np.ndarray, pop: np.ndarray, transform) -> pd.DataFrame:
    rows = []
    for _, row in cities.iterrows():
        mask = city_mask(row, dem.shape, transform)
        valid = mask & np.isfinite(walk) & np.isfinite(pop) & (pop > 0)
        terrain_valid = mask & np.isfinite(dem)
        weights = pop[valid]
        walk_values = walk[valid]
        rows.append(
            {
                "city_raw": row["City_name"],
                "city": DISPLAY_CITY.get(row["City_name"], row["City_name"]),
                "population": float(np.nansum(weights)),
                "walking_pwtt_primary_min": float(np.average(walk_values, weights=weights)) if valid.any() else np.nan,
                "walking_median_primary_min": float(np.nanmedian(walk_values)) if valid.any() else np.nan,
                "walking_share_gt120_pct": float(np.nansum(weights[walk_values > 120]) / np.nansum(weights) * 100)
                if valid.any()
                else np.nan,
                "mean_elevation_m": float(np.nanmean(dem[terrain_valid])) if terrain_valid.any() else np.nan,
                "p90_elevation_m": float(np.nanpercentile(dem[terrain_valid], 90)) if terrain_valid.any() else np.nan,
            }
        )
    return pd.DataFrame(rows)


def add_panel_label(ax: plt.Axes, label: str) -> None:
    ax.text(
        -0.08,
        1.04,
        label,
        transform=ax.transAxes,
        ha="left",
        va="bottom",
        fontsize=11,
        fontweight="bold",
        color="#111111",
    )


def add_degree_ticks(ax: plt.Axes) -> None:
    x0, x1 = ax.get_xlim()
    y0, y1 = ax.get_ylim()
    xticks = np.arange(np.ceil(x0 * 2) / 2, np.floor(x1 * 2) / 2 + 0.01, 0.5)
    yticks = np.arange(np.ceil(y0 * 2) / 2, np.floor(y1 * 2) / 2 + 0.01, 0.5)
    ax.set_xticks(xticks)
    ax.set_yticks(yticks)
    ax.tick_params(labelsize=7, direction="out", length=2.5, pad=1.5)
    ax.xaxis.set_major_formatter(mpl.ticker.FuncFormatter(lambda v, _: f"{v:.1f}°E"))
    ax.yaxis.set_major_formatter(mpl.ticker.FuncFormatter(lambda v, _: f"{v:.1f}°N"))


def plot_city_map(
    ax: plt.Axes,
    city_raw: str,
    cities: gpd.GeoDataFrame,
    dem: np.ndarray,
    walk: np.ndarray,
    transform: rasterio.Affine,
    dem_norm: mcolors.Normalize,
    walk_norm: mcolors.Normalize,
) -> mpl.image.AxesImage:
    row = cities.loc[cities["City_name"] == city_raw].iloc[0]
    mask = city_mask(row, dem.shape, transform)
    (dem_c, walk_c), extent = crop_to_mask([dem, walk], mask, transform)
    view_extent = padded_extent_from_geometry(row.geometry)
    shade = hillshade(dem_c)
    ax.set_xlim(view_extent[0], view_extent[1])
    ax.set_ylim(view_extent[2], view_extent[3])
    basemap_extent = None
    try:
        cx.add_basemap(
            ax,
            crs=cities.crs,
            source=SATELLITE_TILES,
            zoom=10,
            attribution=False,
            reset_extent=False,
            alpha=0.95,
            zorder=0,
        )
        basemap_extent = ax.images[-1].get_extent()
    except Exception:
        ax.set_facecolor("#F4F4F0")
    shade_cmap = mpl.colormaps["gray"].copy()
    shade_cmap.set_bad((1, 1, 1, 0))
    ax.imshow(
        np.ma.masked_where(~np.isfinite(dem_c), shade),
        extent=extent,
        origin="upper",
        cmap=shade_cmap,
        vmin=0,
        vmax=1,
        alpha=0.42,
        zorder=1,
    )
    ax.imshow(dem_c, extent=extent, origin="upper", cmap="gist_earth", norm=dem_norm, alpha=0.30, zorder=2)
    walk_c = np.where(np.isfinite(walk_c), np.minimum(walk_c, 180), np.nan)
    cmap = mpl.colormaps["YlOrRd"].copy()
    cmap.set_bad((1, 1, 1, 0))
    im = ax.imshow(np.ma.masked_invalid(walk_c), extent=extent, origin="upper", cmap=cmap, norm=walk_norm, alpha=0.68, zorder=3)
    city_gdf = gpd.GeoDataFrame([row], crs=cities.crs)
    city_gdf.boundary.plot(ax=ax, color="white", linewidth=1.0, zorder=4)
    city_gdf.boundary.plot(ax=ax, color="#222222", linewidth=0.45, zorder=5)
    if basemap_extent is not None:
        ax.set_xlim(basemap_extent[0], basemap_extent[1])
        ax.set_ylim(basemap_extent[2], basemap_extent[3])
    else:
        ax.set_xlim(view_extent[0], view_extent[1])
        ax.set_ylim(view_extent[2], view_extent[3])
    ax.set_aspect("equal", adjustable="box")
    add_degree_ticks(ax)
    label = DISPLAY_CITY.get(city_raw, city_raw)
    ax.text(
        0.04,
        0.06,
        f"{label}: DEM + walking time",
        transform=ax.transAxes,
        ha="left",
        va="bottom",
        fontsize=8,
        color="#111111",
        path_effects=[pe.withStroke(linewidth=2.4, foreground="white", alpha=0.88)],
    )
    for spine in ax.spines.values():
        spine.set_visible(True)
        spine.set_linewidth(0.65)
        spine.set_color("#444444")
    return im


def plot_cdf(ax: plt.Axes, cities: gpd.GeoDataFrame, walk: np.ndarray, pop: np.ndarray, transform) -> pd.DataFrame:
    colors = {"Jiaxin": "#3A6EA5", "Lishui": "#B9403A"}
    rows = []
    for city_raw, display in TARGET_CITIES.items():
        row = cities.loc[cities["City_name"] == city_raw].iloc[0]
        mask = city_mask(row, walk.shape, transform)
        values = walk[mask]
        weights = pop[mask]
        x, y = weighted_cdf(values, weights)
        ax.plot(np.clip(x, 0, 240), y * 100, color=colors[city_raw], lw=1.8, label=display)
        ok = np.isfinite(values) & np.isfinite(weights) & (weights > 0)
        rows.append(
            {
                "city_raw": city_raw,
                "city": display,
                "population": float(np.nansum(weights[ok])),
                "share_within_30_min_pct": float(np.nansum(weights[ok & (values <= 30)]) / np.nansum(weights[ok]) * 100),
                "share_gt120_min_pct": float(np.nansum(weights[ok & (values > 120)]) / np.nansum(weights[ok]) * 100),
                "pwtt_primary_walk_min": float(np.average(values[ok], weights=weights[ok])),
                "median_primary_walk_min": float(np.nanmedian(values[ok])),
            }
        )
    ax.axvline(30, color="#555555", lw=0.75, ls="--")
    ax.axvline(120, color="#555555", lw=0.75, ls=":")
    ax.set_xlim(0, 200)
    ax.set_ylim(0, 100)
    ax.set_xlabel("Walking time to primary care (min)")
    ax.set_ylabel("Population covered (%)")
    ax.grid(color="#DADADA", linewidth=0.45)
    ax.legend(loc="center right", bbox_to_anchor=(0.98, 0.22), fontsize=8)
    ax.text(31.5, 4, "30 min", fontsize=7.3, color="#555555", va="bottom")
    ax.text(121.5, 4, "120 min", fontsize=7.3, color="#555555", va="bottom")
    add_panel_label(ax, "c")
    return pd.DataFrame(rows)


def plot_elevation_bins(ax: plt.Axes, cities: gpd.GeoDataFrame, dem: np.ndarray, walk: np.ndarray, pop: np.ndarray, transform) -> pd.DataFrame:
    colors = {"Jiaxin": "#3A6EA5", "Lishui": "#B9403A"}
    rows = []
    for city_raw, display in TARGET_CITIES.items():
        row = cities.loc[cities["City_name"] == city_raw].iloc[0]
        mask = city_mask(row, dem.shape, transform)
        valid = mask & np.isfinite(dem) & np.isfinite(walk) & np.isfinite(pop) & (pop > 0)
        d = pd.DataFrame({"elevation_m": dem[valid], "walking_time_min": walk[valid], "population": pop[valid]})
        bins = np.linspace(np.nanpercentile(d["elevation_m"], 2), np.nanpercentile(d["elevation_m"], 98), 9)
        d["bin"] = pd.cut(d["elevation_m"], bins=bins, include_lowest=True)
        grouped = []
        for interval, g in d.groupby("bin", observed=True):
            if len(g) < 5:
                continue
            grouped.append(
                {
                    "city_raw": city_raw,
                    "city": display,
                    "elevation_mid_m": float((interval.left + interval.right) / 2),
                    "median_walking_time_min": float(np.nanmedian(g["walking_time_min"])),
                    "population_weighted_walking_time_min": float(
                        np.average(g["walking_time_min"], weights=g["population"])
                    ),
                    "population": float(g["population"].sum()),
                }
            )
        gd = pd.DataFrame(grouped)
        rows.append(gd)
        ax.plot(
            gd["elevation_mid_m"],
            gd["population_weighted_walking_time_min"],
            color=colors[city_raw],
            lw=1.8,
            marker="o",
            ms=3.5,
            label=display,
        )
    out = pd.concat(rows, ignore_index=True)
    ax.axhline(30, color="#555555", lw=0.75, ls="--")
    ax.axhline(120, color="#555555", lw=0.75, ls=":")
    ax.set_xlabel("Elevation bin midpoint (m)")
    ax.set_ylabel("Population-weighted walking time (min)")
    ax.grid(color="#DADADA", linewidth=0.45)
    ax.set_xscale("symlog", linthresh=50, linscale=1.0)
    ax.set_xlim(0, 1400)
    ax.set_xticks([0, 50, 200, 1200])
    ax.xaxis.set_major_formatter(mpl.ticker.ScalarFormatter())
    ax.set_ylim(0, max(140, out["population_weighted_walking_time_min"].max() * 1.10))
    ax.legend(loc="upper left", fontsize=8)
    ax.text(0.14, 0.13, "30 and 120 min thresholds", transform=ax.transAxes, ha="left", va="bottom", fontsize=7.2)
    add_panel_label(ax, "d")
    return out


def save_outputs(fig: plt.Figure, stem: Path) -> None:
    fig.savefig(stem.with_suffix(".svg"), bbox_inches="tight")
    fig.savefig(stem.with_suffix(".pdf"), bbox_inches="tight")
    fig.savefig(stem.with_suffix(".png"), dpi=600, bbox_inches="tight")
    fig.savefig(stem.with_suffix(".tiff"), dpi=600, bbox_inches="tight", pil_kwargs={"compression": "tiff_lzw"})


def main() -> None:
    missing = [str(path) for path in PATHS.values() if not path.exists()]
    if missing:
        raise FileNotFoundError("Missing required inputs:\n" + "\n".join(missing))

    FIG_DIR.mkdir(parents=True, exist_ok=True)
    DATA_DIR.mkdir(parents=True, exist_ok=True)

    cities = gpd.read_file(PATHS["cities"]).to_crs("EPSG:4326")
    dem, walk, pop, transform, crs = read_aligned_inputs()
    cities = cities.to_crs(crs)
    zhejiang_mask = features.geometry_mask(
        cities.geometry,
        out_shape=dem.shape,
        transform=transform,
        invert=True,
        all_touched=True,
    )
    dem = np.where(zhejiang_mask, dem, np.nan)
    walk = np.where(zhejiang_mask, walk, np.nan)
    pop = np.where(zhejiang_mask, pop, np.nan)

    stats = city_statistics(cities, dem, walk, pop, transform)
    stats.to_csv(DATA_DIR / "figure8_city_terrain_walking_stats.csv", index=False, encoding="utf-8-sig")

    fig = plt.figure(figsize=(7.4, 6.2), constrained_layout=False)
    ax_a = fig.add_axes([0.070, 0.560, 0.370, 0.365])
    ax_b = fig.add_axes([0.545, 0.560, 0.310, 0.365])
    ax_c = fig.add_axes([0.105, 0.035, 0.330, 0.340])
    ax_d = fig.add_axes([0.565, 0.035, 0.300, 0.340])

    dem_valid = dem[np.isfinite(dem)]
    dem_norm = mcolors.Normalize(vmin=np.nanpercentile(dem_valid, 2), vmax=np.nanpercentile(dem_valid, 98))
    walk_norm = mcolors.Normalize(vmin=0, vmax=180)
    im_walk = plot_city_map(ax_a, "Jiaxin", cities, dem, walk, transform, dem_norm, walk_norm)
    plot_city_map(ax_b, "Lishui", cities, dem, walk, transform, dem_norm, walk_norm)
    add_panel_label(ax_a, "a")
    add_panel_label(ax_b, "b")

    cax = fig.add_axes([0.300, 0.485, 0.360, 0.014])
    cbar = fig.colorbar(im_walk, cax=cax, orientation="horizontal")
    cbar.set_label("Walking time to primary care (min; values >=180 shown at upper color)", fontsize=8, labelpad=2)
    cbar.ax.tick_params(labelsize=7, length=2.2, pad=1.5)

    cdf_stats = plot_cdf(ax_c, cities, walk, pop, transform)
    cdf_stats.to_csv(DATA_DIR / "figure8_jiaxing_lishui_walking_cdf_stats.csv", index=False, encoding="utf-8-sig")
    elevation_bins = plot_elevation_bins(ax_d, cities, dem, walk, pop, transform)
    elevation_bins.to_csv(DATA_DIR / "figure8_jiaxing_lishui_elevation_bins.csv", index=False, encoding="utf-8-sig")

    stem = FIG_DIR / "Figure8_terrain_effects_walking_accessibility"
    save_outputs(fig, stem)
    plt.close(fig)

    audit = {
        "figure": "Figure 8. Terrain effects on walking accessibility",
        "core_conclusion": (
            "Flat Jiaxing has more spatially continuous walking access to primary care, whereas mountainous "
            "Lishui shows fragmented valley-constrained walking accessibility and a larger population share "
            "beyond long walking-time thresholds."
        ),
        "definitions": {
            "walking_time": "level1_walk travel time raster, interpreted as walking time to primary care",
            "dem": "DEM reprojected to the population/walking raster grid",
            "cdf": "population-weighted cumulative distribution of walking time",
            "city_pwtt": "population-weighted walking time to primary care within each city",
        },
        "key_values": {
            "jiaxing": cdf_stats.loc[cdf_stats["city"].eq("Jiaxing")].iloc[0].to_dict(),
            "lishui": cdf_stats.loc[cdf_stats["city"].eq("Lishui")].iloc[0].to_dict(),
            "max_lishui_elevation_bin_pwtt": float(
                elevation_bins.loc[elevation_bins["city"].eq("Lishui"), "population_weighted_walking_time_min"].max()
            ),
            "max_jiaxing_elevation_bin_pwtt": float(
                elevation_bins.loc[elevation_bins["city"].eq("Jiaxing"), "population_weighted_walking_time_min"].max()
            ),
        },
        "inputs": {k: str(v) for k, v in PATHS.items()},
        "outputs": {
            "svg": str(stem.with_suffix(".svg")),
            "pdf": str(stem.with_suffix(".pdf")),
            "png": str(stem.with_suffix(".png")),
            "tiff": str(stem.with_suffix(".tiff")),
            "city_stats": str(DATA_DIR / "figure8_city_terrain_walking_stats.csv"),
            "cdf_stats": str(DATA_DIR / "figure8_jiaxing_lishui_walking_cdf_stats.csv"),
            "elevation_bins": str(DATA_DIR / "figure8_jiaxing_lishui_elevation_bins.csv"),
        },
    }
    (DATA_DIR / "figure8_terrain_walking_accessibility_audit.json").write_text(
        json.dumps(audit, indent=2, ensure_ascii=False), encoding="utf-8"
    )


if __name__ == "__main__":
    main()


