﻿from __future__ import annotations

import json
from pathlib import Path

import geopandas as gpd
import matplotlib as mpl
import matplotlib.colors as mcolors
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import rasterio
from rasterio import features


BASE = Path("data_external/datasets")
CITY_PATH = Path("data_external/datasets1/zj_cities.shp")
PROJECT_OUT = Path("outputs")
FIG_DIR = PROJECT_OUT / "figures"
DATA_DIR = PROJECT_OUT / "data"

PATHS = {
    "cities": CITY_PATH,
    "population": Path("data_external/datasets1/ZJ_pop.tif"),
    "friction_drive": BASE / "ZJ_Motor_Weiss.tif",
    "friction_walk": BASE / "ZJ_Walk_Weiss.tif",
    "diff_drive": BASE / "diff_motor_nodata.tif",
    "diff_walk": BASE / "ZJ_diff_Walk_nodata.tif",
}

DISPLAY_CITY = {"Jiaxin": "Jiaxing"}


mpl.rcParams.update(
    {
        "font.family": "sans-serif",
        "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans", "sans-serif"],
        "svg.fonttype": "none",
        "pdf.fonttype": 42,
        "font.size": 8,
        "axes.linewidth": 0.7,
        "axes.spines.right": False,
        "axes.spines.top": False,
        "legend.frameon": False,
        "xtick.major.width": 0.6,
        "ytick.major.width": 0.6,
    }
)


def clean_time(arr: np.ndarray, nodata: float | int | None) -> np.ndarray:
    arr = arr.astype("float32", copy=False)
    if nodata is not None and np.isfinite(nodata):
        arr = np.where(arr == nodata, np.nan, arr)
    arr = np.where(arr < -1e20, np.nan, arr)
    return np.where((arr > 0) & (arr <= 5000) & np.isfinite(arr), arr, np.nan)


def clean_diff(arr: np.ndarray, nodata: float | int | None) -> np.ndarray:
    arr = arr.astype("float32", copy=False)
    if nodata is not None and np.isfinite(nodata):
        arr = np.where(arr == nodata, np.nan, arr)
    arr = np.where(arr < -1e20, np.nan, arr)
    return np.where(np.isfinite(arr), arr, np.nan)


def clean_population(arr: np.ndarray, nodata: float | int | None) -> np.ndarray:
    arr = arr.astype("float32", copy=False)
    if nodata is not None and np.isfinite(nodata):
        arr = np.where(arr == nodata, 0, arr)
    arr = np.where(arr < -1e20, 0, arr)
    return np.where((arr > 0) & np.isfinite(arr), arr, 0)


def read_inputs() -> tuple[dict[str, np.ndarray], rasterio.Affine, object]:
    arrays = {}
    with rasterio.open(PATHS["population"]) as src:
        transform = src.transform
        crs = src.crs
        shape = src.shape
        arrays["population"] = clean_population(src.read(1), src.nodata)
    for key in ["friction_drive", "friction_walk"]:
        with rasterio.open(PATHS[key]) as src:
            if src.shape != shape:
                raise ValueError(f"{key} is not aligned to the population grid")
            arrays[key] = clean_time(src.read(1), src.nodata)
    for key in ["diff_drive", "diff_walk"]:
        with rasterio.open(PATHS[key]) as src:
            if src.shape != shape or not np.allclose(tuple(src.transform), tuple(transform), rtol=0, atol=1e-8):
                raise ValueError(f"{key} is not aligned to the population grid")
            arrays[key] = clean_diff(src.read(1), src.nodata)
    arrays["nav_drive"] = np.where(
        np.isfinite(arrays["friction_drive"]) & np.isfinite(arrays["diff_drive"]),
        arrays["friction_drive"] + arrays["diff_drive"],
        np.nan,
    )
    arrays["nav_walk"] = np.where(
        np.isfinite(arrays["friction_walk"]) & np.isfinite(arrays["diff_walk"]),
        arrays["friction_walk"] + arrays["diff_walk"],
        np.nan,
    )
    return arrays, transform, crs


def raster_extent(transform: rasterio.Affine, arr: np.ndarray) -> tuple[float, float, float, float]:
    h, w = arr.shape
    return (transform.c, transform.c + transform.a * w, transform.f + transform.e * h, transform.f)


def city_stats(cities: gpd.GeoDataFrame, arrays: dict[str, np.ndarray], transform) -> pd.DataFrame:
    rows = []
    shape = arrays["population"].shape
    for _, row in cities.iterrows():
        mask = features.geometry_mask([row.geometry], out_shape=shape, transform=transform, invert=True, all_touched=False)
        pop = arrays["population"]
        for mode, diff_key, nav_key, fric_key in [
            ("driving", "diff_drive", "nav_drive", "friction_drive"),
            ("walking", "diff_walk", "nav_walk", "friction_walk"),
        ]:
            diff = arrays[diff_key]
            nav = arrays[nav_key]
            fric = arrays[fric_key]
            valid = mask & np.isfinite(diff)
            pop_valid = valid & (pop > 0)
            rows.append(
                {
                    "city_raw": row["City_name"],
                    "city": DISPLAY_CITY.get(row["City_name"], row["City_name"]),
                    "mode": mode,
                    "mean_delta_min": float(np.nanmean(diff[valid])),
                    "median_delta_min": float(np.nanmedian(diff[valid])),
                    "population_weighted_mean_delta_min": float(np.average(diff[pop_valid], weights=pop[pop_valid]))
                    if pop_valid.any()
                    else np.nan,
                    "navigation_pwtt_min": float(np.average(nav[pop_valid], weights=pop[pop_valid])) if pop_valid.any() else np.nan,
                    "friction_pwtt_min": float(np.average(fric[pop_valid], weights=pop[pop_valid])) if pop_valid.any() else np.nan,
                    "valid_cells": int(valid.sum()),
                }
            )
    return pd.DataFrame(rows)


def weighted_cdf(values: np.ndarray, weights: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    valid = np.isfinite(values) & np.isfinite(weights) & (weights > 0)
    values = values[valid]
    weights = weights[valid]
    order = np.argsort(values)
    x = values[order]
    y = np.cumsum(weights[order]) / weights.sum() * 100
    return x, y


def add_panel_label(ax: plt.Axes, label: str) -> None:
    ax.text(-0.08, 1.04, label, transform=ax.transAxes, ha="left", va="bottom", fontsize=11, fontweight="bold")


def style_map(ax: plt.Axes, cities: gpd.GeoDataFrame) -> None:
    cities.boundary.plot(ax=ax, color="white", linewidth=0.62, alpha=0.90, zorder=4)
    cities.boundary.plot(ax=ax, color="#252525", linewidth=0.20, alpha=0.72, zorder=5)
    ax.set_aspect("equal", adjustable="box")
    ax.set_xticks([])
    ax.set_yticks([])
    for spine in ax.spines.values():
        spine.set_visible(True)
        spine.set_color("#444444")
        spine.set_linewidth(0.65)


def plot_diff_map(ax: plt.Axes, diff: np.ndarray, extent, cities: gpd.GeoDataFrame, norm, label: str) -> mpl.image.AxesImage:
    ax.set_facecolor("#F3F3F0")
    cities.plot(ax=ax, facecolor="#DDDDDD", edgecolor="none", alpha=0.95, zorder=0)
    cmap = mpl.colormaps["RdBu_r"].copy()
    cmap.set_bad((1, 1, 1, 0))
    im = ax.imshow(np.ma.masked_invalid(diff), extent=extent, origin="upper", cmap=cmap, norm=norm, zorder=2)
    style_map(ax, cities)
    ax.text(
        0.04,
        0.06,
        label,
        transform=ax.transAxes,
        ha="left",
        va="bottom",
        fontsize=7.4,
        bbox=dict(facecolor="white", edgecolor="none", alpha=0.78, pad=2),
    )
    return im


def plot_cdf(ax: plt.Axes, nav: np.ndarray, fric: np.ndarray, pop: np.ndarray, mode: str, xlim: tuple[float, float]) -> None:
    xn, yn = weighted_cdf(nav, pop)
    xf, yf = weighted_cdf(fric, pop)
    ax.plot(xn, yn, color="#2F6DA5", lw=1.8, label="Navigation")
    ax.plot(xf, yf, color="#B9403A", lw=1.8, label="Static friction")
    ax.set_xlim(*xlim)
    ax.set_ylim(0, 100)
    ax.set_xlabel("Travel time (min)")
    ax.set_ylabel("Population covered (%)")
    ax.grid(color="#DADADA", linewidth=0.45)
    ax.legend(loc="lower right", fontsize=7.5)
    ax.text(0.04, 0.94, mode.capitalize(), transform=ax.transAxes, ha="left", va="top", fontsize=8.2)


def plot_city_bars(ax: plt.Axes, stats: pd.DataFrame, mode: str, color: str, xlim: tuple[float, float]) -> None:
    d = stats[stats["mode"].eq(mode)].sort_values("mean_delta_min", ascending=True).reset_index(drop=True)
    y = np.arange(len(d))
    colors = np.where(d["mean_delta_min"] < 0, "#3F78A8", color)
    ax.barh(y, d["mean_delta_min"], color=colors, edgecolor="#333333", linewidth=0.28, height=0.68)
    ax.axvline(0, color="#333333", lw=0.75)
    ax.set_yticks(y)
    ax.set_yticklabels(d["city"], fontsize=7.1)
    ax.invert_yaxis()
    ax.set_xlim(*xlim)
    ax.set_xlabel("Mean ΔT (min)")
    ax.grid(axis="x", color="#DADADA", linewidth=0.45)
    if mode == "walking":
        lishui = d.loc[d["city"].eq("Lishui"), "mean_delta_min"].iloc[0]
        zhoushan = d.loc[d["city"].eq("Zhoushan"), "mean_delta_min"].iloc[0]
        ax.text(
            0.03,
            0.05,
            f"Lishui {lishui:.0f} min\nZhoushan {zhoushan:.0f} min",
            transform=ax.transAxes,
            ha="left",
            va="bottom",
            fontsize=7.2,
            bbox=dict(facecolor="white", edgecolor="#BBBBBB", boxstyle="round,pad=0.25", alpha=0.94),
        )


def save_outputs(fig: plt.Figure, stem: Path) -> None:
    fig.savefig(stem.with_suffix(".svg"), bbox_inches="tight")
    fig.savefig(stem.with_suffix(".pdf"), bbox_inches="tight")
    fig.savefig(stem.with_suffix(".png"), dpi=600, bbox_inches="tight")
    fig.savefig(stem.with_suffix(".tiff"), dpi=600, bbox_inches="tight", pil_kwargs={"compression": "tiff_lzw"})


def main() -> None:
    missing = [str(path) for path in PATHS.values() if not path.exists()]
    if missing:
        raise FileNotFoundError("Missing required inputs:\n" + "\n".join(missing))
    FIG_DIR.mkdir(parents=True, exist_ok=True)
    DATA_DIR.mkdir(parents=True, exist_ok=True)

    arrays, transform, crs = read_inputs()
    cities = gpd.read_file(PATHS["cities"]).to_crs(crs)
    zhejiang_mask = features.geometry_mask(cities.geometry, out_shape=arrays["population"].shape, transform=transform, invert=True, all_touched=True)
    for key in arrays:
        arrays[key] = np.where(zhejiang_mask, arrays[key], np.nan if key != "population" else 0)

    stats = city_stats(cities, arrays, transform)
    stats.to_csv(DATA_DIR / "figure9_navigation_friction_city_stats.csv", index=False, encoding="utf-8-sig")
    extent = raster_extent(transform, arrays["population"])

    fig = plt.figure(figsize=(7.4, 5.8), constrained_layout=False)
    row_h = 0.285
    top_y = 0.585
    bottom_y = 0.135
    ax_a = fig.add_axes([0.045, top_y, 0.285, row_h])
    ax_b = fig.add_axes([0.390, top_y, 0.245, row_h])
    ax_c = fig.add_axes([0.745, top_y, 0.210, row_h])
    ax_d = fig.add_axes([0.045, bottom_y, 0.285, row_h])
    ax_e = fig.add_axes([0.390, bottom_y, 0.245, row_h])
    ax_f = fig.add_axes([0.745, bottom_y, 0.210, row_h])

    drive_norm = mcolors.TwoSlopeNorm(vmin=-120, vcenter=0, vmax=60)
    walk_norm = mcolors.TwoSlopeNorm(vmin=-420, vcenter=0, vmax=120)
    im_drive = plot_diff_map(ax_a, arrays["diff_drive"], extent, cities, drive_norm, "Driving ΔT")
    plot_cdf(ax_b, arrays["nav_drive"], arrays["friction_drive"], arrays["population"], "driving", (0, 180))
    plot_city_bars(ax_c, stats, "driving", "#B9403A", (-8, 9))
    im_walk = plot_diff_map(ax_d, arrays["diff_walk"], extent, cities, walk_norm, "Walking ΔT")
    plot_cdf(ax_e, arrays["nav_walk"], arrays["friction_walk"], arrays["population"], "walking", (0, 500))
    plot_city_bars(ax_f, stats, "walking", "#B9403A", (-220, 40))
    add_panel_label(ax_a, "a")
    add_panel_label(ax_b, "b")
    add_panel_label(ax_c, "c")
    add_panel_label(ax_d, "d")
    add_panel_label(ax_e, "e")
    add_panel_label(ax_f, "f")

    cax1 = fig.add_axes([0.075, 0.540, 0.225, 0.012])
    cb1 = fig.colorbar(im_drive, cax=cax1, orientation="horizontal")
    cb1.set_label("Driving ΔT (min)", fontsize=7.6, labelpad=1)
    cb1.ax.tick_params(labelsize=6.8, length=2.0, pad=1)
    cax2 = fig.add_axes([0.075, 0.090, 0.225, 0.012])
    cb2 = fig.colorbar(im_walk, cax=cax2, orientation="horizontal")
    cb2.set_label("Walking ΔT (min)", fontsize=7.6, labelpad=1)
    cb2.ax.tick_params(labelsize=6.8, length=2.0, pad=1)

    fig.text(
        0.52,
        0.965,
        r"$\Delta T=T_{\mathrm{navigation}}-T_{\mathrm{friction}}$; negative values mean static friction is longer",
        ha="center",
        va="top",
        fontsize=7.2,
    )

    stem = FIG_DIR / "Figure9_navigation_static_friction_comparison"
    save_outputs(fig, stem)
    plt.close(fig)

    audit = {
        "figure": "Figure 9. Navigation-based versus static friction-based estimates",
        "delta_definition": "ΔT = T_navigation − T_friction",
        "interpretation": {
            "positive": "navigation-based estimate is longer than static friction-based estimate",
            "negative": "static friction-based estimate is longer than navigation-based estimate",
        },
        "key_values": {
            "lishui_walking_mean_delta_unweighted_min": float(
                stats.loc[(stats["city"].eq("Lishui")) & (stats["mode"].eq("walking")), "mean_delta_min"].iloc[0]
            ),
            "zhoushan_walking_mean_delta_unweighted_min": float(
                stats.loc[(stats["city"].eq("Zhoushan")) & (stats["mode"].eq("walking")), "mean_delta_min"].iloc[0]
            ),
            "overall_driving_mean_delta_unweighted_min": float(np.nanmean(arrays["diff_drive"])),
            "overall_walking_mean_delta_unweighted_min": float(np.nanmean(arrays["diff_walk"])),
        },
        "consistency_note": (
            "The mapped and city-level ΔT values use navigation minus friction. Under this definition, the large "
            "negative Lishui and Zhoushan walking differences mean the static friction surface is longer, not shorter, "
            "than the navigation-based walking surface in those places."
        ),
        "inputs": {k: str(v) for k, v in PATHS.items()},
        "cdf_note": "Navigation CDFs are reconstructed on the aligned comparison grid as T_friction + ΔT.",
        "grid_note": (
            "Friction rasters have the same row-column shape as the difference and population rasters but slightly "
            "different affine origins in metadata; comparisons use row-column pairing from the supplied benchmark "
            "outputs, with maps georeferenced to the cleaned ΔT rasters."
        ),
        "outputs": {
            "svg": str(stem.with_suffix(".svg")),
            "pdf": str(stem.with_suffix(".pdf")),
            "png": str(stem.with_suffix(".png")),
            "tiff": str(stem.with_suffix(".tiff")),
            "city_stats": str(DATA_DIR / "figure9_navigation_friction_city_stats.csv"),
        },
    }
    (DATA_DIR / "figure9_navigation_friction_audit.json").write_text(
        json.dumps(audit, indent=2, ensure_ascii=False), encoding="utf-8"
    )


if __name__ == "__main__":
    main()


