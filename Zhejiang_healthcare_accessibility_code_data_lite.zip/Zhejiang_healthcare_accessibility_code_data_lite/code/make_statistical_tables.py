﻿from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd
import geopandas as gpd
import rasterio
from rasterio import features


PROJECT_OUT = Path("outputs")
DATA_DIR = PROJECT_OUT / "data"
TABLE_DIR = PROJECT_OUT / "tables_revision"
TABLE_DIR.mkdir(parents=True, exist_ok=True)
HEALTHCARE_BASE = Path("data_external/healthcare_zj")


DISPLAY_CITY = {"Jiaxin": "Jiaxing"}
METRIC_KEYS = [
    "drive_l1",
    "drive_l2",
    "drive_l3",
    "transit_l1",
    "transit_l2",
    "transit_l3",
    "walk_l1",
    "walk_l2",
    "walk_l3",
]
METRIC_LABELS = {
    "drive_l1": "Driving-primary",
    "drive_l2": "Driving-secondary",
    "drive_l3": "Driving-tertiary",
    "transit_l1": "Public transit-primary",
    "transit_l2": "Public transit-secondary",
    "transit_l3": "Public transit-tertiary",
    "walk_l1": "Walking-primary",
    "walk_l2": "Walking-secondary",
    "walk_l3": "Walking-tertiary",
}
MODES = {"drive": "Driving", "transit": "Public transit", "walk": "Walking"}
TIERS = {"l1": "Primary", "l2": "Secondary", "l3": "Tertiary"}


def r1(x):
    return np.round(pd.to_numeric(x, errors="coerce"), 1)


def r2(x):
    return np.round(pd.to_numeric(x, errors="coerce"), 2)


def read_csv(name: str) -> pd.DataFrame:
    return pd.read_csv(DATA_DIR / name)


def table1_data_sources() -> pd.DataFrame:
    return pd.DataFrame(
        [
            {
                "Dataset": "WorldPop population grid",
                "Source": "WorldPop",
                "Year / period": "2020",
                "Spatial scale": "1 km grid",
                "Key variables": "Population count",
                "Use in this study": "Population exposure and population-weighted travel time",
            },
            {
                "Dataset": "DEM / terrain",
                "Source": "DEM source; confirm final citation",
                "Year / period": "Confirm final year",
                "Spatial scale": "Raster",
                "Key variables": "Elevation, slope",
                "Use in this study": "Geographic context and terrain mechanism analysis",
            },
            {
                "Dataset": "Healthcare POIs",
                "Source": "AMap POI records",
                "Year / period": "Confirm collection year",
                "Spatial scale": "Point",
                "Key variables": "Facility name, tier/category, coordinates",
                "Use in this study": "Tiered healthcare supply and nearest-facility analysis",
            },
            {
                "Dataset": "AMap route planning",
                "Source": "AMap route planning API",
                "Year / period": "Confirm query period",
                "Spatial scale": "Origin-destination route",
                "Key variables": "Travel time by driving, public transit and walking",
                "Use in this study": "Navigation-based multimodal travel impedance",
            },
            {
                "Dataset": "Static friction surface",
                "Source": "Weiss et al. global healthcare travel-time surface",
                "Year / period": "Around 2019/2020",
                "Spatial scale": "Raster",
                "Key variables": "Static friction-based travel time to healthcare",
                "Use in this study": "Comparison with navigation-based estimates",
            },
            {
                "Dataset": "Administrative boundaries",
                "Source": "Official/public administrative boundary data; confirm citation",
                "Year / period": "Confirm boundary vintage",
                "Spatial scale": "City polygon",
                "Key variables": "City name, administrative code, geometry",
                "Use in this study": "Spatial aggregation, mapping and city-level summaries",
            },
        ]
    )


def table2_city_supply(grid: pd.DataFrame) -> pd.DataFrame:
    supply = read_csv("figure2_city_healthcare_supply.csv")
    supply["City"] = supply["City_display"].replace(DISPLAY_CITY)
    cells = (
        grid.loc[grid["population"].gt(0)]
        .assign(City=lambda d: d["City"].replace(DISPLAY_CITY))
        .groupby("City")
        .size()
        .rename("Populated grid cells")
        .reset_index()
    )
    out = supply.merge(cells, on="City", how="left")
    out = out.rename(
        columns={
            "population": "Population",
            "primary": "Primary facilities",
            "secondary": "Secondary facilities",
            "tertiary": "Tertiary facilities",
            "total_count": "Total facilities",
            "facilities_per_10k": "Facilities per 10,000 people",
            "tertiary_share_pct": "Tertiary share (%)",
        }
    )
    cols = [
        "City",
        "Population",
        "Populated grid cells",
        "Primary facilities",
        "Secondary facilities",
        "Tertiary facilities",
        "Total facilities",
        "Facilities per 10,000 people",
        "Tertiary share (%)",
    ]
    out = out[cols].sort_values("Population", ascending=False)
    out["Population"] = out["Population"].round(0).astype("Int64")
    out["Facilities per 10,000 people"] = r2(out["Facilities per 10,000 people"])
    out["Tertiary share (%)"] = r2(out["Tertiary share (%)"])
    return out


def table3_pwtt_coverage() -> pd.DataFrame:
    df = read_csv("figure4_pwtt_coverage_metrics.csv")
    distribution = read_csv("figure3_accessibility_matrix_metrics.csv")[["key", "median", "p90"]]
    df = df.merge(distribution, on="key", how="left", suffixes=("", "_fig3"))
    out = pd.DataFrame(
        {
            "Travel mode": df["mode"],
            "Healthcare tier": df["tier"],
            "PWTT (min)": r1(df.get("label_pwtt_min", df["pwtt_min"])),
            "Median (min)": r1(df["median"]),
            "P90 (min)": r1(df["p90"]),
            "15-min coverage (%)": r2(df["coverage_15min_pct"]),
            "30-min coverage (%)": r2(df["coverage_30min_pct"]),
            "60-min coverage (%)": r2(df["coverage_60min_pct"]),
            "Uncovered beyond 30 min (million)": r2(df["beyond_30min_pop"] / 1_000_000),
        }
    )
    return out


def table4_transit_disadvantage() -> pd.DataFrame:
    profiles = read_csv("figure5_city_accessibility_profiles.csv")
    voids = read_csv("figure6_transit_efficiency_voids_city_stats.csv")
    profiles["City"] = profiles["city"].replace(DISPLAY_CITY)
    voids["City"] = voids["city"].replace(DISPLAY_CITY)
    out = profiles.merge(voids, on="City", how="left", suffixes=("", "_void"))
    out = pd.DataFrame(
        {
            "City": out["City"],
            "Driving PWTT to tertiary care (min)": r1(out["driving_tertiary_pwtt"]),
            "Public transit PWTT to tertiary care (min)": r1(out["transit_tertiary_pwtt"]),
            "Transit-to-car ratio": r2(out["mean_transit_to_car_ratio"]),
            "Population in potential transit service voids": out[
                "potential_public_transit_service_void_pop"
            ].round(0).astype("Int64"),
            "Potential transit service void share (%)": r2(
                out["potential_public_transit_service_void_pop_share_pct"]
            ),
        }
    )
    return out.sort_values("Transit-to-car ratio", ascending=False)


def table5_typology() -> pd.DataFrame:
    summary = read_csv("figure10_accessibility_regime_summary.csv")
    rows = {
        "Type A": {
            "Main locations": "Hangzhou / Ningbo / Wenzhou urban cores",
            "Accessibility profile": "Favorable multimodal access",
            "Main constraint": "Limited",
            "Planning implication": "Maintain integrated multimodal access",
        },
        "Type B": {
            "Main locations": "Jiaxing / Shaoxing / Jinhua / Taizhou transition belt",
            "Accessibility profile": "Good driving access, weaker public transit",
            "Main constraint": "Car dependence",
            "Planning implication": "Improve transit-to-hospital connectivity",
        },
        "Type C": {
            "Main locations": "Peripheral and island areas, including Zhoushan",
            "Accessibility profile": "Weaker multimodal access",
            "Main constraint": "Geographic separation",
            "Planning implication": "Improve cross-region referral and transport links",
        },
        "Type D": {
            "Main locations": "Lishui / Quzhou and southwest mountainous hinterland",
            "Accessibility profile": "Least favorable access",
            "Main constraint": "Terrain and potential transit service voids",
            "Planning implication": "Strengthen local primary care and mobile/referral services",
        },
    }
    out = []
    for _, row in summary.iterrows():
        item = rows[row["type"]].copy()
        item.update(
            {
                "Type": row["type"],
                "Population share (%)": round(float(row["reported_population_share_pct"]), 2),
            }
        )
        out.append(item)
    return pd.DataFrame(out)[
        [
            "Type",
            "Main locations",
            "Population share (%)",
            "Accessibility profile",
            "Main constraint",
            "Planning implication",
        ]
    ]


def supp_s1_city_pwtt(grid: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for city, group in grid.assign(City=lambda d: d["City"].replace(DISPLAY_CITY)).groupby("City"):
        weights = group["population"].to_numpy(dtype=float)
        row = {"City": city}
        for key in METRIC_KEYS:
            valid = group[key].notna() & group["population"].gt(0)
            row[METRIC_LABELS[key]] = (
                round(float(np.average(group.loc[valid, key], weights=group.loc[valid, "population"])), 1)
                if valid.any()
                else np.nan
            )
        rows.append(row)
    return pd.DataFrame(rows).sort_values("City")


def supp_s2_city_coverage(grid: pd.DataFrame) -> pd.DataFrame:
    rows = []
    g = grid.assign(City=lambda d: d["City"].replace(DISPLAY_CITY))
    for city, group in g.groupby("City"):
        for key in METRIC_KEYS:
            mode_key, tier_key = key.split("_")
            valid = group[key].notna() & group["population"].gt(0)
            denom = float(group.loc[valid, "population"].sum())
            row = {"City": city, "Mode": MODES[mode_key], "Tier": TIERS[tier_key]}
            for threshold in [15, 30, 60, 120]:
                if denom:
                    covered = float(group.loc[valid & group[key].le(threshold), "population"].sum())
                    row[f"{threshold}-min coverage (%)"] = round(covered / denom * 100, 2)
                else:
                    row[f"{threshold}-min coverage (%)"] = np.nan
            rows.append(row)
    return pd.DataFrame(rows).sort_values(["City", "Mode", "Tier"])


def supp_s3_navigation_friction() -> pd.DataFrame:
    df = read_csv("figure9_navigation_friction_city_stats.csv")
    p90 = city_difference_p90()
    wide = df.pivot(index="city", columns="mode")
    out = pd.DataFrame(
        {
            "City": wide.index,
            "Driving mean difference (min)": r1(wide["mean_delta_min"]["driving"]),
            "Driving median difference (min)": r1(wide["median_delta_min"]["driving"]),
            "Walking mean difference (min)": r1(wide["mean_delta_min"]["walking"]),
            "Walking median difference (min)": r1(wide["median_delta_min"]["walking"]),
            "Walking P90 difference (min)": r1([p90.get(city, np.nan) for city in wide.index]),
        }
    ).reset_index(drop=True)
    return out.sort_values("Walking mean difference (min)")


def city_difference_p90() -> dict[str, float]:
    diff_path = HEALTHCARE_BASE / "datasets" / "ZJ_diff_Walk_nodata.tif"
    city_path = HEALTHCARE_BASE / "datasets1" / "zj_cities.shp"
    if not diff_path.exists() or not city_path.exists():
        return {}
    with rasterio.open(diff_path) as src:
        diff = src.read(1).astype("float32")
        if src.nodata is not None and np.isfinite(src.nodata):
            diff = np.where(diff == src.nodata, np.nan, diff)
        diff = np.where(diff < -1e20, np.nan, diff)
        transform = src.transform
        crs = src.crs
        shape = src.shape
    cities = gpd.read_file(city_path).to_crs(crs)
    out: dict[str, float] = {}
    for _, row in cities.iterrows():
        mask = features.geometry_mask([row.geometry], out_shape=shape, transform=transform, invert=True, all_touched=False)
        values = diff[mask & np.isfinite(diff)]
        name = DISPLAY_CITY.get(row["City_name"], row["City_name"])
        out[name] = float(np.nanpercentile(values, 90)) if values.size else np.nan
    return out


def supp_s4_cluster_centers() -> pd.DataFrame:
    summary = read_csv("figure10_accessibility_regime_summary.csv")
    out = summary[["type", *METRIC_KEYS]].copy()
    out = out.rename(columns={"type": "Type", **METRIC_LABELS})
    for col in out.columns:
        if col != "Type":
            out[col] = r1(out[col])
    return out


def supp_s5_poi_rules() -> pd.DataFrame:
    return pd.DataFrame(
        [
            {
                "Tier": "Primary",
                "Keyword examples": "community health service center; township health center; clinic",
                "Included facility types": "Primary care, community-level and township-level healthcare facilities",
                "Excluded / ambiguous cases": "Non-medical services, pharmacies, duplicated branch POIs",
            },
            {
                "Tier": "Secondary",
                "Keyword examples": "county hospital; district hospital; specialized hospital",
                "Included facility types": "County/district hospitals and specialized hospitals with secondary-level service role",
                "Excluded / ambiguous cases": "Facilities with unclear recorded hierarchy; ambiguous POIs require manual review",
            },
            {
                "Tier": "Tertiary",
                "Keyword examples": "provincial hospital; university-affiliated hospital; major municipal hospital",
                "Included facility types": "Provincial, university-affiliated and major municipal hospitals",
                "Excluded / ambiguous cases": "Branch campuses without independent tertiary service capacity unless recorded as such",
            },
        ]
    )


def write_outputs(tables: dict[str, pd.DataFrame]) -> None:
    xlsx_path = TABLE_DIR / "Zhejiang_healthcare_accessibility_tables.xlsx"
    with pd.ExcelWriter(xlsx_path, engine="openpyxl") as writer:
        for name, df in tables.items():
            df.to_excel(writer, sheet_name=name[:31], index=False)
            ws = writer.book[name[:31]]
            ws.freeze_panes = "A2"
            for col_cells in ws.columns:
                max_len = max(len(str(cell.value)) if cell.value is not None else 0 for cell in col_cells)
                ws.column_dimensions[col_cells[0].column_letter].width = min(max(max_len + 2, 10), 45)

    for name, df in tables.items():
        df.to_csv(TABLE_DIR / f"{name}.csv", index=False, encoding="utf-8-sig")

    inventory = pd.DataFrame(
        [
            {"Table": name, "Rows": len(df), "Columns": len(df.columns), "Output": f"{name}.csv"}
            for name, df in tables.items()
        ]
    )
    inventory.to_csv(TABLE_DIR / "tables_inventory.csv", index=False, encoding="utf-8-sig")


def main() -> None:
    grid = pd.read_parquet(DATA_DIR / "health_place_grid_table.parquet")
    tables = {
        "Table1_Data_sources": table1_data_sources(),
        "Table2_City_supply": table2_city_supply(grid),
        "Table3_PWTT_coverage": table3_pwtt_coverage(),
        "Table4_Transit_voids": table4_transit_disadvantage(),
        "Table5_Typology": table5_typology(),
        "TableS1_City_PWTT": supp_s1_city_pwtt(grid),
        "TableS2_City_coverage": supp_s2_city_coverage(grid),
        "TableS3_Nav_friction": supp_s3_navigation_friction(),
        "TableS4_Kmeans_centers": supp_s4_cluster_centers(),
        "TableS5_POI_rules": supp_s5_poi_rules(),
    }
    write_outputs(tables)


if __name__ == "__main__":
    main()


