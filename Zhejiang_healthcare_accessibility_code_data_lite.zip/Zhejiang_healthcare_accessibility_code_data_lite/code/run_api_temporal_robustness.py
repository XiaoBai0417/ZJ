﻿"""Optional live routing robustness script.

Set TENCENT_MAP_KEYS as a comma-separated list. This script is intentionally
separate from the main analysis because it consumes live API quota.
"""
import os
from pathlib import Path
import pandas as pd

SAMPLE = Path("source_data/api_robustness_origin_sample.csv")
OUT = Path("source_data/api_temporal_robustness_results.csv")

keys = [k.strip() for k in os.environ.get("TENCENT_MAP_KEYS", "").split(",") if k.strip()]
if not keys:
    raise SystemExit("Set TENCENT_MAP_KEYS before running live API robustness queries.")

df = pd.read_csv(SAMPLE)
print(f"Loaded {len(df)} sampled origins. Add destination reconstruction before live query if needed.")
print("This scaffold preserves the sampling design; live OD querying should use the nearest-facility destinations from the original URL files.")


