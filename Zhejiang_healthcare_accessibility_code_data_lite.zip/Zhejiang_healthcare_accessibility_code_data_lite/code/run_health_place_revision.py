﻿from pathlib import Path
import json
import math
import warnings

import geopandas as gpd
import matplotlib
matplotlib.use("Agg")
import matplotlib.colors as mcolors
import matplotlib.patches as mpatches
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import rasterio
from rasterio import features
from rasterio.enums import Resampling
from rasterio.warp import reproject
from scipy.stats import spearmanr
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
import statsmodels.api as sm
from docx import Document
from docx.shared import Inches, Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH

warnings.filterwarnings("ignore", category=UserWarning)


BASE = Path("data_external/datasets1")
AG_DIR = Path("outputs")
ORIGINAL_MS = AG_DIR / "MS.docx"
OUT = AG_DIR / "revision_health_place"
FIG_DIR = OUT / "figures"
SUPP_FIG_DIR = OUT / "supplement_figures"
TABLE_DIR = OUT / "tables"
DATA_DIR = OUT / "data"
CODE_DIR = Path("code")

for folder in [OUT, FIG_DIR, SUPP_FIG_DIR, TABLE_DIR, DATA_DIR, CODE_DIR]:
    folder.mkdir(parents=True, exist_ok=True)

PATHS = {
    "pop": BASE / "ZJ_pop.tif",
    "cities": BASE / "zj_cities.shp",
    "hosp_l1": Path("data_external/healthcare_zj/zj_L1.shp"),
    "hosp_l2": Path("data_external/healthcare_zj/zj_L2.shp"),
    "hosp_l3": Path("data_external/healthcare_zj/zj_L3.shp"),
    "elderly65": Path("data_external/vulnerability/elderly_65_plus_1km.tif"),
    "elderly70": Path("data_external/vulnerability/elderly_70_74_1km.tif"),
    "elderly75": Path("data_external/vulnerability/elderly_75_79_1km.tif"),
    "elderly80": Path("data_external/vulnerability/elderly_80_plus_1km.tif"),
    "slope": Path("data_external/terrain/new_slope.tif"),
    "dem": Path("data_external/terrain/resampled_dem_2.tif"),
    "gdp": Path("data_external/context/new_GDP.tif"),
    "urban": Path("data_external/context/GUB_city.tif"),
    "weiss_drive": BASE / "ZJ_Motor_Weiss.tif",
    "weiss_walk": BASE / "ZJ_Walk_Weiss.tif",
}

TIME_PATHS = {
    "drive_l1": BASE / "level1_drive.tif",
    "drive_l2": BASE / "level2_drive.tif",
    "drive_l3": BASE / "level3_drive.tif",
    "transit_l1": BASE / "level1_transit.tif",
    "transit_l2": BASE / "level2_transit.tif",
    "transit_l3": BASE / "level3_transit.tif",
    "walk_l1": BASE / "level1_walk.tif",
    "walk_l2": BASE / "level2_walk.tif",
    "walk_l3": BASE / "level3_walk.tif",
}

CITY_FIX = {"Jiaxin": "Jiaxing"}

FONT_FAMILY = ["Arial", "DejaVu Sans", "Liberation Sans", "sans-serif"]
NATURE_PALETTE = {
    "blue": "#0F4D92",
    "blue_soft": "#3775BA",
    "teal": "#42949E",
    "green": "#6BAF6E",
    "green_soft": "#DDF3DE",
    "orange": "#D98C3A",
    "red": "#B64342",
    "red_soft": "#F6CFCB",
    "neutral_light": "#E8E8E8",
    "neutral_mid": "#A8A8A8",
    "neutral_dark": "#4D4D4D",
    "black": "#272727",
}
MODE_COLORS = {"Driving": NATURE_PALETTE["blue"], "Transit": NATURE_PALETTE["orange"], "Walking": NATURE_PALETTE["green"]}
MODE_LABELS = {"drive": "Driving", "transit": "Transit", "walk": "Walking"}
TIER_LABELS = {"l1": "Primary care", "l2": "Secondary care", "l3": "Tertiary care"}
HOSPITAL_SHP = {"L1": PATHS["hosp_l1"], "L2": PATHS["hosp_l2"], "L3": PATHS["hosp_l3"]}
GRID_SHAPE = None



def apply_pub_style(base_size=7):
    plt.rcParams["font.family"] = "sans-serif"
    plt.rcParams["font.sans-serif"] = FONT_FAMILY
    plt.rcParams["svg.fonttype"] = "none"
    plt.rcParams["pdf.fonttype"] = 42
    plt.rcParams["ps.fonttype"] = 42
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["mathtext.fontset"] = "dejavusans"
    plt.rcParams["xtick.direction"] = "out"
    plt.rcParams["ytick.direction"] = "out"
    plt.rcParams["font.size"] = base_size
    plt.rcParams["axes.labelsize"] = base_size
    plt.rcParams["axes.titlesize"] = base_size + 0.5
    plt.rcParams["xtick.labelsize"] = base_size - 0.5
    plt.rcParams["ytick.labelsize"] = base_size - 0.5
    plt.rcParams["legend.fontsize"] = base_size - 0.5
    plt.rcParams["axes.linewidth"] = 0.6
    plt.rcParams["axes.spines.top"] = False
    plt.rcParams["axes.spines.right"] = False
    plt.rcParams["legend.frameon"] = False
    plt.rcParams["savefig.dpi"] = 600
    plt.rcParams["savefig.bbox"] = "tight"


def format_map_axis(ax, grid=True):
    ax.set_xlabel("Longitude")
    ax.set_ylabel("Latitude")
    ax.tick_params(axis="both", which="major", length=2.2, width=0.5, pad=1.5)
    if grid:
        ax.grid(True, linestyle="-", alpha=0.16, color=NATURE_PALETTE["neutral_mid"], linewidth=0.35)
    for spine in ax.spines.values():
        spine.set_linewidth(0.55)
        spine.set_edgecolor(NATURE_PALETTE["neutral_dark"])


def add_slim_colorbar(fig, im, ax, label=None, labelsize=6.5):
    cbar = fig.colorbar(im, ax=ax, fraction=0.030, pad=0.025)
    if label:
        cbar.set_label(label, fontsize=labelsize)
    cbar.ax.tick_params(labelsize=6, length=2.0, width=0.45)
    cbar.outline.set_linewidth(0.45)
    return cbar


def panel_label(ax, label):
    if not label:
        return
    ax.text(
        -0.06, 1.02, label, transform=ax.transAxes, ha="left", va="bottom",
        fontsize=8, fontweight="bold", color=NATURE_PALETTE["black"],
        zorder=30,
    )


def add_panel_label(ax, label):
    panel_label(ax, label)


def grid_array(df, column):
    if GRID_SHAPE is None:
        h = int(df["row"].max()) + 1
        w = int(df["col"].max()) + 1
    else:
        h, w = GRID_SHAPE
    arr = np.full((h, w), np.nan, dtype="float64")
    ok = df[column].notna()
    arr[df.loc[ok, "row"].astype(int), df.loc[ok, "col"].astype(int)] = df.loc[ok, column].astype(float)
    return arr


def draw_raster_map(ax, arr, extent, title, cbar_label, cmap="viridis", vmin=None, vmax=None, boundary=True, cbar=True):
    im = ax.imshow(arr, extent=extent, origin="upper", cmap=cmap, vmin=vmin, vmax=vmax, interpolation="nearest")
    ax.set_title(title)
    format_map_axis(ax)
    if cbar:
        add_slim_colorbar(ax.figure, im, ax, cbar_label)
    if boundary:
        try:
            cities.boundary.to_crs("EPSG:4326").plot(ax=ax, color="black", linewidth=0.32, alpha=0.65)
        except Exception:
            pass
    return im


def draw_binary_map(ax, arr, extent, title, labels, colors, boundary=True):
    cmap = mcolors.ListedColormap(colors)
    im = ax.imshow(arr, extent=extent, origin="upper", cmap=cmap, vmin=0, vmax=len(colors) - 1, interpolation="nearest")
    ax.set_title(title)
    format_map_axis(ax)
    if boundary:
        try:
            cities.boundary.to_crs("EPSG:4326").plot(ax=ax, color="black", linewidth=0.32, alpha=0.65)
        except Exception:
            pass
    handles = [mpatches.Patch(facecolor=colors[int(k)], edgecolor="none", label=v) for k, v in labels.items()]
    ax.legend(handles=handles, frameon=False, fontsize=6.2, loc="lower left")
    return im


def plot_city_bar(ax, data, city_col, value_col, title, ylabel, color=None):
    if color is None:
        color = NATURE_PALETTE["red"]
    city_col = city_col if city_col in data.columns else "City"
    d = data[[city_col, value_col]].dropna().sort_values(value_col, ascending=True)
    ax.barh(d[city_col], d[value_col], color=color, edgecolor="none")
    ax.set_title(title)
    ax.set_xlabel(ylabel)
    ax.grid(True, axis="x", alpha=0.18, linewidth=0.45)
    ax.tick_params(axis="both", length=2.2, width=0.5)


def save_pub_figure(fig, path, figures=None, dpi=600):
    plt.rcParams["svg.fonttype"] = "none"
    plt.rcParams["pdf.fonttype"] = 42
    plt.rcParams["ps.fonttype"] = 42
    path = Path(path)
    png_path = path.with_suffix(".png")
    fig.savefig(png_path, dpi=dpi, bbox_inches="tight")
    fig.savefig(path.with_suffix(".svg"), bbox_inches="tight")
    fig.savefig(path.with_suffix(".pdf"), bbox_inches="tight")
    fig.savefig(path.with_suffix(".tiff"), dpi=dpi, bbox_inches="tight", pil_kwargs={"compression": "tiff_lzw"})
    if figures is not None:
        figures.append(png_path)
    plt.close(fig)
    return png_path

def add_dataframe_table(doc, frame, max_rows=30):
    show = frame.head(max_rows).copy()
    table = doc.add_table(rows=1, cols=len(show.columns))
    table.style = "Table Grid"
    for j, col in enumerate(show.columns):
        table.rows[0].cells[j].text = str(col)
    for _, row in show.iterrows():
        cells = table.add_row().cells
        for j, value in enumerate(row):
            if pd.isna(value):
                txt = ""
            elif isinstance(value, float):
                txt = f"{value:.3f}"
            else:
                txt = str(value)
            cells[j].text = txt
    if len(frame) > len(show):
        doc.add_paragraph(f"Note: table truncated to first {len(show)} rows in the Word preview; full CSV is saved separately.")
    return table

def extract_references(path):
    if not Path(path).exists():
        return []
    old = Document(path)
    refs = []
    in_refs = False
    for para in old.paragraphs:
        txt = para.text.strip()
        low = txt.lower()
        if not in_refs:
            if low == "references" or low.startswith("references"):
                in_refs = True
            continue
        if not txt:
            continue
        if low.startswith("figure ") or low.startswith("table ") or low.startswith("fig. "):
            break
        refs.append(txt)
    return refs


def clean_name(value):
    if pd.isna(value):
        return value
    return CITY_FIX.get(str(value), str(value))


def read_base():
    with rasterio.open(PATHS["pop"]) as src:
        arr = src.read(1).astype("float64")
        profile = src.profile.copy()
        transform = src.transform
        crs = src.crs
        nodata = src.nodata
        bounds = src.bounds
    if nodata is not None:
        arr[arr == nodata] = np.nan
    arr[(arr < 0) | (arr > 1_000_000)] = np.nan
    return arr, profile, transform, crs, bounds


def read_match(path, base_profile, resampling=Resampling.bilinear):
    dst = np.full((base_profile["height"], base_profile["width"]), np.nan, dtype="float32")
    if not Path(path).exists():
        return dst.astype("float64")
    with rasterio.open(path) as src:
        src_arr = src.read(1).astype("float32")
        src_nodata = src.nodata
        if src_nodata is not None:
            src_arr[src_arr == src_nodata] = np.nan
        reproject(
            source=src_arr,
            destination=dst,
            src_transform=src.transform,
            src_crs=src.crs,
            src_nodata=np.nan,
            dst_transform=base_profile["transform"],
            dst_crs=base_profile["crs"],
            dst_nodata=np.nan,
            resampling=resampling,
        )
    return dst.astype("float64")


def read_time(path, base_profile):
    arr = read_match(path, base_profile, Resampling.nearest)
    arr[(arr <= 0) | (arr > 10_000)] = np.nan
    med = np.nanmedian(arr)
    if np.isfinite(med) and med > 500:
        arr = arr / 60.0
    return arr


def rasterize_cities(base_profile):
    cities = gpd.read_file(PATHS["cities"]).to_crs(base_profile["crs"])
    cities["City_name"] = cities["City_name"].map(clean_name)
    city_values = {name: i + 1 for i, name in enumerate(cities["City_name"])}
    shapes = ((geom, city_values[name]) for geom, name in zip(cities.geometry, cities["City_name"]))
    city_id = features.rasterize(
        shapes=shapes,
        out_shape=(base_profile["height"], base_profile["width"]),
        transform=base_profile["transform"],
        fill=0,
        dtype="int16",
    )
    id_to_city = {v: k for k, v in city_values.items()}
    return cities, city_id, id_to_city


def city_hospital_density(cities):
    cities_m = cities.to_crs(3857)
    area_km2 = cities_m.geometry.area / 1_000_000
    out = pd.DataFrame({"City": cities["City_name"].values, "area_km2": area_km2.values})
    for level, path in [("l1", PATHS["hosp_l1"]), ("l2", PATHS["hosp_l2"]), ("l3", PATHS["hosp_l3"])]:
        hosp = gpd.read_file(path).to_crs(cities.crs)
        joined = gpd.sjoin(hosp, cities[["City_name", "geometry"]], how="left", predicate="within")
        counts = joined.groupby("City_name").size()
        out[f"hosp_{level}_count"] = out["City"].map(counts).fillna(0).values
        out[f"hosp_{level}_density"] = out[f"hosp_{level}_count"] / out["area_km2"]
    out["hosp_total_density"] = (
        out["hosp_l1_count"] + out["hosp_l2_count"] + out["hosp_l3_count"]
    ) / out["area_km2"]
    return out


def make_grid_table():
    pop, profile, transform, crs, bounds = read_base()
    profile["transform"] = transform
    profile["crs"] = crs
    cities, city_id, id_to_city = rasterize_cities(profile)
    density = city_hospital_density(cities)

    rows, cols = np.indices(pop.shape)
    xs, ys = rasterio.transform.xy(transform, rows, cols, offset="center")
    df = pd.DataFrame({
        "row": rows.ravel().astype("int32"),
        "col": cols.ravel().astype("int32"),
        "lon": np.array(xs).ravel(),
        "lat": np.array(ys).ravel(),
        "population": pop.ravel(),
        "city_id": city_id.ravel(),
    })
    df["City"] = df["city_id"].map(id_to_city)

    for name, path in TIME_PATHS.items():
        df[name] = read_time(path, profile).ravel()

    df["elderly65"] = read_match(PATHS["elderly65"], profile, Resampling.bilinear).ravel()
    elderly70_74 = read_match(PATHS["elderly70"], profile, Resampling.bilinear)
    elderly75_79 = read_match(PATHS["elderly75"], profile, Resampling.bilinear)
    elderly80 = read_match(PATHS["elderly80"], profile, Resampling.bilinear)
    df["elderly70plus"] = (elderly70_74 + elderly75_79 + elderly80).ravel()
    df["slope"] = read_match(PATHS["slope"], profile, Resampling.bilinear).ravel()
    df["dem"] = read_match(PATHS["dem"], profile, Resampling.bilinear).ravel()
    df["gdp"] = read_match(PATHS["gdp"], profile, Resampling.bilinear).ravel()
    df["urban"] = read_match(PATHS["urban"], profile, Resampling.nearest).ravel()
    df["weiss_drive"] = read_time(PATHS["weiss_drive"], profile).ravel()
    df["weiss_walk"] = read_time(PATHS["weiss_walk"], profile).ravel()

    for col in ["elderly65", "elderly70plus", "slope", "dem", "gdp"]:
        df.loc[df[col] < 0, col] = np.nan
    df["elderly_share"] = df["elderly65"] / df["population"]
    df.loc[(df["elderly_share"] < 0) | (df["elderly_share"] > 1), "elderly_share"] = np.nan
    df["urban_binary"] = np.where(df["urban"].fillna(0) > 0, 1, 0)
    df["transit_void_l3"] = np.where(df["drive_l3"].notna() & df["transit_l3"].isna(), 1, 0)
    df["transit_car_l3_ratio"] = df["transit_l3"] / df["drive_l3"]
    df["walk_car_l1_ratio"] = df["walk_l1"] / df["drive_l1"]
    df["walk_car_l3_ratio"] = df["walk_l3"] / df["drive_l3"]
    df["drive_hierarchy_gap"] = df["drive_l3"] - df["drive_l1"]
    df["transit_hierarchy_gap"] = df["transit_l3"] - df["transit_l1"]
    df["walk_hierarchy_gap"] = df["walk_l3"] - df["walk_l1"]

    df = df[(df["population"].notna()) & (df["population"] > 0) & (df["city_id"] > 0)].copy()
    df = df.merge(density, on="City", how="left")
    grid_path = DATA_DIR / "health_place_grid_table.parquet"
    try:
        df.to_parquet(grid_path, index=False)
    except Exception:
        grid_path = DATA_DIR / "health_place_grid_table.csv"
        df.to_csv(grid_path, index=False, encoding="utf-8-sig")

    audit = {
        "base_shape": [profile["height"], profile["width"]],
        "base_crs": str(profile["crs"]),
        "base_transform": tuple(round(x, 12) for x in profile["transform"][:6]),
        "valid_population_cells": int(len(df)),
        "total_population_grid": float(df["population"].sum()),
        "total_elderly65_grid": float(df["elderly65"].sum(skipna=True)),
        "api_provenance": "Existing URL-generation scripts reference Tencent Maps direction API; revised manuscript uses 'commercial navigation platform API' and reports this audit.",
    }
    (DATA_DIR / "data_audit.json").write_text(json.dumps(audit, indent=2), encoding="utf-8")
    return df, cities, profile


def weighted_quantile(values, weights, qs):
    mask = np.isfinite(values) & np.isfinite(weights) & (weights > 0)
    if mask.sum() == 0:
        return [np.nan for _ in qs]
    v = np.asarray(values[mask])
    w = np.asarray(weights[mask])
    order = np.argsort(v)
    v = v[order]
    w = w[order]
    cdf = np.cumsum(w) / np.sum(w)
    return [float(np.interp(q, cdf, v)) for q in qs]


def weighted_gini(values, weights):
    mask = np.isfinite(values) & np.isfinite(weights) & (weights > 0)
    if mask.sum() < 2:
        return np.nan
    x = np.asarray(values[mask], dtype=float)
    w = np.asarray(weights[mask], dtype=float)
    order = np.argsort(x)
    x = x[order]
    w = w[order]
    cumw = np.cumsum(w)
    cumxw = np.cumsum(x * w)
    if cumxw[-1] <= 0:
        return np.nan
    return float(1 - 2 * np.trapz(cumxw / cumxw[-1], cumw / cumw[-1]))


def weighted_theil(values, weights):
    mask = np.isfinite(values) & np.isfinite(weights) & (weights > 0) & (values > 0)
    if mask.sum() < 2:
        return np.nan
    x = np.asarray(values[mask], dtype=float)
    w = np.asarray(weights[mask], dtype=float)
    mu = np.average(x, weights=w)
    r = x / mu
    return float(np.average(r * np.log(r), weights=w))


def metric_rows(df):
    labels = {
        "drive_l1": ("Driving", "Primary"),
        "drive_l2": ("Driving", "Secondary"),
        "drive_l3": ("Driving", "Tertiary"),
        "transit_l1": ("Transit", "Primary"),
        "transit_l2": ("Transit", "Secondary"),
        "transit_l3": ("Transit", "Tertiary"),
        "walk_l1": ("Walking", "Primary"),
        "walk_l2": ("Walking", "Secondary"),
        "walk_l3": ("Walking", "Tertiary"),
    }
    rows = []
    for col, (mode, tier) in labels.items():
        t = df[col].values
        pop = df["population"].values
        old = df["elderly65"].fillna(0).values
        valid = np.isfinite(t) & np.isfinite(pop) & (pop > 0)
        q25, q50, q75, q90 = weighted_quantile(t, pop, [0.25, 0.5, 0.75, 0.9])
        q10 = weighted_quantile(t, pop, [0.1])[0]
        item = {
            "mode": mode,
            "tier": tier,
            "indicator": col,
            "valid_population": pop[valid].sum(),
            "pwtt": np.average(t[valid], weights=pop[valid]) if valid.any() else np.nan,
            "median": q50,
            "p75_p25": q75 / q25 if q25 and q25 > 0 else np.nan,
            "p90_p10": q90 / q10 if q10 and q10 > 0 else np.nan,
            "gini": weighted_gini(t, pop),
            "theil": weighted_theil(t, pop),
        }
        for thr in [15, 30, 45, 60]:
            within = valid & (t <= thr)
            beyond = valid & (t > thr)
            item[f"coverage_{thr}min_pct"] = pop[within].sum() / pop[valid].sum() * 100 if valid.any() else np.nan
            item[f"beyond_{thr}min_pop"] = pop[beyond].sum()
            item[f"beyond_{thr}min_elderly65"] = old[beyond].sum()
        rows.append(item)
    out = pd.DataFrame(rows)
    out.to_csv(TABLE_DIR / "Table_A_accessibility_inequality_exposure.csv", index=False, encoding="utf-8-sig")
    return out


def exposure_by_city(df):
    rows = []
    for city, sub in df.groupby("City"):
        row = {"City": city, "population": sub["population"].sum(), "elderly65": sub["elderly65"].sum()}
        for col in ["drive_l3", "transit_l3", "walk_l1", "walk_l3"]:
            valid = sub[col].notna()
            if valid.any():
                row[f"{col}_pwtt"] = np.average(sub.loc[valid, col], weights=sub.loc[valid, "population"])
                row[f"{col}_coverage30_pct"] = sub.loc[valid & (sub[col] <= 30), "population"].sum() / sub.loc[valid, "population"].sum() * 100
                row[f"{col}_elderly_beyond30"] = sub.loc[valid & (sub[col] > 30), "elderly65"].sum()
        row["transit_void_l3_pop"] = sub.loc[sub["transit_void_l3"] == 1, "population"].sum()
        row["transit_void_l3_pct"] = row["transit_void_l3_pop"] / row["population"] * 100
        rows.append(row)
    out = pd.DataFrame(rows).sort_values("transit_l3_pwtt", ascending=False)
    out.to_csv(TABLE_DIR / "Table_B_city_elderly_exposure.csv", index=False, encoding="utf-8-sig")
    return out


def mechanism_models(df):
    vars_x = ["slope", "dem", "elderly_share", "gdp", "urban_binary", "hosp_total_density"]
    deps = {
        "tertiary_transit_car_penalty": "transit_car_l3_ratio",
        "primary_walking_car_penalty": "walk_car_l1_ratio",
        "tertiary_walking_car_penalty": "walk_car_l3_ratio",
    }
    rows = []
    for dep_name, col in deps.items():
        data = df[[col, "population", "City"] + vars_x].replace([np.inf, -np.inf], np.nan).dropna()
        data = data[(data[col] > 0) & (data[col] < 100)]
        if len(data) < 50:
            continue
        y = np.log1p(data[col])
        X = data[vars_x].copy()
        for x in ["slope", "dem", "elderly_share", "gdp", "hosp_total_density"]:
            sd = X[x].std()
            if sd > 0:
                X[x] = (X[x] - X[x].mean()) / sd
        X = sm.add_constant(X)
        model = sm.WLS(y, X, weights=data["population"])
        fit = model.fit(cov_type="cluster", cov_kwds={"groups": data["City"]})
        for var in X.columns:
            rows.append({
                "model": dep_name,
                "term": var,
                "coef": fit.params[var],
                "se_cluster_city": fit.bse[var],
                "p_value": fit.pvalues[var],
                "n": int(len(data)),
                "r2": fit.rsquared,
            })
    # GLM for void
    data = df[["transit_void_l3", "population", "City"] + vars_x].replace([np.inf, -np.inf], np.nan).dropna()
    if len(data) > 50 and data["transit_void_l3"].sum() > 0:
        X = data[vars_x].copy()
        for x in ["slope", "dem", "elderly_share", "gdp", "hosp_total_density"]:
            sd = X[x].std()
            if sd > 0:
                X[x] = (X[x] - X[x].mean()) / sd
        X = sm.add_constant(X)
        fit = sm.GLM(data["transit_void_l3"], X, family=sm.families.Binomial(), freq_weights=data["population"]).fit()
        for var in X.columns:
            rows.append({
                "model": "tertiary_transit_void_binary",
                "term": var,
                "coef": fit.params[var],
                "se_cluster_city": fit.bse[var],
                "p_value": fit.pvalues[var],
                "n": int(len(data)),
                "r2": np.nan,
            })
    out = pd.DataFrame(rows)
    out.to_csv(TABLE_DIR / "Table_C_mechanism_models.csv", index=False, encoding="utf-8-sig")
    return out


def accessibility_regimes(df):
    feature_cols = [
        "drive_l1", "drive_l2", "drive_l3", "transit_l1", "transit_l2", "transit_l3",
        "walk_l1", "walk_l2", "walk_l3",
    ]
    city_rows = []
    for city, sub in df.groupby("City"):
        row = {"City": city, "population": sub["population"].sum(), "elderly65": sub["elderly65"].sum()}
        for col in feature_cols:
            valid = sub[col].notna()
            row[col] = np.average(sub.loc[valid, col], weights=sub.loc[valid, "population"]) if valid.any() else np.nan
        city_rows.append(row)
    city = pd.DataFrame(city_rows)
    X = city[feature_cols].fillna(city[feature_cols].max() * 1.5)
    labels = KMeans(n_clusters=4, random_state=42, n_init=20).fit_predict(StandardScaler().fit_transform(X))
    city["cluster_raw"] = labels
    score = city.groupby("cluster_raw")[feature_cols].mean().mean(axis=1).sort_values()
    rank = {cid: i for i, cid in enumerate(score.index)}
    names = {
        0: "High-access multimodal core",
        1: "Car-dependent transition",
        2: "Transit-limited periphery",
        3: "Compound low-access hinterland",
    }
    city["access_regime"] = city["cluster_raw"].map(rank).map(names)
    city.to_csv(TABLE_DIR / "Table_D_accessibility_regimes.csv", index=False, encoding="utf-8-sig")
    return city


def deep_hierarchy_analysis(df):
    modes = {
        "Driving": ("drive_l1", "drive_l2", "drive_l3"),
        "Transit": ("transit_l1", "transit_l2", "transit_l3"),
        "Walking": ("walk_l1", "walk_l2", "walk_l3"),
    }
    summary_rows = []
    for mode, (l1, l2, l3) in modes.items():
        sub = df[[l1, l2, l3, "population", "elderly65"]].replace([np.inf, -np.inf], np.nan).dropna()
        pop = sub["population"].values
        gap = (sub[l3] - sub[l1]).values
        ratio = (sub[l3] / sub[l1]).replace([np.inf, -np.inf], np.nan).values
        closest = np.argmin(sub[[l1, l2, l3]].values, axis=1)
        mismatch = closest != 0
        summary_rows.append({
            "mode": mode,
            "valid_population": pop.sum(),
            "mean_l3_l1_gap": np.average(gap, weights=pop),
            "median_l3_l1_gap": weighted_quantile(gap, pop, [0.5])[0],
            "mean_l3_l1_ratio": np.average(ratio[np.isfinite(ratio)], weights=pop[np.isfinite(ratio)]),
            "compressed_gap_le_5min_pct": pop[gap <= 5].sum() / pop.sum() * 100,
            "expanded_gap_gt_30min_pct": pop[gap > 30].sum() / pop.sum() * 100,
            "primary_not_closest_pct": pop[mismatch].sum() / pop.sum() * 100,
            "elderly65_primary_not_closest": sub.loc[mismatch, "elderly65"].sum(),
        })
    summary = pd.DataFrame(summary_rows)
    summary.to_csv(TABLE_DIR / "Table_F_hierarchy_compression_expansion.csv", index=False, encoding="utf-8-sig")

    work = df.copy()
    work["car_tertiary_reachable_noncar_primary_barrier"] = (
        (work["drive_l3"] <= 30)
        & ((work["walk_l1"] > 30) | (work["transit_l1"] > 30) | (work["transit_l1"].isna()))
    ).astype(int)
    elderly_cut = work["elderly_share"].quantile(0.75)
    work["ageing_sensitive_primary_failure"] = (
        (work["elderly_share"] >= elderly_cut)
        & (work["drive_l1"] <= 15)
        & ((work["walk_l1"] > 30) | (work["transit_l1"] > 30) | (work["transit_l1"].isna()))
    ).astype(int)

    mismatch_cols = []
    for mode, (l1, l2, l3) in modes.items():
        vals = work[[l1, l2, l3]].values
        valid = np.isfinite(vals).all(axis=1)
        closest = np.full(len(work), np.nan)
        closest[valid] = np.argmin(vals[valid], axis=1)
        col = f"{mode.lower()}_primary_not_closest"
        work[col] = ((closest != 0) & valid).astype(int)
        mismatch_cols.append(col)
    work["any_primary_not_closest"] = work[mismatch_cols].max(axis=1)
    work["mismatch_intensity"] = work[mismatch_cols].sum(axis=1)

    city_rows = []
    for city, sub in work.groupby("City"):
        pop = sub["population"].sum()
        old = sub["elderly65"].sum()
        row = {
            "City": city,
            "population": pop,
            "elderly65": old,
            "car_tertiary_reachable_noncar_primary_barrier_pop": sub.loc[sub["car_tertiary_reachable_noncar_primary_barrier"] == 1, "population"].sum(),
            "ageing_sensitive_primary_failure_pop": sub.loc[sub["ageing_sensitive_primary_failure"] == 1, "population"].sum(),
            "ageing_sensitive_primary_failure_elderly65": sub.loc[sub["ageing_sensitive_primary_failure"] == 1, "elderly65"].sum(),
            "any_primary_not_closest_pop": sub.loc[sub["any_primary_not_closest"] == 1, "population"].sum(),
        }
        row["car_tertiary_reachable_noncar_primary_barrier_pct"] = row["car_tertiary_reachable_noncar_primary_barrier_pop"] / pop * 100
        row["ageing_sensitive_primary_failure_pop_pct"] = row["ageing_sensitive_primary_failure_pop"] / pop * 100
        row["ageing_sensitive_primary_failure_elderly65_pct"] = row["ageing_sensitive_primary_failure_elderly65"] / old * 100 if old > 0 else np.nan
        row["any_primary_not_closest_pct"] = row["any_primary_not_closest_pop"] / pop * 100
        city_rows.append(row)
    city = pd.DataFrame(city_rows).sort_values("ageing_sensitive_primary_failure_elderly65_pct", ascending=False)
    city.to_csv(TABLE_DIR / "Table_G_hierarchy_mismatch_failure_zones.csv", index=False, encoding="utf-8-sig")
    return summary, work, city


def weighted_cdf(values, weights):
    mask = np.isfinite(values) & np.isfinite(weights) & (weights > 0)
    v = np.asarray(values[mask])
    w = np.asarray(weights[mask])
    order = np.argsort(v)
    v = v[order]
    w = w[order]
    return v, np.cumsum(w) / np.sum(w) * 100



def primary_locality_analysis(df: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Test whether institutionally local primary care remains local under unequal mobility."""
    work = df.copy()
    pop = work["population"].fillna(0).clip(lower=0)

    work["primary_car_local_15"] = work["drive_l1"].le(15)
    work["primary_car_reachable_30"] = work["drive_l1"].le(30)
    work["primary_transit_beyond_30"] = work["transit_l1"].isna() | work["transit_l1"].gt(30)
    work["primary_walk_beyond_30"] = work["walk_l1"].isna() | work["walk_l1"].gt(30)
    work["primary_transit_beyond_45"] = work["transit_l1"].isna() | work["transit_l1"].gt(45)
    work["primary_walk_beyond_45"] = work["walk_l1"].isna() | work["walk_l1"].gt(45)
    work["primary_noncar_beyond_30"] = work["primary_transit_beyond_30"] | work["primary_walk_beyond_30"]
    work["primary_noncar_beyond_45"] = work["primary_transit_beyond_45"] | work["primary_walk_beyond_45"]
    work["primary_not_local"] = work["primary_car_local_15"] & work["primary_noncar_beyond_30"]
    work["primary_failure_zone"] = work["primary_car_reachable_30"] & work["primary_noncar_beyond_30"]
    work["car_tertiary_reachable_noncar_primary_barrier"] = work["drive_l3"].le(45) & work["primary_noncar_beyond_30"]

    elderly_cut = work.loc[pop > 0, "elderly_share"].quantile(0.75)
    work["ageing_sensitive_primary_failure"] = work["primary_failure_zone"] & work["elderly_share"].ge(elderly_cut)

    rows = []
    city_col = "city" if "city" in work.columns else "City"
    for city, g in work.groupby(city_col):
        gp = g["population"].fillna(0).clip(lower=0)
        ge = g["elderly65"].fillna(0).clip(lower=0)
        def pct(mask, weights):
            denom = weights.sum()
            return float((weights[mask].sum() / denom) * 100) if denom else np.nan
        rows.append({
            "city": city,
            "population": float(gp.sum()),
            "elderly65": float(ge.sum()),
            "primary_noncar_beyond30_pop_pct": pct(g["primary_noncar_beyond_30"], gp),
            "primary_noncar_beyond30_elderly65_pct": pct(g["primary_noncar_beyond_30"], ge),
            "primary_not_local_pop_pct": pct(g["primary_not_local"], gp),
            "primary_not_local_elderly65_pct": pct(g["primary_not_local"], ge),
            "car_tertiary_reachable_noncar_primary_barrier_pop_pct": pct(g["car_tertiary_reachable_noncar_primary_barrier"], gp),
            "ageing_sensitive_primary_failure_pop_pct": pct(g["ageing_sensitive_primary_failure"], gp),
            "ageing_sensitive_primary_failure_elderly65_pct": pct(g["ageing_sensitive_primary_failure"], ge),
        })
    city_summary = pd.DataFrame(rows).sort_values("primary_not_local_elderly65_pct", ascending=False)
    city_summary.to_csv(TABLE_DIR / "Supplement_PrimaryLocality_city.csv", index=False, encoding="utf-8-sig")
    return work, city_summary


def make_main_tables(metrics: pd.DataFrame, hierarchy_summary: pd.DataFrame, failure_city: pd.DataFrame,
                     primary_city: pd.DataFrame, models: pd.DataFrame) -> list[Path]:
    paths: list[Path] = []
    table1 = pd.DataFrame([
        {"component": "Population grid", "source": str(PATHS["pop"]), "resolution_or_unit": "1 km grid", "role_or_definition": "Population weights and denominator for coverage/exposure."},
        {"component": "Navigation travel time", "source": "Nine mode-tier rasters from the commercial navigation platform API", "resolution_or_unit": "1 km grid; minutes", "role_or_definition": "Driving, transit and walking access to primary, secondary and tertiary care."},
        {"component": "Healthcare hierarchy", "source": "Zhejiang L1/L2/L3 hospital shapefiles", "resolution_or_unit": "facility points", "role_or_definition": "Primary, secondary and tertiary service tiers."},
        {"component": "Older population", "source": str(PATHS["elderly65"]), "resolution_or_unit": "1 km grid", "role_or_definition": "Population aged 65+ and elderly share."},
        {"component": "Terrain", "source": f"{PATHS['dem']}; {PATHS['slope']}", "resolution_or_unit": "1 km grid", "role_or_definition": "Elevation and slope as place-based mobility constraints."},
        {"component": "Built and socioeconomic context", "source": f"{PATHS['gdp']}; {PATHS['urban']}", "resolution_or_unit": "1 km grid", "role_or_definition": "GDP proxy and built-up/urban context."},
        {"component": "Primary locality failure", "source": "Derived metric", "resolution_or_unit": "grid/city", "role_or_definition": "Driving reaches primary care within 30 min but transit or walking exceeds 30 min."},
        {"component": "Hierarchy mismatch", "source": "Derived metric", "resolution_or_unit": "grid/city", "role_or_definition": "Primary care is not the nearest reachable tier, or tertiary care is car-reachable while non-car primary care is constrained."},
    ])
    p = TABLE_DIR / "MainTable1_data_metric_definitions.csv"; table1.to_csv(p, index=False, encoding="utf-8-sig"); paths.append(p)

    table2_cols = ["mode", "tier", "pwtt", "coverage_30min_pct", "coverage_45min_pct", "gini", "theil", "p90_p10", "beyond_30min_elderly65"]
    table2 = metrics[[c for c in table2_cols if c in metrics.columns]].copy()
    for c in table2.select_dtypes(include=[np.number]).columns:
        table2[c] = table2[c].round(3)
    p = TABLE_DIR / "MainTable2_mode_tier_accessibility_inequality.csv"; table2.to_csv(p, index=False, encoding="utf-8-sig"); paths.append(p)

    table3 = hierarchy_summary.copy()
    select3 = ["mode", "mean_l3_l1_gap", "median_l3_l1_gap", "compressed_gap_le_5min_pct", "expanded_gap_gt_30min_pct", "mean_l3_l1_ratio", "median_l3_l1_ratio", "primary_not_closest_pct", "elderly65_primary_not_closest"]
    table3 = table3[[c for c in select3 if c in table3.columns]]
    for c in table3.select_dtypes(include=[np.number]).columns:
        table3[c] = table3[c].round(3)
    p = TABLE_DIR / "MainTable3_hierarchy_compression_mismatch.csv"; table3.to_csv(p, index=False, encoding="utf-8-sig"); paths.append(p)

    fc = failure_city.rename(columns={"City": "city"}).copy()
    pc = primary_city.rename(columns={"City": "city"}).copy()
    table4 = fc.merge(pc, on=["city", "population", "elderly65"], how="outer")
    select4 = [
        "city", "population", "elderly65", "any_primary_not_closest_pct",
        "primary_noncar_beyond30_pop_pct", "primary_noncar_beyond30_elderly65_pct",
        "primary_not_local_pop_pct", "primary_not_local_elderly65_pct",
        "car_tertiary_reachable_noncar_primary_barrier_pct",
        "car_tertiary_reachable_noncar_primary_barrier_pop_pct",
        "ageing_sensitive_primary_failure_pop_pct", "ageing_sensitive_primary_failure_elderly65_pct",
    ]
    table4 = table4[[c for c in select4 if c in table4.columns]].sort_values("primary_not_local_elderly65_pct", ascending=False)
    for c in table4.select_dtypes(include=[np.number]).columns:
        table4[c] = table4[c].round(3)
    p = TABLE_DIR / "MainTable4_city_primary_failure_exposure.csv"; table4.to_csv(p, index=False, encoding="utf-8-sig"); paths.append(p)

    keep_models = ["primary_walking_car_penalty", "tertiary_transit_car_penalty", "tertiary_walking_car_penalty", "tertiary_transit_void_binary"]
    table5 = models[models["model"].isin(keep_models)].copy()
    select5 = ["model", "term", "coef", "se_cluster_city", "p_value", "n", "r2"]
    table5 = table5[[c for c in select5 if c in table5.columns]]
    for c in table5.select_dtypes(include=[np.number]).columns:
        table5[c] = table5[c].round(4)
    p = TABLE_DIR / "MainTable5_mechanism_models.csv"; table5.to_csv(p, index=False, encoding="utf-8-sig"); paths.append(p)
    return paths


def save_figures(df: pd.DataFrame, metrics: pd.DataFrame, exposure_city: pd.DataFrame,
                 regimes: pd.DataFrame, api_status: pd.DataFrame,
                 hierarchy_summary: pd.DataFrame, hierarchy_city: pd.DataFrame,
                 deep_df: pd.DataFrame, failure_city: pd.DataFrame,
                 primary_df: pd.DataFrame, primary_city: pd.DataFrame,
                 models: pd.DataFrame) -> list[Path]:
    for old in FIG_DIR.glob("Figure*.*"):
        old.unlink()
    for old in SUPP_FIG_DIR.glob("Supplement_Figure*.*"):
        old.unlink()

    figures: list[Path] = []
    pop = df["population"].fillna(0).clip(lower=0)
    extent = [df["lon"].min(), df["lon"].max(), df["lat"].min(), df["lat"].max()]
    shape = GRID_SHAPE
    modes = ["drive", "transit", "walk"]

    fig, ax = plt.subplots(figsize=(7.2, 3.6))
    ax.axis("off")
    ax.text(0.50, 0.94, "When primary care is not local", ha="center", va="center",
            fontsize=11, fontweight="bold", color=NATURE_PALETTE["black"], transform=ax.transAxes)
    boxes = [
        (0.06, 0.68, 0.34, 0.15, "Institutional hierarchy\nPrimary care assumed local"),
        (0.06, 0.43, 0.34, 0.15, "Mobility hierarchy\nCar / transit / walking"),
        (0.06, 0.18, 0.34, 0.15, "Place vulnerability\nAgeing, terrain, service context"),
        (0.59, 0.56, 0.34, 0.17, "Locality test\nIs primary care local\nwithout car mobility?"),
        (0.59, 0.25, 0.34, 0.17, "Outcome\nLocal-primary secure\nvs non-car failure"),
    ]
    for x, y, w, h, label in boxes:
        ax.add_patch(mpatches.Rectangle((x, y), w, h, transform=ax.transAxes,
                                        facecolor="#FAFAF7", edgecolor=NATURE_PALETTE["neutral_dark"], lw=0.75))
        ax.text(x + w / 2, y + h / 2, label, ha="center", va="center",
                transform=ax.transAxes, fontsize=6.4, linespacing=1.18, color=NATURE_PALETTE["black"])
    arrows = [
        ((0.40, 0.755), (0.59, 0.645)),
        ((0.40, 0.505), (0.59, 0.645)),
        ((0.40, 0.255), (0.59, 0.335)),
        ((0.76, 0.56), (0.76, 0.42)),
    ]
    for a, b in arrows:
        ax.annotate("", xy=b, xytext=a, xycoords=ax.transAxes, textcoords=ax.transAxes,
                    arrowprops=dict(arrowstyle="->", lw=0.85, color=NATURE_PALETTE["neutral_dark"],
                                    shrinkA=2, shrinkB=2))
    p = FIG_DIR / "Figure1_conceptual_framework.png"; save_pub_figure(fig, p, figures)

    fig, axes = plt.subplots(1, 3, figsize=(7.2, 2.55), constrained_layout=True)
    draw_raster_map(axes[0], grid_array(df, "dem"), extent, "Elevation and terrain", "Elevation (m)", cmap="terrain", vmin=np.nanpercentile(df["dem"], 2), vmax=np.nanpercentile(df["dem"], 98), boundary=True)
    draw_raster_map(axes[1], grid_array(df.assign(elderly_share_pct=df["elderly_share"] * 100), "elderly_share_pct"), extent, "Older population share", "Aged 65+ (%)", cmap="magma", vmin=0, vmax=np.nanpercentile(df["elderly_share"] * 100, 98), boundary=True)
    draw_raster_map(axes[2], grid_array(df.assign(logpop=np.log1p(df["population"])), "logpop"), extent, "Population and healthcare hierarchy", "log(population + 1)", cmap="Greys", boundary=True)
    colors = {"L1": NATURE_PALETTE["green"], "L2": NATURE_PALETTE["orange"], "L3": NATURE_PALETTE["red"]}
    for level, shp in HOSPITAL_SHP.items():
        try:
            pts = gpd.read_file(shp).to_crs("EPSG:4326")
            pts.plot(ax=axes[2], markersize=8 if level != "L3" else 16, color=colors[level], edgecolor=NATURE_PALETTE["neutral_dark"], linewidth=0.15, label=level)
        except Exception:
            pass
    axes[2].legend(frameon=False, loc="lower left", ncol=3, fontsize=8)
    for ax, lab in zip(axes, list("abc")):
        add_panel_label(ax, lab)
    p = FIG_DIR / "Figure2_study_area_context.png"; save_pub_figure(fig, p, figures)

    tiers = ["l1", "l2", "l3"]
    fig, axes = plt.subplots(3, 3, figsize=(7.2, 6.2), constrained_layout=True)
    for i, mode in enumerate(modes):
        for j, tier in enumerate(tiers):
            arr = grid_array(df, f"{mode}_{tier}")
            draw_raster_map(axes[i, j], arr, extent, f"{MODE_LABELS[mode]} - {TIER_LABELS[tier]}", "Minutes", cmap="YlOrRd", vmin=0, vmax=90, boundary=True, cbar=(j == 2))
            add_panel_label(axes[i, j], chr(97 + i * 3 + j))
    p = FIG_DIR / "Figure3_mode_tier_accessibility_matrix.png"; save_pub_figure(fig, p, figures)

    fig, axes = plt.subplots(2, 2, figsize=(7.2, 5.4), constrained_layout=True)
    draw_raster_map(axes[0, 0], grid_array(primary_df, "drive_l1"), extent, "Driving to primary care", "Minutes", cmap="YlGn", vmin=0, vmax=60, boundary=True)
    draw_raster_map(axes[0, 1], grid_array(primary_df, "transit_l1"), extent, "Transit to primary care", "Minutes", cmap="OrRd", vmin=0, vmax=90, boundary=True)
    draw_raster_map(axes[1, 0], grid_array(primary_df, "walk_l1"), extent, "Walking to primary care", "Minutes", cmap="PuRd", vmin=0, vmax=120, boundary=True)
    draw_binary_map(axes[1, 1], grid_array(primary_df, "primary_failure_zone"), extent, "Primary care failure zones", {0: "Not failure", 1: "Car reachable, non-car >30 min"}, colors=[NATURE_PALETTE["neutral_light"], NATURE_PALETTE["red"]], boundary=True)
    for ax, lab in zip(axes.flat, list("abcd")):
        add_panel_label(ax, lab)
    p = FIG_DIR / "Figure4_primary_care_locality_test.png"; save_pub_figure(fig, p, figures)

    fig, axes = plt.subplots(1, 3, figsize=(7.2, 2.55), constrained_layout=True)
    for ax, mode, lab in zip(axes, modes, list("abc")):
        arr = grid_array(df.assign(_gap=df[f"{mode}_l3"] - df[f"{mode}_l1"]), "_gap")
        draw_raster_map(ax, arr, extent, f"{MODE_LABELS[mode]} L3-L1 hierarchy gap", "Minutes", cmap="RdYlBu_r", vmin=-10, vmax=90, boundary=True)
        add_panel_label(ax, lab)
    p = FIG_DIR / "Figure5_hierarchy_compression_expansion.png"; save_pub_figure(fig, p, figures)

    fig, axes = plt.subplots(1, 3, figsize=(7.2, 2.55), constrained_layout=True)
    draw_binary_map(axes[0], grid_array(deep_df, "any_primary_not_closest"), extent, "Primary care not closest", {0: "Primary closest", 1: "Primary not closest"}, colors=[NATURE_PALETTE["neutral_light"], NATURE_PALETTE["red"]], boundary=True)
    draw_binary_map(axes[1], grid_array(deep_df, "car_tertiary_reachable_noncar_primary_barrier"), extent, "Car tertiary reachable; non-car primary barrier", {0: "No mismatch", 1: "Mismatch"}, colors=[NATURE_PALETTE["neutral_light"], NATURE_PALETTE["orange"]], boundary=True)
    draw_binary_map(axes[2], grid_array(primary_df, "primary_not_local"), extent, "Primary care not local", {0: "Local enough", 1: "Non-car local failure"}, colors=[NATURE_PALETTE["neutral_light"], NATURE_PALETTE["red"]], boundary=True)
    for ax, lab in zip(axes, list("abc")):
        add_panel_label(ax, lab)
    p = FIG_DIR / "Figure6_hierarchy_mismatch_map.png"; save_pub_figure(fig, p, figures)

    fig, axes = plt.subplots(1, 3, figsize=(7.2, 2.55), constrained_layout=True)
    draw_raster_map(axes[0], grid_array(df.assign(elderly_share_pct=df["elderly_share"] * 100), "elderly_share_pct"), extent, "Older population concentration", "Aged 65+ (%)", cmap="magma", vmin=0, vmax=np.nanpercentile(df["elderly_share"] * 100, 98), boundary=True)
    draw_binary_map(axes[1], grid_array(primary_df, "ageing_sensitive_primary_failure"), extent, "Ageing-sensitive primary failure", {0: "Other", 1: "Older + primary failure"}, colors=[NATURE_PALETTE["neutral_light"], NATURE_PALETTE["red"]], boundary=True)
    plot_city_bar(axes[2], primary_city, "city", "primary_not_local_elderly65_pct", "Older residents in primary-not-local zones", "% of 65+ population", color=NATURE_PALETTE["red"])
    for ax, lab in zip(axes, list("abc")):
        add_panel_label(ax, lab)
    p = FIG_DIR / "Figure7_ageing_sensitive_primary_failure.png"; save_pub_figure(fig, p, figures)

    fig, axes = plt.subplots(1, 3, figsize=(7.2, 2.6), constrained_layout=True)
    tmp = primary_df.replace([np.inf, -np.inf], np.nan).copy()
    tmp["primary_walk_car_ratio"] = tmp["walk_l1"] / tmp["drive_l1"].replace(0, np.nan)
    tmp["w"] = pop
    for ax, x, y, title, ylabel, color in [
        (axes[0], "slope", "primary_walk_car_ratio", "Slope penalty", "Walking/driving ratio", NATURE_PALETTE["orange"]),
        (axes[1], "dem", "primary_failure_zone", "Elevation failure", "Failure-zone share", NATURE_PALETTE["teal"]),
    ]:
        d = tmp[[x, y, "w"]].dropna()
        d = d[d["w"] > 0]
        d["bin"] = pd.qcut(d[x].rank(method="first"), 10, labels=False, duplicates="drop")
        b = pd.DataFrame([{"x": np.average(g[x], weights=g["w"]), "y": np.average(g[y], weights=g["w"])} for _, g in d.groupby("bin")])
        ax.plot(b["x"], b["y"], marker="o", color=color, lw=1.8)
        ax.set_title(title); ax.set_xlabel(x.upper() if x == "dem" else "Slope"); ax.set_ylabel(ylabel); ax.grid(True, alpha=0.25)
    forest = models[(models["model"] == "primary_walking_car_penalty") & (models["term"] != "const")].copy()
    if not forest.empty:
        forest = forest.sort_values("coef")
        y = np.arange(len(forest))
        axes[2].axvline(0, color=NATURE_PALETTE["black"], lw=0.8)
        axes[2].errorbar(forest["coef"], y, xerr=1.96 * forest["se_cluster_city"].fillna(0), fmt="o", color=NATURE_PALETTE["green"], ecolor=NATURE_PALETTE["neutral_mid"], capsize=2)
        axes[2].set_yticks(y); axes[2].set_yticklabels(forest["term"].str.replace("_", " "), fontsize=6.2)
        axes[2].set_xlabel("Coefficient"); axes[2].set_title("Model coefficients"); axes[2].grid(True, axis="x", alpha=0.18)
    for ax, lab in zip(axes, list("abc")):
        add_panel_label(ax, lab)
    p = FIG_DIR / "Figure8_place_based_mechanisms.png"; save_pub_figure(fig, p, figures)

    city_typology = primary_city.rename(columns={"City": "city"}).merge(failure_city.rename(columns={"City": "city"}), on=["city", "population", "elderly65"], how="outer")
    def label_regime(r):
        if r.get("primary_not_local_elderly65_pct", 0) >= 50 and r.get("ageing_sensitive_primary_failure_elderly65_pct", 0) >= 25:
            return "Compound mismatch"
        if r.get("primary_not_local_elderly65_pct", 0) >= 40:
            return "Non-car primary failure"
        if r.get("car_tertiary_reachable_noncar_primary_barrier_pop_pct", r.get("car_tertiary_reachable_noncar_primary_barrier_pct", 0)) >= 25:
            return "Car-compressed hierarchy"
        return "Local-primary secure"
    city_typology["regime"] = city_typology.apply(label_regime, axis=1)
    palette = {"Local-primary secure": NATURE_PALETTE["green"], "Car-compressed hierarchy": "#E8D7A2", "Non-car primary failure": NATURE_PALETTE["orange"], "Compound mismatch": NATURE_PALETTE["red"]}
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 3.1), constrained_layout=True)
    try:
        cc = cities.copy().to_crs("EPSG:4326")
        key = "City_name" if "City_name" in cc.columns else ("Name_1" if "Name_1" in cc.columns else "city")
        cc = cc.merge(city_typology[["city", "regime"]], left_on=key, right_on="city", how="left")
        cc.plot(ax=axes[0], color=cc["regime"].map(palette).fillna(NATURE_PALETTE["neutral_mid"]), edgecolor="white", linewidth=0.7)
        axes[0].legend(handles=[mpatches.Patch(facecolor=v, edgecolor="none", label=k) for k, v in palette.items()], frameon=False, loc="lower left", fontsize=5.8)
        axes[0].set_axis_off(); axes[0].set_title("City regimes")
    except Exception:
        axes[0].axis("off")
    ct = city_typology.sort_values("primary_not_local_elderly65_pct", ascending=True)
    axes[1].barh(ct["city"], ct["primary_not_local_elderly65_pct"], color=ct["regime"].map(palette))
    axes[1].set_xlabel("65+ in primary-not-local zones (%)"); axes[1].set_title("Exposure gradient"); axes[1].grid(True, axis="x", alpha=0.18)
    for ax, lab in zip(axes, list("ab")):
        add_panel_label(ax, lab)
    p = FIG_DIR / "Figure9_accessibility_regimes.png"; save_pub_figure(fig, p, figures)

    fig, axes = plt.subplots(1, 3, figsize=(7.2, 2.55), constrained_layout=True)
    for ax, col, label, color in [(axes[0], "drive_l3", "Driving to tertiary care", NATURE_PALETTE["red"]), (axes[1], "walk_l1", "Walking to primary care", NATURE_PALETTE["green"])]:
        vals = df.loc[pop > 0, col].dropna().sort_values()
        y = np.linspace(0, 1, len(vals)) if len(vals) else []
        ax.plot(vals, y, color=color, lw=2); ax.set_xlabel("Travel time (min)"); ax.set_ylabel("Cumulative population share"); ax.set_title(label); ax.grid(True, alpha=0.25)
    axes[2].axis("off")
    status_lines = ["Temporal API robustness", "Designed as sampled check", "Live multi-period API not run"]
    if not api_status.empty:
        for _, r in api_status.head(5).iterrows():
            status_lines.append(f"{r.get('component', '')}: {r.get('status', '')}")
    axes[2].text(0.02, 0.95, "\n".join(status_lines), va="top", ha="left", fontsize=10, transform=axes[2].transAxes)
    axes[2].set_title("Robustness status")
    for ax, lab in zip(axes, list("abc")):
        add_panel_label(ax, lab)
    p = FIG_DIR / "Figure10_benchmarking_and_robustness.png"; save_pub_figure(fig, p, figures)

    fig, ax = plt.subplots(figsize=(7.2, 3.2))
    gi = metrics.pivot(index="tier", columns="mode", values="gini")
    x = np.arange(len(gi.index))
    width = 0.24
    for k, mode in enumerate(gi.columns):
        ax.bar(x + (k - (len(gi.columns) - 1) / 2) * width, gi[mode], width=width,
               color=MODE_COLORS.get(mode, NATURE_PALETTE["neutral_mid"]), label=mode)
    ax.set_xticks(x); ax.set_xticklabels(gi.index)
    ax.legend(frameon=False)
    ax.set_title("Supplement: inequality across modes and tiers"); ax.set_ylabel("Population-weighted Gini")
    save_pub_figure(fig, SUPP_FIG_DIR / "Supplement_Figure_inequality_indices.png")

    fig, ax = plt.subplots(figsize=(7.2, 3.2))
    plot_city_bar(ax, exposure_city, "city", "transit_l3_elderly_beyond30", "Supplement: older residents beyond 30 min to tertiary transit", "65+ residents", color=NATURE_PALETTE["red"])
    save_pub_figure(fig, SUPP_FIG_DIR / "Supplement_Figure_elderly_tertiary_exposure.png")

    fig, ax = plt.subplots(figsize=(7.2, 3.2))
    mask = (tmp["w"] > 0) & tmp["slope"].notna() & tmp["primary_walk_car_ratio"].notna()
    if mask.any():
        sample = tmp.loc[mask].sample(min(6000, int(mask.sum())), random_state=42)
        ax.scatter(sample["slope"], sample["primary_walk_car_ratio"], s=4, alpha=0.15, color=NATURE_PALETTE["orange"])
    ax.set_xlabel("Slope"); ax.set_ylabel("Walking/driving primary ratio"); ax.set_title("Supplement: raw terrain penalty scatter")
    save_pub_figure(fig, SUPP_FIG_DIR / "Supplement_Figure_raw_terrain_scatter.png")

    return figures

def make_api_sampling_inputs(df):
    # Stratified OD sample for later live API robustness queries. Endpoints are not
    # reconstructed here; this creates the reproducible origin strata and baseline times.
    use = df.dropna(subset=["population", "City", "drive_l3", "transit_l3", "slope", "urban_binary"]).copy()
    use["slope_bin"] = pd.qcut(use["slope"].rank(method="first"), 3, labels=["low", "mid", "high"])
    use["time_bin"] = pd.qcut(use["transit_l3"].rank(method="first"), 3, labels=["fast", "middle", "slow"])
    samples = []
    for _, group in use.groupby(["City", "slope_bin", "urban_binary", "time_bin"]):
        n = min(5, len(group))
        if n:
            samples.append(group.sample(n=n, random_state=42, weights=group["population"]))
    sample = pd.concat(samples).drop_duplicates(subset=["row", "col"]).head(2000)
    sample[["row", "col", "lon", "lat", "City", "population", "drive_l3", "transit_l3", "slope", "urban_binary"]].to_csv(
        DATA_DIR / "api_robustness_origin_sample.csv", index=False, encoding="utf-8-sig"
    )
    pd.DataFrame([
        {
            "component": "stratified_origin_sample",
            "status": "completed",
            "details": f"{len(sample)} origins sampled by city, slope, urban status, and baseline transit-time strata",
        },
        {
            "component": "live_multiperiod_api_query",
            "status": "not_run",
            "details": "Requires reconnecting sampled origins to nearest-facility destination coordinates and setting TENCENT_MAP_KEYS; no live API quota was consumed by this pipeline.",
        },
        {
            "component": "recommended_query_windows",
            "status": "specified",
            "details": "weekday morning peak, weekday off-peak, weekday evening peak, weekend daytime for driving and transit",
        },
    ]).to_csv(TABLE_DIR / "Table_E_api_robustness_status.csv", index=False, encoding="utf-8-sig")

    script = CODE_DIR / "run_api_temporal_robustness.py"
    script.write_text(
        """\
\"\"\"Optional live routing robustness script.

Set TENCENT_MAP_KEYS as a comma-separated list. This script is intentionally
separate from the main analysis because it consumes live API quota.
\"\"\"
import os
from pathlib import Path
import pandas as pd

SAMPLE = Path("source_data/api_robustness_origin_sample.csv")
OUT = Path("outputs/api_temporal_robustness_results.csv")

keys = [k.strip() for k in os.environ.get(\"TENCENT_MAP_KEYS\", \"\").split(\",\") if k.strip()]
if not keys:
    raise SystemExit(\"Set TENCENT_MAP_KEYS before running live API robustness queries.\")

df = pd.read_csv(SAMPLE)
print(f\"Loaded {len(df)} sampled origins. Add destination reconstruction before live query if needed.\")
print(\"This scaffold preserves the sampling design; live OD querying should use the nearest-facility destinations from the original URL files.\")
""",
        encoding="utf-8",
    )



def write_figure_qa_notes():
    notes = {
        "backend": "Python/matplotlib only",
        "export_contract": "Each main figure is exported as editable SVG, PDF, 600 dpi PNG, and 600 dpi LZW-compressed TIFF.",
        "font_contract": "Sans-serif fonts with svg.fonttype='none' and pdf.fonttype=42.",
        "figure_story": {
            "Figure1": "Institutional hierarchy and mobility hierarchy jointly create primary-care locality failure.",
            "Figure2": "Terrain, ageing and hospital hierarchy define the place context.",
            "Figure3": "Mode-tier travel-time matrix provides background accessibility evidence.",
            "Figure4": "Primary care is not always local under transit and walking constraints.",
            "Figure5": "Car mobility compresses hierarchy; non-car modes expand it.",
            "Figure6": "Hierarchy mismatch is spatially structured.",
            "Figure7": "Older residents are exposed to primary-care failure zones.",
            "Figure8": "Terrain and contextual covariates explain mobility penalties.",
            "Figure9": "Cities fall into interpretable accessibility regimes.",
            "Figure10": "Benchmarking and API robustness status are treated as validation, not the main finding.",
        },
    }
    (OUT / "figure_qa_notes.json").write_text(json.dumps(notes, indent=2), encoding="utf-8")


def make_docx(figures: list[Path], main_tables: list[Path], api_status: pd.DataFrame) -> None:
    doc = Document()
    styles = doc.styles
    styles["Normal"].font.name = "Times New Roman"
    styles["Normal"].font.size = Pt(11)
    title = doc.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = title.add_run("When primary care is not local: Mobility hierarchy and place-based mismatch in access to tiered healthcare in Zhejiang, China")
    run.bold = True
    run.font.size = Pt(16)

    manuscript_text = CODE_DIR / "manuscript_full_text.json"
    if manuscript_text.exists():
        sections = json.loads(manuscript_text.read_text(encoding="utf-8"))
    else:
        sections = [
            {"heading": "Abstract", "paragraphs": ["Primary care is conventionally treated as the local tier of a hierarchical healthcare system. Using Zhejiang, China as a case, this revised Health & Place manuscript tests that assumption directly by combining navigation-based travel times, healthcare facility hierarchy, population ageing, terrain and city context. The central finding is that cars compress the healthcare hierarchy, while transit and walking can make primary care non-local for substantial older populations. These mobility-contingent failures reveal a place-based mismatch between institutional design and practical healthcare access."]},
        ]
    for section in sections:
        doc.add_heading(section["heading"], level=1)
        for body in section["paragraphs"]:
            if body.startswith("## "):
                doc.add_heading(body[3:], level=2)
            else:
                doc.add_paragraph(body)

    doc.add_heading("Main figures", level=1)
    figure_captions = {
        1: "Conceptual framework linking institutional healthcare hierarchy and mobility hierarchy.",
        2: "Study context: terrain, ageing and healthcare hierarchy in Zhejiang.",
        3: "Mode-tier accessibility matrix for driving, transit and walking across three healthcare tiers.",
        4: "Primary care locality test showing when nominally local primary care fails under non-car mobility.",
        5: "Hierarchy compression and expansion measured as tertiary-minus-primary travel time.",
        6: "Hierarchy mismatch maps identifying primary-not-closest and non-car primary barriers.",
        7: "Ageing-sensitive primary care failure zones and city-level older-population exposure.",
        8: "Place-based mechanisms linking terrain and covariates to primary-care penalties.",
        9: "Accessibility regimes expressed as local-primary security, car-compressed hierarchy, non-car primary failure and compound mismatch.",
        10: "Benchmarking and robustness status for navigation-based accessibility estimates.",
    }
    for i in range(1, 11):
        matches = sorted(FIG_DIR.glob(f"Figure{i}_*.png"))
        if matches:
            doc.add_picture(str(matches[0]), width=Inches(6.4))
            cap = doc.add_paragraph(f"Figure {i}. {figure_captions[i]}")
            cap.style = styles["Caption"]

    doc.add_heading("Main tables", level=1)
    table_captions = {
        1: "Data and metric definitions.",
        2: "Mode-tier accessibility, coverage, inequality and older-population exposure.",
        3: "Hierarchy compression and mismatch summary.",
        4: "City-level primary care failure exposure.",
        5: "Mechanism models explaining mobility penalties and mismatch.",
    }
    for i in range(1, 6):
        matches = sorted(TABLE_DIR.glob(f"MainTable{i}_*.csv"))
        if matches:
            df_table = pd.read_csv(matches[0])
            doc.add_paragraph(f"Table {i}. {table_captions[i]}")
            add_dataframe_table(doc, df_table, max_rows=30)

    refs = extract_references(ORIGINAL_MS)
    if refs:
        doc.add_heading("References", level=1)
        for ref in refs:
            txt = ref.strip()
            if not txt:
                continue
            low = txt.lower()
            if low.startswith("figure ") or low.startswith("table ") or low.startswith("fig. "):
                continue
            doc.add_paragraph(txt)
    doc.save(OUT / "MS_HealthPlace_revised.docx")

    cl = Document()
    cl.styles["Normal"].font.name = "Times New Roman"
    cl.add_paragraph("Dear Editors of Health & Place,")
    cl.add_paragraph("We are pleased to submit our manuscript, 'When primary care is not local: Mobility hierarchy and place-based mismatch in access to tiered healthcare in Zhejiang, China', for consideration in Health & Place.")
    cl.add_paragraph("The manuscript asks a deliberately health-geographical question: whether primary care, although designed as the local tier of a healthcare hierarchy, remains local when evaluated through real mobility constraints, ageing geography and terrain. The answer is consequential: car-based accessibility compresses the healthcare hierarchy, while transit and walking can make primary care non-local for older and non-car-dependent populations.")
    cl.add_paragraph("We believe the study fits Health & Place because it advances debates on place-based health inequality, mobility-mediated access, vulnerable populations and the spatial consequences of tiered healthcare systems. We use navigation-based travel-time surfaces as evidence, but the contribution is not the routing technology itself; it is the diagnosis of mismatch between institutional assumptions and practical access.")
    cl.add_paragraph("Sincerely,")
    cl.save(OUT / "CL_HealthPlace.docx")

    supp = Document()
    supp.styles["Normal"].font.name = "Times New Roman"
    supp.add_heading("Supplementary Materials", level=0)
    supp.add_paragraph("Supplementary outputs include detailed exposure tables, full accessibility regime summaries, API robustness scaffolding and figures displaced from the fixed ten-figure main text.")
    for fig_path in sorted(SUPP_FIG_DIR.glob("*.png")):
        supp.add_picture(str(fig_path), width=Inches(6.2))
        supp.add_paragraph(fig_path.stem.replace("_", " "))
    for table_path in sorted(TABLE_DIR.glob("Table_*.csv")) + sorted(TABLE_DIR.glob("Supplement_*.csv")):
        supp.add_heading(table_path.stem, level=1)
        add_dataframe_table(supp, pd.read_csv(table_path), max_rows=20)
    supp.save(OUT / "Supplementary_Materials.docx")

    (OUT / "README_outputs.md").write_text("""# Health & Place revision outputs

Storyline: **Primary care is not always local**. The main scientific question is how unequal mobility breaks the spatial assumption that primary care is local and tertiary care is distant.

## Main figures
1. Conceptual framework: institutional healthcare hierarchy x mobility hierarchy.
2. Study context: Zhejiang terrain, ageing and healthcare hierarchy.
3. Mode-tier accessibility matrix.
4. Primary care locality test.
5. Hierarchy compression/expansion.
6. Hierarchy mismatch map.
7. Ageing-sensitive primary care failure zones.
8. Place-based mechanisms.
9. Accessibility regimes.
10. Robustness and benchmarking.

## Main tables
1. Data and metric definitions.
2. Mode-tier accessibility and inequality.
3. Hierarchy compression and mismatch summary.
4. City-level primary care failure exposure.
5. Mechanism models.

API provenance remains conservatively reported as a commercial navigation platform API. Multi-period live API robustness is documented as designed but not executed. Original MS/CL files were not overwritten.
""", encoding="utf-8")


def main() -> None:
    print("Building grid table...")
    df, cities_obj, profile = make_grid_table()
    globals()["cities"] = cities_obj
    globals()["GRID_SHAPE"] = (profile["height"], profile["width"])
    print(f"Grid table rows: {len(df):,}")
    metrics = metric_rows(df)
    exposure_city = exposure_by_city(df)
    models = mechanism_models(df)
    regimes = accessibility_regimes(df)
    hierarchy_summary, deep_df, failure_city = deep_hierarchy_analysis(df)
    hierarchy_city = failure_city
    primary_df, primary_city = primary_locality_analysis(df)
    api_status = make_api_sampling_inputs(df)
    if api_status is None:
        api_status = pd.DataFrame([{"component": "multi_period_api_robustness", "status": "designed_not_run"}])
    main_tables = make_main_tables(metrics, hierarchy_summary, failure_city, primary_city, models)
    figures = save_figures(
        df, metrics, exposure_city, regimes, api_status,
        hierarchy_summary, hierarchy_city, deep_df, failure_city,
        primary_df, primary_city, models,
    )
    write_figure_qa_notes()
    make_docx(figures, main_tables, api_status)
    print("Done.")
    print(f"Outputs: {OUT}")


if __name__ == "__main__":
    main()








